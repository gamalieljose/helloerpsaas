
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `account_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `type` enum('debit','credit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_type` enum('opening_balance','fund_transfer','deposit') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(22,4) NOT NULL,
  `reff_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `transaction_payment_id` int(11) DEFAULT NULL,
  `transfer_transaction_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_transactions_account_id_index` (`account_id`),
  KEY `account_transactions_transaction_id_index` (`transaction_id`),
  KEY `account_transactions_transaction_payment_id_index` (`transaction_payment_id`),
  KEY `account_transactions_transfer_transaction_id_index` (`transfer_transaction_id`),
  KEY `account_transactions_created_by_index` (`created_by`),
  KEY `account_transactions_type_index` (`type`),
  KEY `account_transactions_sub_type_index` (`sub_type`),
  KEY `account_transactions_operation_date_index` (`operation_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `account_transactions` WRITE;
/*!40000 ALTER TABLE `account_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_account_type_id` int(11) DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_types_parent_account_type_id_index` (`parent_account_type_id`),
  KEY `account_types_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_details` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_type_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accounts_business_id_index` (`business_id`),
  KEY `accounts_account_type_id_index` (`account_type_id`),
  KEY `accounts_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `causer_id` int(11) DEFAULT NULL,
  `causer_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `properties` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=522 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 14:41:48','2021-10-30 14:41:48'),(2,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-10-30 14:43:04','2021-10-30 14:43:04'),(3,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 14:52:50','2021-10-30 14:52:50'),(4,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-10-30 15:01:22','2021-10-30 15:01:22'),(5,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 15:34:24','2021-10-30 15:34:24'),(6,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 15:40:48','2021-10-30 15:40:48'),(7,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-10-30 15:47:22','2021-10-30 15:47:22'),(8,'default','login',2,'App\\User',2,2,'App\\User','[]','2021-10-30 15:48:59','2021-10-30 15:48:59'),(9,'default','logout',2,'App\\User',2,2,'App\\User','[]','2021-10-30 15:51:37','2021-10-30 15:51:37'),(10,'default','login',2,'App\\User',2,2,'App\\User','[]','2021-10-30 15:51:47','2021-10-30 15:51:47'),(11,'default','logout',2,'App\\User',2,2,'App\\User','[]','2021-10-30 15:55:33','2021-10-30 15:55:33'),(12,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 15:55:52','2021-10-30 15:55:52'),(13,'default','added',3,'App\\Contact',1,1,'App\\User','[]','2021-10-30 16:16:15','2021-10-30 16:16:15'),(14,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-10-30 16:24:18','2021-10-30 16:24:18'),(15,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 16:24:33','2021-10-30 16:24:33'),(16,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-10-30 16:24:46','2021-10-30 16:24:46'),(17,'default','login',2,'App\\User',2,2,'App\\User','[]','2021-10-30 16:24:53','2021-10-30 16:24:53'),(18,'default','logout',2,'App\\User',2,2,'App\\User','[]','2021-10-30 16:25:00','2021-10-30 16:25:00'),(19,'default','login',2,'App\\User',2,2,'App\\User','[]','2021-10-30 16:25:06','2021-10-30 16:25:06'),(20,'default','logout',2,'App\\User',2,2,'App\\User','[]','2021-10-30 16:25:39','2021-10-30 16:25:39'),(21,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 16:25:44','2021-10-30 16:25:44'),(22,'default','added',2,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-10-30 16:31:39','2021-10-30 16:31:39'),(23,'default','edited',2,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"15.0000\"}}','2021-10-30 16:32:22','2021-10-30 16:32:22'),(24,'default','edited',2,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"15.0000\"}}','2021-10-30 16:33:46','2021-10-30 16:33:46'),(25,'default','added',3,'App\\Transaction',1,1,'App\\User','[]','2021-10-30 16:35:06','2021-10-30 16:35:06'),(26,'default','added',4,'App\\Contact',1,1,'App\\User','[]','2021-10-30 16:36:54','2021-10-30 16:36:54'),(27,'default','added',4,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"ordered\",\"payment_status\":\"due\",\"final_total\":1200}}','2021-10-30 16:37:46','2021-10-30 16:37:46'),(28,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 16:55:08','2021-10-30 16:55:08'),(29,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 20:17:07','2021-10-30 20:17:07'),(30,'default','added',5,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":60}}','2021-10-30 20:17:32','2021-10-30 20:17:32'),(31,'default','added',6,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":30}}','2021-10-30 20:21:54','2021-10-30 20:21:54'),(32,'default','added',7,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":90}}','2021-10-30 20:29:49','2021-10-30 20:29:49'),(33,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-30 22:54:57','2021-10-30 22:54:57'),(34,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-31 14:47:16','2021-10-31 14:47:16'),(35,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-10-31 14:47:30','2021-10-31 14:47:30'),(36,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-10-31 14:48:37','2021-10-31 14:48:37'),(37,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 10:57:36','2021-11-02 10:57:36'),(38,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 10:58:12','2021-11-02 10:58:12'),(39,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 11:02:25','2021-11-02 11:02:25'),(40,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 11:14:35','2021-11-02 11:14:35'),(41,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 11:17:37','2021-11-02 11:17:37'),(42,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 11:36:17','2021-11-02 11:36:17'),(43,'default','added',8,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":30}}','2021-11-02 11:37:08','2021-11-02 11:37:08'),(44,'default','added',9,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":30}}','2021-11-02 11:37:36','2021-11-02 11:37:36'),(45,'default','added',10,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":30}}','2021-11-02 11:37:57','2021-11-02 11:37:57'),(46,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 11:40:15','2021-11-02 11:40:15'),(47,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-02 11:40:16','2021-11-02 11:40:16'),(48,'default','added',11,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":15}}','2021-11-02 11:43:25','2021-11-02 11:43:25'),(49,'default','created',1,'Modules\\Project\\Entities\\Project',NULL,1,'App\\User','{\"attributes\":{\"business_id\":1,\"name\":\"Proyecto 1\",\"contact_id\":3,\"status\":\"in_progress\",\"lead_id\":1,\"start_date\":null,\"end_date\":null,\"description\":null,\"created_by\":1,\"settings\":{\"enable_timelog\":1,\"enable_invoice\":1,\"enable_notes_documents\":1,\"members_crud_task\":0,\"members_crud_note\":0,\"members_crud_timelog\":0,\"task_view\":\"list_view\",\"task_id_prefix\":\"#\"},\"created_at\":\"2021-11-02 11:47:13\",\"updated_at\":\"2021-11-02 11:47:13\"}}','2021-11-02 11:47:13','2021-11-02 11:47:13'),(50,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 12:13:20','2021-11-02 12:13:20'),(51,'default','added',12,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-02 12:13:55','2021-11-02 12:13:55'),(52,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 12:19:07','2021-11-02 12:19:07'),(53,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 12:38:54','2021-11-02 12:38:54'),(54,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 12:40:29','2021-11-02 12:40:29'),(55,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 13:14:49','2021-11-02 13:14:49'),(56,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 15:50:44','2021-11-02 15:50:44'),(57,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 15:51:12','2021-11-02 15:51:12'),(58,'default','added',13,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-02 15:51:53','2021-11-02 15:51:53'),(59,'default','added',14,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":60}}','2021-11-02 15:53:34','2021-11-02 15:53:34'),(60,'default','added',15,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-02 15:53:40','2021-11-02 15:53:40'),(61,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 16:36:38','2021-11-02 16:36:38'),(62,'default','added',5,'App\\Contact',1,1,'App\\User','[]','2021-11-02 16:50:51','2021-11-02 16:50:51'),(63,'default','added',17,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":5}}','2021-11-02 16:50:58','2021-11-02 16:50:58'),(64,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 17:39:24','2021-11-02 17:39:24'),(65,'default','added',18,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":100}}','2021-11-02 17:55:33','2021-11-02 17:55:33'),(66,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-02 18:26:48','2021-11-02 18:26:48'),(67,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 18:49:06','2021-11-02 18:49:06'),(68,'default','payment_edited',4,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"paid\",\"final_total\":\"1200.0000\"},\"old\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":\"1200.0000\"}}','2021-11-02 18:49:59','2021-11-02 18:49:59'),(69,'default','added',6,'App\\Contact',1,1,'App\\User','[]','2021-11-02 18:57:03','2021-11-02 18:57:03'),(70,'default','added',19,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":225000}}','2021-11-02 18:57:13','2021-11-02 18:57:13'),(71,'default','added',20,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15000}}','2021-11-02 18:59:13','2021-11-02 18:59:13'),(72,'default','added',21,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3835}}','2021-11-02 18:59:52','2021-11-02 18:59:52'),(73,'default','added',22,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3805}}','2021-11-02 19:00:22','2021-11-02 19:00:22'),(74,'default','added',23,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3790}}','2021-11-02 19:01:08','2021-11-02 19:01:08'),(75,'default','added',24,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1875}}','2021-11-02 19:01:55','2021-11-02 19:01:55'),(76,'default','edited',24,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1875},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"1875.0000\"}}','2021-11-02 19:03:36','2021-11-02 19:03:36'),(77,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 19:16:47','2021-11-02 19:16:47'),(78,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 20:01:55','2021-11-02 20:01:55'),(79,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 20:28:14','2021-11-02 20:28:14'),(80,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 21:13:02','2021-11-02 21:13:02'),(81,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-02 22:51:00','2021-11-02 22:51:00'),(82,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 00:04:56','2021-11-03 00:04:56'),(83,'default','added',25,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1910}}','2021-11-03 00:09:42','2021-11-03 00:09:42'),(84,'default','added',26,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1925}}','2021-11-03 00:10:05','2021-11-03 00:10:05'),(85,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 00:11:31','2021-11-03 00:11:31'),(86,'default','payment_edited',17,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"5.0000\"},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":\"5.0000\"}}','2021-11-03 00:13:21','2021-11-03 00:13:21'),(87,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 07:30:43','2021-11-03 07:30:43'),(88,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 08:15:06','2021-11-03 08:15:06'),(89,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 08:18:07','2021-11-03 08:18:07'),(90,'default','login',3,'App\\User',3,3,'App\\User','[]','2021-11-03 08:19:48','2021-11-03 08:19:48'),(91,'default','added',27,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3790}}','2021-11-03 08:24:20','2021-11-03 08:24:20'),(92,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-03 08:26:58','2021-11-03 08:26:58'),(93,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 09:49:26','2021-11-03 09:49:26'),(94,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 10:07:27','2021-11-03 10:07:27'),(95,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 10:13:43','2021-11-03 10:13:43'),(96,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 10:31:14','2021-11-03 10:31:14'),(97,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 10:35:08','2021-11-03 10:35:08'),(98,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 11:02:38','2021-11-03 11:02:38'),(99,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 11:16:16','2021-11-03 11:16:16'),(100,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 11:52:31','2021-11-03 11:52:31'),(101,'default','added',28,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":10}}','2021-11-03 11:53:00','2021-11-03 11:53:00'),(102,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 12:20:14','2021-11-03 12:20:14'),(103,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 14:26:37','2021-11-03 14:26:37'),(104,'default','added',29,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":20}}','2021-11-03 14:29:20','2021-11-03 14:29:20'),(105,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 14:42:28','2021-11-03 14:42:28'),(106,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 15:22:13','2021-11-03 15:22:13'),(107,'default','added',30,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":5}}','2021-11-03 15:22:31','2021-11-03 15:22:31'),(108,'default','edited',30,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":5},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"due\",\"final_total\":\"5.0000\"}}','2021-11-03 15:22:58','2021-11-03 15:22:58'),(109,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 17:50:51','2021-11-03 17:50:51'),(110,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-03 17:54:08','2021-11-03 17:54:08'),(111,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 20:13:58','2021-11-03 20:13:58'),(112,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 21:49:52','2021-11-03 21:49:52'),(113,'default','added',31,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"final_total\":20}}','2021-11-03 21:51:17','2021-11-03 21:51:17'),(114,'default','added',32,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-03 21:52:02','2021-11-03 21:52:02'),(115,'default','added',33,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-03 21:52:50','2021-11-03 21:52:50'),(116,'default','added',8,'App\\Contact',1,1,'App\\User','[]','2021-11-03 22:27:57','2021-11-03 22:27:57'),(117,'default','added',35,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":300}}','2021-11-03 22:28:06','2021-11-03 22:28:06'),(118,'default','payment_edited',35,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"paid\",\"final_total\":\"300.0000\"},\"old\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":\"300.0000\"}}','2021-11-03 22:28:36','2021-11-03 22:28:36'),(119,'default','added',36,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":155}}','2021-11-03 22:33:30','2021-11-03 22:33:30'),(120,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 23:38:09','2021-11-03 23:38:09'),(121,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-03 23:38:44','2021-11-03 23:38:44'),(122,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 07:37:13','2021-11-04 07:37:13'),(123,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 08:02:45','2021-11-04 08:02:45'),(124,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 09:25:01','2021-11-04 09:25:01'),(125,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 10:38:10','2021-11-04 10:38:10'),(126,'default','added',37,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":15}}','2021-11-04 10:38:21','2021-11-04 10:38:21'),(127,'default','added',38,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":5}}','2021-11-04 10:39:17','2021-11-04 10:39:17'),(128,'default','added',39,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":5}}','2021-11-04 10:40:35','2021-11-04 10:40:35'),(129,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 12:45:20','2021-11-04 12:45:20'),(130,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 12:49:47','2021-11-04 12:49:47'),(131,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 14:05:17','2021-11-04 14:05:17'),(132,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 18:35:57','2021-11-04 18:35:57'),(133,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 19:44:26','2021-11-04 19:44:26'),(134,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 19:58:19','2021-11-04 19:58:19'),(135,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 20:09:58','2021-11-04 20:09:58'),(136,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-04 23:59:26','2021-11-04 23:59:26'),(137,'default','edited',26,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1925},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"1925.0000\"}}','2021-11-05 00:01:19','2021-11-05 00:01:19'),(138,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 06:33:27','2021-11-05 06:33:27'),(139,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 08:05:47','2021-11-05 08:05:47'),(140,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 10:47:12','2021-11-05 10:47:12'),(141,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 10:59:11','2021-11-05 10:59:11'),(142,'default','added',41,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":5}}','2021-11-05 11:06:16','2021-11-05 11:06:16'),(143,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 11:11:05','2021-11-05 11:11:05'),(144,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-05 11:13:14','2021-11-05 11:13:14'),(145,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 12:31:35','2021-11-05 12:31:35'),(146,'default','added',42,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":155}}','2021-11-05 12:32:02','2021-11-05 12:32:02'),(147,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 15:58:46','2021-11-05 15:58:46'),(148,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 17:26:37','2021-11-05 17:26:37'),(149,'default','added',43,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":155}}','2021-11-05 17:27:12','2021-11-05 17:27:12'),(150,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-05 22:35:33','2021-11-05 22:35:33'),(151,'default','added',9,'App\\Contact',1,1,'App\\User','[]','2021-11-05 22:38:27','2021-11-05 22:38:27'),(152,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-06 00:55:20','2021-11-06 00:55:20'),(153,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-06 00:57:02','2021-11-06 00:57:02'),(154,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-06 07:50:02','2021-11-06 07:50:02'),(155,'default','added',44,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"status\":\"final\"}}','2021-11-06 08:05:48','2021-11-06 08:05:48'),(156,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-06 09:37:07','2021-11-06 09:37:07'),(157,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-06 11:36:05','2021-11-06 11:36:05'),(158,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-06 11:37:51','2021-11-06 11:37:51'),(159,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-06 13:42:14','2021-11-06 13:42:14'),(160,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 01:37:49','2021-11-07 01:37:49'),(161,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 02:07:35','2021-11-07 02:07:35'),(162,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 11:43:59','2021-11-07 11:43:59'),(163,'default','added',46,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":620}}','2021-11-07 11:49:36','2021-11-07 11:49:36'),(164,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 12:23:32','2021-11-07 12:23:32'),(165,'default','added',47,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":310}}','2021-11-07 12:28:30','2021-11-07 12:28:30'),(166,'default','added',48,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":1240}}','2021-11-07 12:30:28','2021-11-07 12:30:28'),(167,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 16:11:38','2021-11-07 16:11:38'),(168,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 16:43:30','2021-11-07 16:43:30'),(169,'default','added',49,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":310}}','2021-11-07 16:46:10','2021-11-07 16:46:10'),(170,'default','added',50,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":155}}','2021-11-07 17:22:34','2021-11-07 17:22:34'),(171,'default','added',51,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":155}}','2021-11-07 17:24:05','2021-11-07 17:24:05'),(172,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 19:57:11','2021-11-07 19:57:11'),(173,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 19:59:55','2021-11-07 19:59:55'),(174,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-07 20:04:42','2021-11-07 20:04:42'),(175,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 00:44:56','2021-11-08 00:44:56'),(176,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-08 00:45:09','2021-11-08 00:45:09'),(177,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 06:27:03','2021-11-08 06:27:03'),(178,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 06:53:14','2021-11-08 06:53:14'),(179,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 07:02:14','2021-11-08 07:02:14'),(180,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 07:16:30','2021-11-08 07:16:30'),(181,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 07:25:46','2021-11-08 07:25:46'),(182,'default','added',52,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"final_total\":310}}','2021-11-08 07:27:07','2021-11-08 07:27:07'),(183,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-08 07:34:35','2021-11-08 07:34:35'),(184,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 07:53:15','2021-11-08 07:53:15'),(185,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 08:05:01','2021-11-08 08:05:01'),(186,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 08:14:12','2021-11-08 08:14:12'),(187,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 08:28:12','2021-11-08 08:28:12'),(188,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 09:07:33','2021-11-08 09:07:33'),(189,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 09:14:57','2021-11-08 09:14:57'),(190,'default','added',53,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":465}}','2021-11-08 09:16:07','2021-11-08 09:16:07'),(191,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 09:25:36','2021-11-08 09:25:36'),(192,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 10:28:22','2021-11-08 10:28:22'),(193,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 10:41:33','2021-11-08 10:41:33'),(194,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 10:56:01','2021-11-08 10:56:01'),(195,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 11:17:23','2021-11-08 11:17:23'),(196,'default','added',54,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":310}}','2021-11-08 11:44:33','2021-11-08 11:44:33'),(197,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-08 11:45:39','2021-11-08 11:45:39'),(198,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 12:32:11','2021-11-08 12:32:11'),(199,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 13:17:51','2021-11-08 13:17:51'),(200,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 14:01:49','2021-11-08 14:01:49'),(201,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 14:18:54','2021-11-08 14:18:54'),(202,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 14:28:54','2021-11-08 14:28:54'),(203,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 14:45:07','2021-11-08 14:45:07'),(204,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 14:46:11','2021-11-08 14:46:11'),(205,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 14:57:07','2021-11-08 14:57:07'),(206,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 16:45:32','2021-11-08 16:45:32'),(207,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 17:10:43','2021-11-08 17:10:43'),(208,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 17:32:54','2021-11-08 17:32:54'),(210,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 19:20:40','2021-11-08 19:20:40'),(211,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 19:59:49','2021-11-08 19:59:49'),(212,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 20:11:03','2021-11-08 20:11:03'),(213,'default','added',55,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":5}}','2021-11-08 20:11:26','2021-11-08 20:11:26'),(214,'default','added',56,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":5}}','2021-11-08 20:14:36','2021-11-08 20:14:36'),(215,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-08 21:29:58','2021-11-08 21:29:58'),(216,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 01:04:22','2021-11-09 01:04:22'),(217,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 01:49:04','2021-11-09 01:49:04'),(218,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 02:35:07','2021-11-09 02:35:07'),(219,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 08:47:19','2021-11-09 08:47:19'),(220,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 08:48:56','2021-11-09 08:48:56'),(221,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 10:31:29','2021-11-09 10:31:29'),(222,'default','added',57,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-09 10:32:21','2021-11-09 10:32:21'),(223,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-09 10:33:39','2021-11-09 10:33:39'),(224,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 14:42:03','2021-11-09 14:42:03'),(225,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 17:36:03','2021-11-09 17:36:03'),(226,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 21:03:28','2021-11-09 21:03:28'),(227,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 21:09:17','2021-11-09 21:09:17'),(228,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-09 21:14:36','2021-11-09 21:14:36'),(229,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-10 07:07:28','2021-11-10 07:07:28'),(230,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-10 07:42:17','2021-11-10 07:42:17'),(231,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-10 08:06:37','2021-11-10 08:06:37'),(232,'default','added',58,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1875}}','2021-11-10 08:08:05','2021-11-10 08:08:05'),(233,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-10 12:57:55','2021-11-10 12:57:55'),(234,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-10 13:39:20','2021-11-10 13:39:20'),(235,'default','added',59,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":310}}','2021-11-10 14:01:37','2021-11-10 14:01:37'),(236,'default','added',10,'App\\Contact',1,1,'App\\User','[]','2021-11-10 14:05:33','2021-11-10 14:05:33'),(237,'default','added',60,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3765}}','2021-11-10 14:06:53','2021-11-10 14:06:53'),(238,'default','added',61,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":2585160}}','2021-11-10 14:11:15','2021-11-10 14:11:15'),(239,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-10 17:08:32','2021-11-10 17:08:32'),(240,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-11 08:31:03','2021-11-11 08:31:03'),(241,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-11 10:57:22','2021-11-11 10:57:22'),(242,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-11 15:07:11','2021-11-11 15:07:11'),(243,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-11 15:44:06','2021-11-11 15:44:06'),(244,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-11 16:13:33','2021-11-11 16:13:33'),(245,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-12 17:49:34','2021-11-12 17:49:34'),(246,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 06:31:12','2021-11-13 06:31:12'),(247,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 06:39:53','2021-11-13 06:39:53'),(248,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 06:48:57','2021-11-13 06:48:57'),(249,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 06:59:21','2021-11-13 06:59:21'),(250,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:01:53','2021-11-13 07:01:53'),(251,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:08:31','2021-11-13 07:08:31'),(252,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:14:50','2021-11-13 07:14:50'),(253,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:15:13','2021-11-13 07:15:13'),(254,'default','added',62,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":23.75}}','2021-11-13 07:15:42','2021-11-13 07:15:42'),(255,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:15:59','2021-11-13 07:15:59'),(256,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:27:29','2021-11-13 07:27:29'),(257,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:35:06','2021-11-13 07:35:06'),(258,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:37:19','2021-11-13 07:37:19'),(259,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:39:52','2021-11-13 07:39:52'),(260,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:47:02','2021-11-13 07:47:02'),(261,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 07:49:30','2021-11-13 07:49:30'),(262,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 08:11:22','2021-11-13 08:11:22'),(263,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 08:18:09','2021-11-13 08:18:09'),(264,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 08:22:05','2021-11-13 08:22:05'),(265,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 09:06:30','2021-11-13 09:06:30'),(266,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 09:14:14','2021-11-13 09:14:14'),(267,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 09:24:41','2021-11-13 09:24:41'),(268,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 09:57:09','2021-11-13 09:57:09'),(269,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 10:30:49','2021-11-13 10:30:49'),(270,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 10:44:17','2021-11-13 10:44:17'),(271,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 10:46:22','2021-11-13 10:46:22'),(272,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-13 11:03:01','2021-11-13 11:03:01'),(273,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 11:06:56','2021-11-13 11:06:56'),(274,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 11:20:26','2021-11-13 11:20:26'),(275,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 11:26:45','2021-11-13 11:26:45'),(276,'default','added',1,'Modules\\Essentials\\Entities\\ToDo',1,1,'App\\User','{\"attributes\":{\"status\":\"new\"}}','2021-11-13 11:26:47','2021-11-13 11:26:47'),(277,'default','added',2,'Modules\\Essentials\\Entities\\ToDo',1,1,'App\\User','{\"attributes\":{\"status\":\"new\"}}','2021-11-13 11:27:01','2021-11-13 11:27:01'),(278,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 14:06:30','2021-11-13 14:06:30'),(279,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 14:50:30','2021-11-13 14:50:30'),(280,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 15:46:54','2021-11-13 15:46:54'),(281,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 16:48:31','2021-11-13 16:48:31'),(282,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 17:19:05','2021-11-13 17:19:05'),(283,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 19:15:02','2021-11-13 19:15:02'),(284,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-13 21:10:09','2021-11-13 21:10:09'),(285,'default','sell_deleted',62,'App\\Transaction',1,1,'App\\User','{\"id\":62,\"invoice_no\":\"0042\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"23.7500\"}}','2021-11-13 21:17:42','2021-11-13 21:17:42'),(286,'default','sell_deleted',61,'App\\Transaction',1,1,'App\\User','{\"id\":61,\"invoice_no\":\"0041\",\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"2585160.0000\"}}','2021-11-13 21:17:50','2021-11-13 21:17:50'),(287,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-14 14:01:28','2021-11-14 14:01:28'),(288,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 06:50:00','2021-11-15 06:50:00'),(289,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 07:02:08','2021-11-15 07:02:08'),(290,'default','added',63,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":25312.5}}','2021-11-15 07:11:46','2021-11-15 07:11:46'),(291,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 08:20:43','2021-11-15 08:20:43'),(292,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 09:44:30','2021-11-15 09:44:30'),(293,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 09:49:28','2021-11-15 09:49:28'),(294,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 09:59:08','2021-11-15 09:59:08'),(295,'default','added',64,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"status\":\"final\"}}','2021-11-15 10:04:50','2021-11-15 10:04:50'),(296,'default','added',66,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1875}}','2021-11-15 10:07:00','2021-11-15 10:07:00'),(297,'default','added',11,'App\\Contact',1,1,'App\\User','[]','2021-11-15 10:09:15','2021-11-15 10:09:15'),(298,'default','added',67,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-15 10:10:33','2021-11-15 10:10:33'),(299,'default','added',68,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"final_total\":15}}','2021-11-15 10:11:25','2021-11-15 10:11:25'),(300,'default','added',69,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-15 10:11:47','2021-11-15 10:11:47'),(301,'default','added',70,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1890}}','2021-11-15 10:18:41','2021-11-15 10:18:41'),(302,'default','added',71,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"status\":\"final\"}}','2021-11-15 10:19:47','2021-11-15 10:19:47'),(303,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 13:48:59','2021-11-15 13:48:59'),(304,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-15 13:56:38','2021-11-15 13:56:38'),(305,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 22:29:03','2021-11-15 22:29:03'),(306,'default','added',73,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3750}}','2021-11-15 22:29:46','2021-11-15 22:29:46'),(307,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-15 23:02:29','2021-11-15 23:02:29'),(308,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-16 06:38:00','2021-11-16 06:38:00'),(309,'default','added',74,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1876}}','2021-11-16 06:40:35','2021-11-16 06:40:35'),(310,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-16 07:17:09','2021-11-16 07:17:09'),(311,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-16 13:27:33','2021-11-16 13:27:33'),(312,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-16 19:47:59','2021-11-16 19:47:59'),(313,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 11:22:05','2021-11-17 11:22:05'),(314,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 11:23:39','2021-11-17 11:23:39'),(315,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 11:32:25','2021-11-17 11:32:25'),(316,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-17 11:32:34','2021-11-17 11:32:34'),(317,'default','added',75,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1875}}','2021-11-17 11:32:54','2021-11-17 11:32:54'),(318,'default','added',76,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":23437.5}}','2021-11-17 11:37:09','2021-11-17 11:37:09'),(319,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 11:38:29','2021-11-17 11:38:29'),(320,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-17 11:52:18','2021-11-17 11:52:18'),(321,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 13:07:57','2021-11-17 13:07:57'),(322,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 13:08:06','2021-11-17 13:08:06'),(323,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 13:09:36','2021-11-17 13:09:36'),(324,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 13:16:23','2021-11-17 13:16:23'),(325,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 13:33:49','2021-11-17 13:33:49'),(326,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 13:34:38','2021-11-17 13:34:38'),(327,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-17 13:35:51','2021-11-17 13:35:51'),(328,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 13:36:18','2021-11-17 13:36:18'),(329,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 20:24:37','2021-11-17 20:24:37'),(330,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 20:48:03','2021-11-17 20:48:03'),(331,'default','added',77,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":23452.5}}','2021-11-17 20:49:45','2021-11-17 20:49:45'),(332,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-17 20:51:41','2021-11-17 20:51:41'),(333,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-17 20:51:57','2021-11-17 20:51:57'),(334,'default','added',78,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":93750}}','2021-11-17 20:54:16','2021-11-17 20:54:16'),(335,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-18 08:00:15','2021-11-18 08:00:15'),(336,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-18 08:49:34','2021-11-18 08:49:34'),(337,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-18 09:58:01','2021-11-18 09:58:01'),(338,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-18 13:59:18','2021-11-18 13:59:18'),(339,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-18 15:57:48','2021-11-18 15:57:48'),(340,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-18 15:58:51','2021-11-18 15:58:51'),(341,'default','added',79,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1875}}','2021-11-18 15:59:23','2021-11-18 15:59:23'),(342,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-18 16:07:47','2021-11-18 16:07:47'),(343,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-18 18:30:01','2021-11-18 18:30:01'),(344,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-19 00:21:16','2021-11-19 00:21:16'),(345,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-19 07:17:18','2021-11-19 07:17:18'),(346,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-19 08:03:53','2021-11-19 08:03:53'),(347,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-19 10:03:50','2021-11-19 10:03:50'),(348,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-19 14:08:46','2021-11-19 14:08:46'),(349,'default','login',4,'App\\User',4,4,'App\\User','[]','2021-11-19 09:46:46','2021-11-19 09:46:46'),(350,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-19 21:12:16','2021-11-19 21:12:16'),(351,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-19 22:04:37','2021-11-19 22:04:37'),(352,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-21 00:24:33','2021-11-21 00:24:33'),(353,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-21 15:19:17','2021-11-21 15:19:17'),(354,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 06:37:09','2021-11-22 06:37:09'),(355,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 07:04:02','2021-11-22 07:04:02'),(356,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 07:42:31','2021-11-22 07:42:31'),(357,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 08:09:05','2021-11-22 08:09:05'),(358,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 09:30:10','2021-11-22 09:30:10'),(359,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 10:06:16','2021-11-22 10:06:16'),(360,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 10:10:53','2021-11-22 10:10:53'),(361,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 11:59:20','2021-11-22 11:59:20'),(362,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 12:32:46','2021-11-22 12:32:46'),(363,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 17:57:31','2021-11-22 17:57:31'),(364,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-22 21:52:37','2021-11-22 21:52:37'),(365,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 00:27:13','2021-11-23 00:27:13'),(366,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 11:27:23','2021-11-23 11:27:23'),(367,'default','added',13,'App\\Contact',1,1,'App\\User','[]','2021-11-23 11:29:22','2021-11-23 11:29:22'),(368,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 12:28:37','2021-11-23 12:28:37'),(369,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 12:58:37','2021-11-23 12:58:37'),(370,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 16:29:05','2021-11-23 16:29:05'),(371,'default','added',80,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"status\":\"pending\"}}','2021-11-23 16:30:57','2021-11-23 16:30:57'),(372,'default','added',82,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":171637.5}}','2021-11-23 16:42:40','2021-11-23 16:42:40'),(373,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 20:37:23','2021-11-23 20:37:23'),(374,'default','added',83,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":325}}','2021-11-23 20:41:14','2021-11-23 20:41:14'),(375,'default','added',5,'App\\User',1,1,'App\\User','{\"name\":\"Sr Luis Luis\"}','2021-11-23 20:43:52','2021-11-23 20:43:52'),(376,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-23 20:44:04','2021-11-23 20:44:04'),(377,'default','login',5,'App\\User',1,5,'App\\User','[]','2021-11-23 20:44:15','2021-11-23 20:44:15'),(378,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 21:43:23','2021-11-23 21:43:23'),(379,'default','edited',5,'App\\User',1,1,'App\\User','{\"name\":\"Sr Luis Luis\"}','2021-11-23 21:44:20','2021-11-23 21:44:20'),(380,'default','added',14,'App\\Contact',1,1,'App\\User','[]','2021-11-23 21:54:28','2021-11-23 21:54:28'),(381,'default','added',84,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"purchase\",\"status\":\"received\",\"payment_status\":\"due\",\"final_total\":90000}}','2021-11-23 21:54:48','2021-11-23 21:54:48'),(382,'default','added',85,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"status\":\"final\"}}','2021-11-23 21:56:07','2021-11-23 21:56:07'),(383,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-23 21:58:18','2021-11-23 21:58:18'),(384,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 21:58:58','2021-11-23 21:58:58'),(385,'default','edited',5,'App\\User',1,1,'App\\User','{\"name\":\"Sr Luis Luis\"}','2021-11-23 22:00:58','2021-11-23 22:00:58'),(386,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-23 22:01:06','2021-11-23 22:01:06'),(387,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 22:01:41','2021-11-23 22:01:41'),(388,'default','deleted',5,'App\\User',1,1,'App\\User','{\"name\":\"Sr Luis Luis\",\"id\":5}','2021-11-23 22:02:04','2021-11-23 22:02:04'),(389,'default','added',6,'App\\User',1,1,'App\\User','{\"name\":\"Sr Luis Luis\"}','2021-11-23 22:02:42','2021-11-23 22:02:42'),(390,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-23 22:02:54','2021-11-23 22:02:54'),(391,'default','login',6,'App\\User',1,6,'App\\User','[]','2021-11-23 22:03:17','2021-11-23 22:03:17'),(392,'default','added',87,'App\\Transaction',1,6,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1240}}','2021-11-23 22:04:19','2021-11-23 22:04:19'),(393,'default','added',88,'App\\Transaction',1,6,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":155}}','2021-11-23 22:04:33','2021-11-23 22:04:33'),(394,'default','edited',88,'App\\Transaction',1,6,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":465},\"old\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":\"155.0000\"}}','2021-11-23 22:05:10','2021-11-23 22:05:10'),(395,'default','added',89,'App\\Transaction',1,6,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"final_total\":465}}','2021-11-23 22:06:16','2021-11-23 22:06:16'),(396,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 22:21:27','2021-11-23 22:21:27'),(397,'default','logout',6,'App\\User',1,6,'App\\User','[]','2021-11-23 22:55:25','2021-11-23 22:55:25'),(398,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 22:55:34','2021-11-23 22:55:34'),(399,'default','edited',80,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"status\":\"final\"},\"old\":{\"status\":\"in_transit\"}}','2021-11-23 22:57:51','2021-11-23 22:57:51'),(400,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 23:39:38','2021-11-23 23:39:38'),(401,'default','login',6,'App\\User',1,6,'App\\User','[]','2021-11-23 23:46:01','2021-11-23 23:46:01'),(402,'default','logout',6,'App\\User',1,6,'App\\User','[]','2021-11-23 23:50:38','2021-11-23 23:50:38'),(403,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-23 23:50:52','2021-11-23 23:50:52'),(404,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-24 07:34:16','2021-11-24 07:34:16'),(405,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-24 10:52:34','2021-11-24 10:52:34'),(406,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-25 08:44:24','2021-11-25 08:44:24'),(407,'default','added',90,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":25327.5}}','2021-11-25 08:45:40','2021-11-25 08:45:40'),(408,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-25 14:26:49','2021-11-25 14:26:49'),(409,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 00:15:56','2021-11-26 00:15:56'),(410,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 00:26:30','2021-11-26 00:26:30'),(411,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-26 00:26:54','2021-11-26 00:26:54'),(412,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 06:52:15','2021-11-26 06:52:15'),(413,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 07:39:27','2021-11-26 07:39:27'),(414,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 07:44:57','2021-11-26 07:44:57'),(415,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 12:42:49','2021-11-26 12:42:49'),(416,'default','added',91,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":70357.5}}','2021-11-26 12:44:47','2021-11-26 12:44:47'),(417,'default','added',92,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":15}}','2021-11-26 12:45:23','2021-11-26 12:45:23'),(418,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 13:46:52','2021-11-26 13:46:52'),(419,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 15:17:19','2021-11-26 15:17:19'),(420,'default','added',93,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-26 15:17:50','2021-11-26 15:17:50'),(421,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 16:41:03','2021-11-26 16:41:03'),(422,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-26 21:22:53','2021-11-26 21:22:53'),(423,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 07:01:12','2021-11-27 07:01:12'),(424,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 07:53:24','2021-11-27 07:53:24'),(425,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 08:07:35','2021-11-27 08:07:35'),(426,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-27 08:10:07','2021-11-27 08:10:07'),(427,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 08:13:31','2021-11-27 08:13:31'),(428,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 08:34:32','2021-11-27 08:34:32'),(429,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 08:41:56','2021-11-27 08:41:56'),(430,'default','created',2,'Modules\\Project\\Entities\\Project',NULL,1,'App\\User','{\"attributes\":{\"business_id\":1,\"name\":\"SHERROSERA DOMINICANA\",\"contact_id\":10,\"status\":\"not_started\",\"lead_id\":6,\"start_date\":\"2021-11-30 00:00:00\",\"end_date\":\"2022-10-31 00:00:00\",\"description\":null,\"created_by\":1,\"settings\":{\"enable_timelog\":1,\"enable_invoice\":1,\"enable_notes_documents\":1,\"members_crud_task\":0,\"members_crud_note\":0,\"members_crud_timelog\":0,\"task_view\":\"list_view\",\"task_id_prefix\":\"#\"},\"created_at\":\"2021-11-27 08:44:35\",\"updated_at\":\"2021-11-27 08:44:35\"}}','2021-11-27 08:44:35','2021-11-27 08:44:35'),(431,'default','updated',2,'Modules\\Project\\Entities\\Project',NULL,1,'App\\User','{\"attributes\":{\"status\":\"on_hold\",\"updated_at\":\"2021-11-27 08:45:21\"},\"old\":{\"status\":\"not_started\",\"updated_at\":\"2021-11-27 08:44:35\"}}','2021-11-27 08:45:21','2021-11-27 08:45:21'),(432,'default','updated',2,'Modules\\Project\\Entities\\Project',NULL,1,'App\\User','{\"attributes\":{\"status\":\"not_started\",\"updated_at\":\"2021-11-27 08:45:26\"},\"old\":{\"status\":\"on_hold\",\"updated_at\":\"2021-11-27 08:45:21\"}}','2021-11-27 08:45:26','2021-11-27 08:45:26'),(433,'default','added',94,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":46875}}','2021-11-27 08:46:27','2021-11-27 08:46:27'),(434,'default','added',95,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":15}}','2021-11-27 08:47:33','2021-11-27 08:47:33'),(435,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 10:09:18','2021-11-27 10:09:18'),(436,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 10:27:52','2021-11-27 10:27:52'),(437,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 10:56:17','2021-11-27 10:56:17'),(438,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 11:23:35','2021-11-27 11:23:35'),(439,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 15:02:09','2021-11-27 15:02:09'),(440,'default','added',96,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":3750}}','2021-11-27 15:04:48','2021-11-27 15:04:48'),(441,'default','added',97,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1875}}','2021-11-27 15:05:10','2021-11-27 15:05:10'),(442,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 15:14:10','2021-11-27 15:14:10'),(443,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 15:30:37','2021-11-27 15:30:37'),(444,'default','added',98,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":38437.5}}','2021-11-27 15:36:40','2021-11-27 15:36:40'),(445,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 17:30:03','2021-11-27 17:30:03'),(446,'default','added',99,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":25312.5}}','2021-11-27 17:31:38','2021-11-27 17:31:38'),(447,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-27 18:53:28','2021-11-27 18:53:28'),(448,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-28 10:45:25','2021-11-28 10:45:25'),(449,'default','added',100,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":60}}','2021-11-28 10:52:49','2021-11-28 10:52:49'),(450,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-28 17:04:07','2021-11-28 17:04:07'),(451,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-28 17:07:10','2021-11-28 17:07:10'),(452,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-28 17:08:25','2021-11-28 17:08:25'),(453,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-28 17:16:41','2021-11-28 17:16:41'),(454,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-28 20:41:39','2021-11-28 20:41:39'),(455,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 03:59:46','2021-11-29 03:59:46'),(456,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 07:01:19','2021-11-29 07:01:19'),(457,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 07:06:38','2021-11-29 07:06:38'),(458,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 07:53:35','2021-11-29 07:53:35'),(459,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 08:50:04','2021-11-29 08:50:04'),(460,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 11:39:18','2021-11-29 11:39:18'),(461,'default','added',101,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":23452.5}}','2021-11-29 11:46:25','2021-11-29 11:46:25'),(462,'default','added',102,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":155}}','2021-11-29 11:49:00','2021-11-29 11:49:00'),(463,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-29 11:52:23','2021-11-29 11:52:23'),(464,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 11:52:56','2021-11-29 11:52:56'),(465,'default','updated',2,'Modules\\Project\\Entities\\Project',NULL,1,'App\\User','{\"attributes\":{\"status\":\"in_progress\",\"updated_at\":\"2021-11-29 12:18:21\"},\"old\":{\"status\":\"not_started\",\"updated_at\":\"2021-11-27 08:45:26\"}}','2021-11-29 12:18:21','2021-11-29 12:18:21'),(466,'default','updated',1,'Modules\\Project\\Entities\\Project',NULL,1,'App\\User','{\"attributes\":{\"status\":\"on_hold\",\"updated_at\":\"2021-11-29 12:18:26\"},\"old\":{\"status\":\"in_progress\",\"updated_at\":\"2021-11-02 11:47:13\"}}','2021-11-29 12:18:26','2021-11-29 12:18:26'),(467,'default','updated',2,'Modules\\Project\\Entities\\Project',NULL,1,'App\\User','{\"attributes\":{\"status\":\"not_started\",\"updated_at\":\"2021-11-29 12:18:29\"},\"old\":{\"status\":\"in_progress\",\"updated_at\":\"2021-11-29 12:18:21\"}}','2021-11-29 12:18:29','2021-11-29 12:18:29'),(468,'default','updated',1,'Modules\\Project\\Entities\\Project',NULL,1,'App\\User','{\"attributes\":{\"status\":\"in_progress\",\"updated_at\":\"2021-11-29 12:18:31\"},\"old\":{\"status\":\"on_hold\",\"updated_at\":\"2021-11-29 12:18:26\"}}','2021-11-29 12:18:31','2021-11-29 12:18:31'),(469,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 12:54:30','2021-11-29 12:54:30'),(470,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 12:55:03','2021-11-29 12:55:03'),(471,'default','added',103,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":23452.5}}','2021-11-29 12:56:08','2021-11-29 12:56:08'),(472,'default','edited',6,'App\\User',1,1,'App\\User','{\"name\":\"Sr Luis Luis\"}','2021-11-29 13:05:36','2021-11-29 13:05:36'),(473,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-29 13:05:48','2021-11-29 13:05:48'),(474,'default','login',6,'App\\User',1,6,'App\\User','[]','2021-11-29 13:05:54','2021-11-29 13:05:54'),(475,'default','added',104,'App\\Transaction',1,6,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"draft\",\"sub_status\":\"quotation\",\"final_total\":155}}','2021-11-29 13:06:37','2021-11-29 13:06:37'),(476,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 13:57:04','2021-11-29 13:57:04'),(477,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 14:07:14','2021-11-29 14:07:14'),(478,'default','added',105,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":25312.5}}','2021-11-29 14:07:50','2021-11-29 14:07:50'),(479,'default','added',106,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":1875}}','2021-11-29 14:08:19','2021-11-29 14:08:19'),(480,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 16:49:02','2021-11-29 16:49:02'),(481,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 17:10:48','2021-11-29 17:10:48'),(482,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 18:30:31','2021-11-29 18:30:31'),(483,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 19:35:20','2021-11-29 19:35:20'),(484,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-29 22:54:41','2021-11-29 22:54:41'),(485,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 08:11:46','2021-11-30 08:11:46'),(486,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 08:35:34','2021-11-30 08:35:34'),(487,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 08:59:43','2021-11-30 08:59:43'),(488,'default','added',107,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"status\":\"pending\"}}','2021-11-30 09:31:20','2021-11-30 09:31:20'),(489,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-30 10:08:02','2021-11-30 10:08:02'),(490,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:03:02','2021-11-30 11:03:02'),(491,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:05:10','2021-11-30 11:05:10'),(492,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:06:46','2021-11-30 11:06:46'),(493,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:09:13','2021-11-30 11:09:13'),(494,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:10:28','2021-11-30 11:10:28'),(495,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:16:19','2021-11-30 11:16:19'),(496,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:17:16','2021-11-30 11:17:16'),(497,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:20:19','2021-11-30 11:20:19'),(498,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:22:43','2021-11-30 11:22:43'),(499,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:24:49','2021-11-30 11:24:49'),(500,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:26:51','2021-11-30 11:26:51'),(501,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:45:34','2021-11-30 11:45:34'),(502,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:52:55','2021-11-30 11:52:55'),(503,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 11:59:48','2021-11-30 11:59:48'),(504,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:15:51','2021-11-30 12:15:51'),(505,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:19:34','2021-11-30 12:19:34'),(506,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:19:43','2021-11-30 12:19:43'),(507,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:20:33','2021-11-30 12:20:33'),(508,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:21:19','2021-11-30 12:21:19'),(509,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:23:40','2021-11-30 12:23:40'),(510,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:25:17','2021-11-30 12:25:17'),(511,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:26:26','2021-11-30 12:26:26'),(512,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:26:46','2021-11-30 12:26:46'),(513,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:27:22','2021-11-30 12:27:22'),(514,'default','added',109,'App\\Transaction',1,1,'App\\User','{\"attributes\":{\"type\":\"sell\",\"status\":\"final\",\"payment_status\":\"paid\",\"final_total\":5640}}','2021-11-30 12:29:04','2021-11-30 12:29:04'),(515,'default','logout',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:31:43','2021-11-30 12:31:43'),(516,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:41:11','2021-11-30 12:41:11'),(517,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:42:08','2021-11-30 12:42:08'),(518,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 12:48:57','2021-11-30 12:48:57'),(519,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 13:01:17','2021-11-30 13:01:17'),(520,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 13:04:35','2021-11-30 13:04:35'),(521,'default','login',1,'App\\User',1,1,'App\\User','[]','2021-11-30 13:23:01','2021-11-30 13:23:01');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `barcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barcodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` double(22,4) DEFAULT NULL,
  `height` double(22,4) DEFAULT NULL,
  `paper_width` double(22,4) DEFAULT NULL,
  `paper_height` double(22,4) DEFAULT NULL,
  `top_margin` double(22,4) DEFAULT NULL,
  `left_margin` double(22,4) DEFAULT NULL,
  `row_distance` double(22,4) DEFAULT NULL,
  `col_distance` double(22,4) DEFAULT NULL,
  `stickers_in_one_row` int(11) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_continuous` tinyint(1) NOT NULL DEFAULT 0,
  `stickers_in_one_sheet` int(11) DEFAULT NULL,
  `business_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `barcodes_business_id_foreign` (`business_id`),
  CONSTRAINT `barcodes_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `barcodes` WRITE;
/*!40000 ALTER TABLE `barcodes` DISABLE KEYS */;
INSERT INTO `barcodes` VALUES (1,'20 Labels per Sheet','Sheet Size: 8.5\" x 11\", Label Size: 4\" x 1\", Labels per sheet: 20',4.0000,1.0000,8.5000,11.0000,0.5000,0.1250,0.0000,0.1875,2,0,0,20,NULL,'2017-12-18 06:13:44','2017-12-18 06:13:44'),(2,'30 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2.625\" x 1\", Labels per sheet: 30',2.6250,1.0000,8.5000,11.0000,0.5000,0.1880,0.0000,0.1250,3,0,0,30,NULL,'2017-12-18 06:04:39','2017-12-18 06:10:40'),(3,'32 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2\" x 1.25\", Labels per sheet: 32',2.0000,1.2500,8.5000,11.0000,0.5000,0.2500,0.0000,0.0000,4,0,0,32,NULL,'2017-12-18 05:55:40','2017-12-18 05:55:40'),(4,'40 Labels per sheet','Sheet Size: 8.5\" x 11\", Label Size: 2\" x 1\", Labels per sheet: 40',2.0000,1.0000,8.5000,11.0000,0.5000,0.2500,0.0000,0.0000,4,0,0,40,NULL,'2017-12-18 05:58:40','2017-12-18 05:58:40'),(5,'50 Labels per Sheet','Sheet Size: 8.5\" x 11\", Label Size: 1.5\" x 1\", Labels per sheet: 50',1.5000,1.0000,8.5000,11.0000,0.5000,0.5000,0.0000,0.0000,5,0,0,50,NULL,'2017-12-18 05:51:10','2017-12-18 05:51:10'),(6,'Continuous Rolls - 31.75mm x 25.4mm','Label Size: 31.75mm x 25.4mm, Gap: 3.18mm',1.2500,1.0000,1.2500,0.0000,0.1250,0.0000,0.1250,0.0000,1,0,1,NULL,NULL,'2017-12-18 05:51:10','2017-12-18 05:51:10');
/*!40000 ALTER TABLE `barcodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` int(10) unsigned NOT NULL,
  `waiter_id` int(10) unsigned DEFAULT NULL,
  `table_id` int(10) unsigned DEFAULT NULL,
  `correspondent_id` int(11) DEFAULT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `booking_start` datetime NOT NULL,
  `booking_end` datetime NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `booking_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `booking_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bookings_contact_id_foreign` (`contact_id`),
  KEY `bookings_business_id_foreign` (`business_id`),
  KEY `bookings_created_by_foreign` (`created_by`),
  KEY `bookings_table_id_index` (`table_id`),
  KEY `bookings_waiter_id_index` (`waiter_id`),
  KEY `bookings_location_id_index` (`location_id`),
  KEY `bookings_booking_status_index` (`booking_status`),
  KEY `bookings_correspondent_id_index` (`correspondent_id`),
  CONSTRAINT `bookings_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `use_for_repair` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'brands to be used on repair module',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brands_business_id_foreign` (`business_id`),
  KEY `brands_created_by_foreign` (`created_by`),
  CONSTRAINT `brands_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `brands_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (1,1,'DEMO1',NULL,1,0,NULL,'2021-10-30 15:58:32','2021-10-30 15:58:32'),(2,1,'COCA COLA',NULL,1,0,NULL,'2021-11-02 16:39:01','2021-11-02 16:39:01'),(3,1,'CARRERA',NULL,1,0,NULL,'2021-11-03 22:04:52','2021-11-03 22:04:52'),(4,1,'Peperi',NULL,1,0,NULL,'2021-11-05 06:42:10','2021-11-05 06:42:10');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `tax_number_1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label_1` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number_2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label_2` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_label_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_label_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_sales_tax` int(10) unsigned DEFAULT NULL,
  `default_profit_percent` double(5,2) NOT NULL DEFAULT 0.00,
  `owner_id` int(10) unsigned NOT NULL,
  `time_zone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Kolkata',
  `fy_start_month` tinyint(4) NOT NULL DEFAULT 1,
  `accounting_method` enum('fifo','lifo','avco') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fifo',
  `default_sales_discount` decimal(5,2) DEFAULT NULL,
  `sell_price_tax` enum('includes','excludes') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'includes',
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_product_expiry` tinyint(1) NOT NULL DEFAULT 0,
  `expiry_type` enum('add_expiry','add_manufacturing') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'add_expiry',
  `on_product_expiry` enum('keep_selling','stop_selling','auto_delete') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'keep_selling',
  `stop_selling_before` int(11) NOT NULL COMMENT 'Stop selling expied item n days before expiry',
  `enable_tooltip` tinyint(1) NOT NULL DEFAULT 1,
  `purchase_in_diff_currency` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Allow purchase to be in different currency then the business currency',
  `purchase_currency_id` int(10) unsigned DEFAULT NULL,
  `p_exchange_rate` decimal(20,3) NOT NULL DEFAULT 1.000,
  `transaction_edit_days` int(10) unsigned NOT NULL DEFAULT 30,
  `stock_expiry_alert_days` int(10) unsigned NOT NULL DEFAULT 30,
  `keyboard_shortcuts` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pos_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `essentials_settings` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manufacturing_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_api_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_skipped_orders` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_wh_oc_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_wh_ou_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_wh_od_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_wh_or_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weighing_scale_setting` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'used to store the configuration of weighing scale',
  `enable_brand` tinyint(1) NOT NULL DEFAULT 1,
  `enable_category` tinyint(1) NOT NULL DEFAULT 1,
  `enable_sub_category` tinyint(1) NOT NULL DEFAULT 1,
  `enable_price_tax` tinyint(1) NOT NULL DEFAULT 1,
  `enable_purchase_status` tinyint(1) DEFAULT 1,
  `enable_lot_number` tinyint(1) NOT NULL DEFAULT 0,
  `default_unit` int(11) DEFAULT NULL,
  `enable_sub_units` tinyint(1) NOT NULL DEFAULT 0,
  `enable_racks` tinyint(1) NOT NULL DEFAULT 0,
  `enable_row` tinyint(1) NOT NULL DEFAULT 0,
  `enable_position` tinyint(1) NOT NULL DEFAULT 0,
  `enable_editing_product_from_purchase` tinyint(1) NOT NULL DEFAULT 1,
  `sales_cmsn_agnt` enum('logged_in_user','user','cmsn_agnt') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_addition_method` tinyint(1) NOT NULL DEFAULT 1,
  `enable_inline_tax` tinyint(1) NOT NULL DEFAULT 1,
  `currency_symbol_placement` enum('before','after') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'before',
  `enabled_modules` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'm/d/Y',
  `time_format` enum('12','24') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '24',
  `ref_no_prefixes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_color` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `repair_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_rp` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `rp_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `amount_for_unit_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_order_total_for_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `max_rp_per_order` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `redeem_amount_per_unit_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_order_total_for_redeem` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_redeem_point` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `max_redeem_point` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `rp_expiry_period` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `rp_expiry_type` enum('month','year') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'year' COMMENT 'rp is the short form of reward points',
  `email_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sms_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_labels` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `common_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_owner_id_foreign` (`owner_id`),
  KEY `business_currency_id_foreign` (`currency_id`),
  KEY `business_default_sales_tax_foreign` (`default_sales_tax`),
  CONSTRAINT `business_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `business_default_sales_tax_foreign` FOREIGN KEY (`default_sales_tax`) REFERENCES `tax_rates` (`id`),
  CONSTRAINT `business_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business` WRITE;
/*!40000 ALTER TABLE `business` DISABLE KEYS */;
INSERT INTO `business` VALUES (1,'GROUPWsidesign',94,'2021-10-30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,1,'America/Lima',1,'fifo',0.00,'includes','1635622898_Diseño sin título (1).png','Ar00',0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"cmmsn_calculation_type\":\"invoice_value\",\"amount_rounding_method\":null,\"enable_sales_order\":\"1\",\"razor_pay_key_id\":null,\"razor_pay_key_secret\":null,\"stripe_public_key\":null,\"stripe_secret_key\":null,\"is_pos_subtotal_editable\":\"1\",\"enable_transaction_date\":\"1\",\"show_invoice_scheme\":\"1\",\"show_invoice_layout\":\"1\",\"show_pricing_on_product_sugesstion\":\"1\",\"cash_denominations\":null,\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',1,1,1,1,1,0,3,0,1,1,1,1,'user',1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"account\",\"modifiers\",\"service_staff\",\"subscription\",\"types_of_service\"]','d-m-Y','24','{\"purchase\":\"PO\",\"purchase_return\":null,\"purchase_order\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null,\"draft\":null,\"sales_order\":null}','black',NULL,NULL,1,'CLIENTE FRECUENTE',1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"sms_service\":\"other\",\"nexmo_key\":null,\"nexmo_secret\":null,\"nexmo_from\":null,\"twilio_sid\":null,\"twilio_token\":null,\"twilio_from\":null,\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"header_1\":null,\"header_val_1\":null,\"header_2\":null,\"header_val_2\":null,\"header_3\":null,\"header_val_3\":null,\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null,\"custom_pay_4\":null,\"custom_pay_5\":null,\"custom_pay_6\":null,\"custom_pay_7\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null,\"custom_field_7\":null,\"custom_field_8\":null,\"custom_field_9\":null,\"custom_field_10\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase_shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"shipping\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null,\"custom_field_5\":null,\"custom_field_6\":null}}','{\"enable_product_warranty\":\"1\",\"default_credit_limit\":null,\"default_datatable_page_entries\":\"50\"}',1,'2021-10-31 01:11:38','2021-11-29 19:36:20'),(2,'DEMO1',2,'2021-10-30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,2,'America/Guayaquil',1,'fifo',NULL,'includes','1635626926_Baby.tux-800x800.png',NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"recent_product_quantity\":\"f2\",\"add_new_product\":\"f4\"}}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,1,1,1,1,0,NULL,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24','{\"purchase\":\"PO\",\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"business_location\":\"BL\"}',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year',NULL,NULL,NULL,NULL,1,'2021-10-31 02:18:46','2021-10-31 02:18:46'),(3,'Aral trendy',94,'2021-11-02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,3,'America/Bogota',1,'fifo',NULL,'includes','1635945568_FB_IMG_1635945156454.jpg',NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"recent_product_quantity\":\"f2\",\"add_new_product\":\"f4\"}}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,1,1,1,1,0,NULL,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24','{\"purchase\":\"PO\",\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"business_location\":\"BL\"}',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year',NULL,NULL,NULL,NULL,1,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(4,'mi negocio',24,'2021-11-19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25.00,4,'America/Adak',1,'fifo',NULL,'includes',NULL,NULL,0,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"recent_product_quantity\":\"f2\",\"add_new_product\":\"f4\"}}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',1,1,1,1,1,0,NULL,0,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\"]','m/d/Y','24','{\"purchase\":\"PO\",\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"business_location\":\"BL\"}',NULL,NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year',NULL,NULL,NULL,NULL,1,'2021-11-20 01:16:31','2021-11-20 01:16:31');
/*!40000 ALTER TABLE `business` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landmark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_scheme_id` int(10) unsigned NOT NULL,
  `invoice_layout_id` int(10) unsigned NOT NULL,
  `sale_invoice_layout_id` int(11) DEFAULT NULL,
  `selling_price_group_id` int(11) DEFAULT NULL,
  `print_receipt_on_invoice` tinyint(1) DEFAULT 1,
  `receipt_printer_type` enum('browser','printer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'browser',
  `printer_id` int(11) DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternate_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured_products` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `default_payment_accounts` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_locations_business_id_index` (`business_id`),
  KEY `business_locations_invoice_scheme_id_foreign` (`invoice_scheme_id`),
  KEY `business_locations_invoice_layout_id_foreign` (`invoice_layout_id`),
  KEY `business_locations_sale_invoice_layout_id_index` (`sale_invoice_layout_id`),
  KEY `business_locations_selling_price_group_id_index` (`selling_price_group_id`),
  KEY `business_locations_receipt_printer_type_index` (`receipt_printer_type`),
  KEY `business_locations_printer_id_index` (`printer_id`),
  CONSTRAINT `business_locations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `business_locations_invoice_layout_id_foreign` FOREIGN KEY (`invoice_layout_id`) REFERENCES `invoice_layouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `business_locations_invoice_scheme_id_foreign` FOREIGN KEY (`invoice_scheme_id`) REFERENCES `invoice_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business_locations` WRITE;
/*!40000 ALTER TABLE `business_locations` DISABLE KEYS */;
INSERT INTO `business_locations` VALUES (1,1,'BL0001','Nacional Code','Medellin - Colombia','colombia','Medellin','Antioquia','050001',1,1,1,NULL,1,'browser',NULL,'+57 350 493 1577','+57 350 493 1577',NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\",\"account\":null},\"card\":{\"is_enabled\":\"1\",\"account\":null},\"cheque\":{\"is_enabled\":\"1\",\"account\":null},\"bank_transfer\":{\"is_enabled\":\"1\",\"account\":null},\"other\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_1\":{\"account\":null},\"custom_pay_2\":{\"account\":null},\"custom_pay_3\":{\"account\":null},\"custom_pay_4\":{\"account\":null},\"custom_pay_5\":{\"account\":null},\"custom_pay_6\":{\"account\":null},\"custom_pay_7\":{\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2021-10-31 01:11:39','2021-10-30 20:29:17'),(2,2,'BL0001','DEMO1','JCROMERO09@HOTMAIL.COM','ECUADOR','GYE','FYE','5934',2,2,2,NULL,1,'browser',NULL,'','','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(3,3,'BL0001','Aral trendy','LA VICTORIA','Perú','Lima','Lima','1415',3,3,3,NULL,1,'browser',NULL,'921210381','','','https://aral-trendy.com',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(4,1,'BL0002','FRANCIS MOTO PARTS',NULL,'Republica Dominicana','SAN JUAN DE LA MAGUANA','JUAN DE HERRERA','00000',1,1,1,0,1,'browser',NULL,'8090006666',NULL,NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\",\"account\":null},\"card\":{\"is_enabled\":\"1\",\"account\":null},\"cheque\":{\"is_enabled\":\"1\",\"account\":null},\"bank_transfer\":{\"is_enabled\":\"1\",\"account\":null},\"other\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_1\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_2\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_3\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_4\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_5\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_6\":{\"is_enabled\":\"1\",\"account\":null},\"custom_pay_7\":{\"is_enabled\":\"1\",\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2021-11-03 22:02:18','2021-11-03 22:02:18'),(5,4,'BL0001','mi negocio','1234','Chile','Santiago','San Bernardo','123456',4,4,4,NULL,1,'browser',NULL,'123456789','','','https://minegocio.cl',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null},\"custom_pay_4\":{\"is_enabled\":1,\"account\":null},\"custom_pay_5\":{\"is_enabled\":1,\"account\":null},\"custom_pay_6\":{\"is_enabled\":1,\"account\":null},\"custom_pay_7\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2021-11-20 01:16:31','2021-11-20 01:16:31');
/*!40000 ALTER TABLE `business_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_register_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_register_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cash_register_id` int(10) unsigned NOT NULL,
  `amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `pay_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('debit','credit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_register_transactions_cash_register_id_foreign` (`cash_register_id`),
  KEY `cash_register_transactions_transaction_id_index` (`transaction_id`),
  KEY `cash_register_transactions_type_index` (`type`),
  KEY `cash_register_transactions_transaction_type_index` (`transaction_type`),
  CONSTRAINT `cash_register_transactions_cash_register_id_foreign` FOREIGN KEY (`cash_register_id`) REFERENCES `cash_registers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_register_transactions` WRITE;
/*!40000 ALTER TABLE `cash_register_transactions` DISABLE KEYS */;
INSERT INTO `cash_register_transactions` VALUES (1,1,1000.0000,'cash','credit','initial',NULL,'2021-10-30 14:42:03','2021-10-30 14:42:03'),(2,1,60.0000,'cash','credit','sell',5,'2021-10-30 20:17:32','2021-10-30 20:17:32'),(3,1,30.0000,'cash','credit','sell',6,'2021-10-30 20:21:54','2021-10-30 20:21:54'),(4,2,100.0000,'cash','credit','initial',NULL,'2021-10-30 20:29:29','2021-10-30 20:29:29'),(5,2,90.0000,'cash','credit','sell',7,'2021-10-30 20:29:49','2021-10-30 20:29:49'),(6,3,1200.0000,'cash','credit','initial',NULL,'2021-11-02 10:59:04','2021-11-02 10:59:04'),(7,3,30.0000,'cash','credit','sell',8,'2021-11-02 11:37:08','2021-11-02 11:37:08'),(8,3,30.0000,'card','credit','sell',9,'2021-11-02 11:37:36','2021-11-02 11:37:36'),(9,4,100.0000,'cash','credit','initial',NULL,'2021-11-02 11:43:06','2021-11-02 11:43:06'),(10,4,15.0000,'cash','credit','sell',12,'2021-11-02 12:13:55','2021-11-02 12:13:55'),(11,5,122222.0000,'cash','credit','initial',NULL,'2021-11-02 15:51:32','2021-11-02 15:51:32'),(12,6,500.0000,'cash','credit','initial',NULL,'2021-11-02 15:51:36','2021-11-02 15:51:36'),(13,5,15.0000,'cash','credit','sell',13,'2021-11-02 15:51:53','2021-11-02 15:51:53'),(14,5,60.0000,'cash','credit','sell',14,'2021-11-02 15:53:34','2021-11-02 15:53:34'),(15,5,15.0000,'cash','credit','sell',15,'2021-11-02 15:53:40','2021-11-02 15:53:40'),(16,5,15000.0000,'cash','credit','sell',20,'2021-11-02 18:59:13','2021-11-02 18:59:13'),(17,5,3835.0000,'cash','credit','sell',21,'2021-11-02 18:59:52','2021-11-02 18:59:52'),(18,5,3805.0000,'cash','credit','sell',22,'2021-11-02 19:00:22','2021-11-02 19:00:22'),(19,7,100.0000,'cash','credit','initial',NULL,'2021-11-02 19:00:44','2021-11-02 19:00:44'),(20,7,3790.0000,'cash','credit','sell',23,'2021-11-02 19:01:08','2021-11-02 19:01:08'),(21,7,1875.0000,'card','credit','sell',24,'2021-11-02 19:01:55','2021-11-02 19:01:55'),(22,7,1875.0000,'cash','credit','sell',24,'2021-11-02 19:03:36','2021-11-02 19:03:36'),(23,7,1875.0000,'card','debit','refund',24,'2021-11-02 19:03:36','2021-11-02 19:03:36'),(24,8,10.0000,'cash','credit','initial',NULL,'2021-11-02 19:17:58','2021-11-02 19:17:58'),(25,8,1910.0000,'cash','credit','sell',25,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(26,8,1925.0000,'card','credit','sell',26,'2021-11-03 00:10:05','2021-11-03 00:10:05'),(27,8,3790.0000,'cash','credit','sell',27,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(28,8,10.0000,'cash','credit','sell',28,'2021-11-03 11:53:00','2021-11-03 11:53:00'),(29,8,20.0000,'cash','credit','sell',29,'2021-11-03 14:29:20','2021-11-03 14:29:20'),(30,8,5.0000,'cash','credit','sell',30,'2021-11-03 15:22:58','2021-11-03 15:22:58'),(31,8,15.0000,'cash','credit','sell',32,'2021-11-03 21:52:02','2021-11-03 21:52:02'),(32,8,15.0000,'cash','credit','sell',33,'2021-11-03 21:52:50','2021-11-03 21:52:50'),(33,8,55.0000,'cash','credit','sell',36,'2021-11-03 22:33:30','2021-11-03 22:33:30'),(34,8,100.0000,'bank_transfer','credit','sell',36,'2021-11-03 22:33:30','2021-11-03 22:33:30'),(35,8,3.0000,'cash','credit','sell',38,'2021-11-04 10:39:17','2021-11-04 10:39:17'),(36,8,2.0000,'card','credit','sell',38,'2021-11-04 10:39:17','2021-11-04 10:39:17'),(37,9,5000.0000,'cash','credit','initial',NULL,'2021-11-04 10:40:26','2021-11-04 10:40:26'),(38,9,5.0000,'cash','credit','sell',39,'2021-11-04 10:40:35','2021-11-04 10:40:35'),(39,10,20.0000,'cash','credit','initial',NULL,'2021-11-04 12:46:07','2021-11-04 12:46:07'),(40,10,1925.0000,'cash','credit','sell',26,'2021-11-05 00:01:19','2021-11-05 00:01:19'),(41,10,1925.0000,'card','debit','refund',26,'2021-11-05 00:01:19','2021-11-05 00:01:19'),(42,10,155.0000,'cash','credit','sell',42,'2021-11-05 12:32:02','2021-11-05 12:32:02'),(43,10,155.0000,'cash','credit','sell',43,'2021-11-05 17:27:12','2021-11-05 17:27:12'),(44,10,620.0000,'cash','credit','sell',46,'2021-11-07 11:49:36','2021-11-07 11:49:36'),(45,10,310.0000,'cash','credit','sell',47,'2021-11-07 12:28:30','2021-11-07 12:28:30'),(46,10,155.0000,'cash','credit','sell',50,'2021-11-07 17:22:34','2021-11-07 17:22:34'),(47,10,155.0000,'cash','credit','sell',51,'2021-11-07 17:24:05','2021-11-07 17:24:05'),(48,10,465.0000,'cash','credit','sell',53,'2021-11-08 09:16:07','2021-11-08 09:16:07'),(49,10,310.0000,'cash','credit','sell',54,'2021-11-08 11:44:33','2021-11-08 11:44:33'),(50,11,100.0000,'cash','credit','initial',NULL,'2021-11-08 15:21:46','2021-11-08 15:21:46'),(51,11,5.0000,'cash','credit','sell',55,'2021-11-08 20:11:26','2021-11-08 20:11:26'),(52,11,5.0000,'cash','credit','sell',56,'2021-11-08 20:14:36','2021-11-08 20:14:36'),(53,11,15.0000,'cash','credit','sell',57,'2021-11-09 10:32:21','2021-11-09 10:32:21'),(54,11,1875.0000,'cash','credit','sell',58,'2021-11-10 08:08:05','2021-11-10 08:08:05'),(55,11,3765.0000,'cash','credit','sell',60,'2021-11-10 14:06:53','2021-11-10 14:06:53'),(57,12,10.0000,'cash','credit','initial',NULL,'2021-11-11 08:31:35','2021-11-11 08:31:35'),(59,12,25312.5000,'cash','credit','sell',63,'2021-11-15 07:11:46','2021-11-15 07:11:46'),(60,12,1875.0000,'cash','credit','sell',66,'2021-11-15 10:07:00','2021-11-15 10:07:00'),(61,12,15.0000,'cash','credit','sell',67,'2021-11-15 10:10:33','2021-11-15 10:10:33'),(62,12,15.0000,'cash','credit','sell',69,'2021-11-15 10:11:47','2021-11-15 10:11:47'),(63,12,1890.0000,'cash','credit','sell',70,'2021-11-15 10:18:41','2021-11-15 10:18:41'),(64,12,3750.0000,'cash','credit','sell',73,'2021-11-15 22:29:46','2021-11-15 22:29:46'),(65,12,1876.0000,'cash','credit','sell',74,'2021-11-16 06:40:35','2021-11-16 06:40:35'),(66,12,1875.0000,'cash','credit','sell',75,'2021-11-17 11:32:54','2021-11-17 11:32:54'),(67,12,23437.5000,'cash','credit','sell',76,'2021-11-17 11:37:09','2021-11-17 11:37:09'),(68,12,93750.0000,'cash','credit','sell',78,'2021-11-17 20:54:16','2021-11-17 20:54:16'),(69,12,1875.0000,'cash','credit','sell',79,'2021-11-18 15:59:23','2021-11-18 15:59:23'),(70,13,50.0000,'cash','credit','initial',NULL,'2021-11-23 20:39:04','2021-11-23 20:39:04'),(71,13,325.0000,'cash','credit','sell',83,'2021-11-23 20:41:14','2021-11-23 20:41:14'),(72,14,50.0000,'cash','credit','initial',NULL,'2021-11-23 20:44:33','2021-11-23 20:44:33'),(73,15,50.0000,'cash','credit','initial',NULL,'2021-11-23 21:57:07','2021-11-23 21:57:07'),(74,16,50.0000,'cash','credit','initial',NULL,'2021-11-23 22:03:23','2021-11-23 22:03:23'),(75,16,1240.0000,'cash','credit','sell',87,'2021-11-23 22:04:19','2021-11-23 22:04:19'),(76,16,155.0000,'cash','credit','sell',88,'2021-11-23 22:04:33','2021-11-23 22:04:33'),(77,16,310.0000,'cash','credit','sell',88,'2021-11-23 22:05:10','2021-11-23 22:05:10'),(78,17,50.0000,'cash','credit','initial',NULL,'2021-11-23 23:46:09','2021-11-23 23:46:09'),(79,18,100000.0000,'cash','credit','initial',NULL,'2021-11-25 08:45:06','2021-11-25 08:45:06'),(80,18,25327.5000,'cash','credit','sell',90,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(81,18,70357.5000,'cash','credit','sell',91,'2021-11-26 12:44:47','2021-11-26 12:44:47'),(82,18,15.0000,'cash','credit','sell',93,'2021-11-26 15:17:50','2021-11-26 15:17:50'),(83,18,15.0000,'cash','credit','sell',95,'2021-11-27 08:47:33','2021-11-27 08:47:33'),(84,18,3750.0000,'card','credit','sell',96,'2021-11-27 15:04:48','2021-11-27 15:04:48'),(85,18,1875.0000,'cash','credit','sell',97,'2021-11-27 15:05:10','2021-11-27 15:05:10'),(86,18,38437.5000,'cash','credit','sell',98,'2021-11-27 15:36:40','2021-11-27 15:36:40'),(87,18,25312.5000,'card','credit','sell',99,'2021-11-27 17:31:38','2021-11-27 17:31:38'),(88,19,100.0000,'cash','credit','initial',NULL,'2021-11-28 10:49:09','2021-11-28 10:49:09'),(89,19,60.0000,'cash','credit','sell',100,'2021-11-28 10:52:49','2021-11-28 10:52:49'),(90,20,10000.0000,'cash','credit','initial',NULL,'2021-11-29 12:54:56','2021-11-29 12:54:56'),(91,20,23452.5000,'cash','credit','sell',103,'2021-11-29 12:56:08','2021-11-29 12:56:08'),(92,20,25312.5000,'cash','credit','sell',105,'2021-11-29 14:07:50','2021-11-29 14:07:50'),(93,20,1875.0000,'cash','credit','sell',106,'2021-11-29 14:08:19','2021-11-29 14:08:19'),(94,20,5640.0000,'cash','credit','sell',109,'2021-11-30 12:29:04','2021-11-30 12:29:04');
/*!40000 ALTER TABLE `cash_register_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status` enum('close','open') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `closed_at` datetime DEFAULT NULL,
  `closing_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `total_card_slips` int(11) NOT NULL DEFAULT 0,
  `total_cheques` int(11) NOT NULL DEFAULT 0,
  `denominations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closing_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_registers_business_id_foreign` (`business_id`),
  KEY `cash_registers_user_id_foreign` (`user_id`),
  KEY `cash_registers_location_id_index` (`location_id`),
  CONSTRAINT `cash_registers_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_registers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_registers` WRITE;
/*!40000 ALTER TABLE `cash_registers` DISABLE KEYS */;
INSERT INTO `cash_registers` VALUES (1,1,1,1,'close','2021-10-30 20:26:24',1090.0000,0,0,NULL,NULL,'2021-10-30 14:42:00','2021-10-30 20:26:24'),(2,1,1,1,'close','2021-10-30 20:30:42',190.0000,0,0,NULL,NULL,'2021-10-30 20:29:00','2021-10-30 20:30:42'),(3,1,1,1,'close','2021-11-02 11:39:33',1230.0000,1,0,NULL,NULL,'2021-11-02 10:59:00','2021-11-02 11:39:33'),(4,1,1,1,'close','2021-11-02 13:21:55',115.0000,0,0,NULL,NULL,'2021-11-02 11:43:00','2021-11-02 13:21:55'),(5,1,1,1,'close','2021-11-02 19:00:36',145452.0000,0,0,NULL,NULL,'2021-11-02 15:51:00','2021-11-02 19:00:36'),(6,1,1,1,'close','2021-11-02 19:00:36',145452.0000,0,0,NULL,NULL,'2021-11-02 15:51:00','2021-11-02 19:00:36'),(7,1,1,1,'close','2021-11-02 19:04:29',5765.0000,2,0,NULL,NULL,'2021-11-02 19:00:00','2021-11-02 19:04:29'),(8,1,1,1,'close','2021-11-04 10:40:03',5833.0000,2,0,NULL,NULL,'2021-11-02 19:17:00','2021-11-04 10:40:03'),(9,1,1,1,'close','2021-11-04 10:41:24',5005.0000,0,0,NULL,NULL,'2021-11-04 10:40:00','2021-11-04 10:41:24'),(10,1,4,1,'close','2021-11-08 11:45:07',4270.0000,1,0,NULL,NULL,'2021-11-04 12:46:00','2021-11-08 11:45:07'),(11,1,1,1,'close','2021-11-10 14:11:55',2590925.0000,0,0,NULL,NULL,'2021-11-08 15:21:00','2021-11-10 14:11:55'),(12,1,1,1,'close','2021-11-23 16:43:17',155681.0000,0,0,NULL,NULL,'2021-11-11 08:31:00','2021-11-23 16:43:17'),(13,1,4,1,'close','2021-11-23 20:42:08',375.0000,0,0,NULL,NULL,'2021-11-23 20:39:00','2021-11-23 20:42:08'),(14,1,4,5,'open',NULL,0.0000,0,0,NULL,NULL,'2021-11-23 20:44:00','2021-11-23 20:44:33'),(15,1,4,1,'close','2021-11-23 21:58:14',50.0000,0,0,NULL,NULL,'2021-11-23 21:57:00','2021-11-23 21:58:14'),(16,1,4,6,'close','2021-11-23 22:55:21',1755.0000,0,0,NULL,NULL,'2021-11-23 22:03:00','2021-11-23 22:55:21'),(17,1,4,6,'open',NULL,0.0000,0,0,NULL,NULL,'2021-11-23 23:46:00','2021-11-23 23:46:09'),(18,1,NULL,1,'close','2021-11-27 17:32:00',236027.5000,2,0,NULL,NULL,'2021-11-25 08:45:00','2021-11-27 17:32:00'),(19,1,1,1,'close','2021-11-29 11:50:15',160.0000,0,0,NULL,NULL,'2021-11-28 10:49:00','2021-11-29 11:50:15'),(20,1,1,1,'open',NULL,0.0000,0,0,NULL,NULL,'2021-11-29 12:54:00','2021-11-29 12:54:56');
/*!40000 ALTER TABLE `cash_registers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `short_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `woocommerce_cat_id` int(11) DEFAULT NULL,
  `category_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_business_id_foreign` (`business_id`),
  KEY `categories_created_by_foreign` (`created_by`),
  KEY `categories_parent_id_index` (`parent_id`),
  KEY `categories_woocommerce_cat_id_index` (`woocommerce_cat_id`),
  CONSTRAINT `categories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'GENERAL',1,'G001',0,1,NULL,'product',NULL,NULL,NULL,'2021-10-30 15:59:54','2021-10-30 15:59:54'),(2,'ESPECIAL',1,'ES001',0,1,NULL,'product',NULL,NULL,NULL,'2021-10-30 16:00:06','2021-10-30 16:00:06'),(3,'Lacteos',1,'00123',0,1,NULL,'product',NULL,NULL,NULL,'2021-11-18 16:11:48','2021-11-18 16:11:48');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categorizables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorizables` (
  `category_id` int(11) NOT NULL,
  `categorizable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categorizable_id` bigint(20) unsigned NOT NULL,
  KEY `categorizables_categorizable_type_categorizable_id_index` (`categorizable_type`,`categorizable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categorizables` WRITE;
/*!40000 ALTER TABLE `categorizables` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorizables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_business_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `tax_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line_1` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_line_2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landline` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternate_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_term_number` int(11) DEFAULT NULL,
  `pay_term_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit_limit` decimal(22,4) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `balance` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `total_rp` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `total_rp_used` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `total_rp_expired` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `shipping_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_details` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_export` tinyint(1) NOT NULL DEFAULT 0,
  `export_custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_custom_field_6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_group_id` int(11) DEFAULT NULL,
  `custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field6` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field7` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field8` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field9` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field10` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_business_id_foreign` (`business_id`),
  KEY `contacts_created_by_foreign` (`created_by`),
  KEY `contacts_type_index` (`type`),
  KEY `contacts_contact_status_index` (`contact_status`),
  CONSTRAINT `contacts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,1,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,1,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(2,2,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,2,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-31 02:18:46','2021-10-31 02:18:46'),(3,1,'customer',NULL,'demo1 demo',NULL,'demo1','demo',NULL,NULL,'CO0002','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'cec',NULL,'cece',NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 16:16:15','2021-10-30 16:16:15'),(4,1,'supplier','DEMO PROVEEDOR','',NULL,NULL,NULL,NULL,NULL,'0992144998001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'123434',NULL,NULL,NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 16:36:54','2021-10-30 16:36:54'),(5,1,'customer',NULL,'Juan Ordoñez',NULL,'Juan',NULL,'Ordoñez',NULL,'CO0004','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'426521564',NULL,NULL,30,'days',500.0000,1,0.0000,5,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 16:50:51','2021-11-02 16:50:57'),(6,1,'supplier','jaun','',NULL,NULL,NULL,NULL,'s8094248312@gmail.com','012121','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'(809) 424-8312',NULL,NULL,NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 18:57:03','2021-11-02 18:57:03'),(7,3,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,3,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(8,1,'supplier',NULL,'SR XXXX','SR','XXXX',NULL,NULL,NULL,'DC','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'8090006666',NULL,NULL,NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 22:27:57','2021-11-03 22:27:57'),(9,1,'supplier','Cinco','',NULL,NULL,NULL,NULL,NULL,'55555','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'123456','13541321','12354152',NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-05 22:38:27','2021-11-05 22:38:27'),(10,1,'customer',NULL,'SR DMS RDS ASD','SR','DMS','RDS','ASD',NULL,'56666','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'200000000000',NULL,NULL,NULL,NULL,NULL,1,0.0000,3765,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-10 14:05:33','2021-11-13 21:17:50'),(11,1,'customer',NULL,'',NULL,NULL,NULL,NULL,'erolan@gmail.com','12345678909','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'405317',NULL,NULL,NULL,NULL,NULL,1,0.0000,15,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:09:15','2021-11-15 10:10:33'),(12,4,'customer',NULL,'Walk-In Customer',NULL,NULL,NULL,NULL,NULL,'CO0001','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,0.0000,4,0.0000,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(13,1,'customer',NULL,'soyla soyla perezx guardian','soyla','soyla','perezx','guardian',NULL,'1994','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'000000',NULL,NULL,NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 11:29:22','2021-11-23 11:29:22'),(14,1,'supplier','alla','',NULL,NULL,NULL,NULL,NULL,'CO0011','active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0967472994',NULL,NULL,NULL,NULL,NULL,1,0.0000,0,0,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 21:54:28','2021-11-23 21:54:28');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thousand_separator` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `decimal_separator` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'Albania','Leke','ALL','Lek',',','.',NULL,NULL),(2,'America','Dollars','USD','$',',','.',NULL,NULL),(3,'Afghanistan','Afghanis','AF','؋',',','.',NULL,NULL),(4,'Argentina','Pesos','ARS','$',',','.',NULL,NULL),(5,'Aruba','Guilders','AWG','ƒ',',','.',NULL,NULL),(6,'Australia','Dollars','AUD','$',',','.',NULL,NULL),(7,'Azerbaijan','New Manats','AZ','ман',',','.',NULL,NULL),(8,'Bahamas','Dollars','BSD','$',',','.',NULL,NULL),(9,'Barbados','Dollars','BBD','$',',','.',NULL,NULL),(10,'Belarus','Rubles','BYR','p.',',','.',NULL,NULL),(11,'Belgium','Euro','EUR','€',',','.',NULL,NULL),(12,'Beliz','Dollars','BZD','BZ$',',','.',NULL,NULL),(13,'Bermuda','Dollars','BMD','$',',','.',NULL,NULL),(14,'Bolivia','Bolivianos','BOB','$b',',','.',NULL,NULL),(15,'Bosnia and Herzegovina','Convertible Marka','BAM','KM',',','.',NULL,NULL),(16,'Botswana','Pula\'s','BWP','P',',','.',NULL,NULL),(17,'Bulgaria','Leva','BG','лв',',','.',NULL,NULL),(18,'Brazil','Reais','BRL','R$',',','.',NULL,NULL),(19,'Britain [United Kingdom]','Pounds','GBP','£',',','.',NULL,NULL),(20,'Brunei Darussalam','Dollars','BND','$',',','.',NULL,NULL),(21,'Cambodia','Riels','KHR','៛',',','.',NULL,NULL),(22,'Canada','Dollars','CAD','$',',','.',NULL,NULL),(23,'Cayman Islands','Dollars','KYD','$',',','.',NULL,NULL),(24,'Chile','Pesos','CLP','$',',','.',NULL,NULL),(25,'China','Yuan Renminbi','CNY','¥',',','.',NULL,NULL),(26,'Colombia','Pesos','COP','$',',','.',NULL,NULL),(27,'Costa Rica','Colón','CRC','₡',',','.',NULL,NULL),(28,'Croatia','Kuna','HRK','kn',',','.',NULL,NULL),(29,'Cuba','Pesos','CUP','₱',',','.',NULL,NULL),(30,'Cyprus','Euro','EUR','€','.',',',NULL,NULL),(31,'Czech Republic','Koruny','CZK','Kč',',','.',NULL,NULL),(32,'Denmark','Kroner','DKK','kr',',','.',NULL,NULL),(33,'Dominican Republic','Pesos','DOP ','RD$',',','.',NULL,NULL),(34,'East Caribbean','Dollars','XCD','$',',','.',NULL,NULL),(35,'Egypt','Pounds','EGP','£',',','.',NULL,NULL),(36,'El Salvador','Colones','SVC','$',',','.',NULL,NULL),(37,'England [United Kingdom]','Pounds','GBP','£',',','.',NULL,NULL),(38,'Euro','Euro','EUR','€','.',',',NULL,NULL),(39,'Falkland Islands','Pounds','FKP','£',',','.',NULL,NULL),(40,'Fiji','Dollars','FJD','$',',','.',NULL,NULL),(41,'France','Euro','EUR','€','.',',',NULL,NULL),(42,'Ghana','Cedis','GHS','¢',',','.',NULL,NULL),(43,'Gibraltar','Pounds','GIP','£',',','.',NULL,NULL),(44,'Greece','Euro','EUR','€','.',',',NULL,NULL),(45,'Guatemala','Quetzales','GTQ','Q',',','.',NULL,NULL),(46,'Guernsey','Pounds','GGP','£',',','.',NULL,NULL),(47,'Guyana','Dollars','GYD','$',',','.',NULL,NULL),(48,'Holland [Netherlands]','Euro','EUR','€','.',',',NULL,NULL),(49,'Honduras','Lempiras','HNL','L',',','.',NULL,NULL),(50,'Hong Kong','Dollars','HKD','$',',','.',NULL,NULL),(51,'Hungary','Forint','HUF','Ft',',','.',NULL,NULL),(52,'Iceland','Kronur','ISK','kr',',','.',NULL,NULL),(53,'India','Rupees','INR','₹',',','.',NULL,NULL),(54,'Indonesia','Rupiahs','IDR','Rp',',','.',NULL,NULL),(55,'Iran','Rials','IRR','﷼',',','.',NULL,NULL),(56,'Ireland','Euro','EUR','€','.',',',NULL,NULL),(57,'Isle of Man','Pounds','IMP','£',',','.',NULL,NULL),(58,'Israel','New Shekels','ILS','₪',',','.',NULL,NULL),(59,'Italy','Euro','EUR','€','.',',',NULL,NULL),(60,'Jamaica','Dollars','JMD','J$',',','.',NULL,NULL),(61,'Japan','Yen','JPY','¥',',','.',NULL,NULL),(62,'Jersey','Pounds','JEP','£',',','.',NULL,NULL),(63,'Kazakhstan','Tenge','KZT','лв',',','.',NULL,NULL),(64,'Korea [North]','Won','KPW','₩',',','.',NULL,NULL),(65,'Korea [South]','Won','KRW','₩',',','.',NULL,NULL),(66,'Kyrgyzstan','Soms','KGS','лв',',','.',NULL,NULL),(67,'Laos','Kips','LAK','₭',',','.',NULL,NULL),(68,'Latvia','Lati','LVL','Ls',',','.',NULL,NULL),(69,'Lebanon','Pounds','LBP','£',',','.',NULL,NULL),(70,'Liberia','Dollars','LRD','$',',','.',NULL,NULL),(71,'Liechtenstein','Switzerland Francs','CHF','CHF',',','.',NULL,NULL),(72,'Lithuania','Litai','LTL','Lt',',','.',NULL,NULL),(73,'Luxembourg','Euro','EUR','€','.',',',NULL,NULL),(74,'Macedonia','Denars','MKD','ден',',','.',NULL,NULL),(75,'Malaysia','Ringgits','MYR','RM',',','.',NULL,NULL),(76,'Malta','Euro','EUR','€','.',',',NULL,NULL),(77,'Mauritius','Rupees','MUR','₨',',','.',NULL,NULL),(78,'Mexico','Pesos','MXN','$',',','.',NULL,NULL),(79,'Mongolia','Tugriks','MNT','₮',',','.',NULL,NULL),(80,'Mozambique','Meticais','MZ','MT',',','.',NULL,NULL),(81,'Namibia','Dollars','NAD','$',',','.',NULL,NULL),(82,'Nepal','Rupees','NPR','₨',',','.',NULL,NULL),(83,'Netherlands Antilles','Guilders','ANG','ƒ',',','.',NULL,NULL),(84,'Netherlands','Euro','EUR','€','.',',',NULL,NULL),(85,'New Zealand','Dollars','NZD','$',',','.',NULL,NULL),(86,'Nicaragua','Cordobas','NIO','C$',',','.',NULL,NULL),(87,'Nigeria','Nairas','NGN','₦',',','.',NULL,NULL),(88,'North Korea','Won','KPW','₩',',','.',NULL,NULL),(89,'Norway','Krone','NOK','kr',',','.',NULL,NULL),(90,'Oman','Rials','OMR','﷼',',','.',NULL,NULL),(91,'Pakistan','Rupees','PKR','₨',',','.',NULL,NULL),(92,'Panama','Balboa','PAB','B/.',',','.',NULL,NULL),(93,'Paraguay','Guarani','PYG','Gs',',','.',NULL,NULL),(94,'Peru','Nuevos Soles','PE','S/.',',','.',NULL,NULL),(95,'Philippines','Pesos','PHP','Php',',','.',NULL,NULL),(96,'Poland','Zlotych','PL','zł',',','.',NULL,NULL),(97,'Qatar','Rials','QAR','﷼',',','.',NULL,NULL),(98,'Romania','New Lei','RO','lei',',','.',NULL,NULL),(99,'Russia','Rubles','RUB','руб',',','.',NULL,NULL),(100,'Saint Helena','Pounds','SHP','£',',','.',NULL,NULL),(101,'Saudi Arabia','Riyals','SAR','﷼',',','.',NULL,NULL),(102,'Serbia','Dinars','RSD','Дин.',',','.',NULL,NULL),(103,'Seychelles','Rupees','SCR','₨',',','.',NULL,NULL),(104,'Singapore','Dollars','SGD','$',',','.',NULL,NULL),(105,'Slovenia','Euro','EUR','€','.',',',NULL,NULL),(106,'Solomon Islands','Dollars','SBD','$',',','.',NULL,NULL),(107,'Somalia','Shillings','SOS','S',',','.',NULL,NULL),(108,'South Africa','Rand','ZAR','R',',','.',NULL,NULL),(109,'South Korea','Won','KRW','₩',',','.',NULL,NULL),(110,'Spain','Euro','EUR','€','.',',',NULL,NULL),(111,'Sri Lanka','Rupees','LKR','₨',',','.',NULL,NULL),(112,'Sweden','Kronor','SEK','kr',',','.',NULL,NULL),(113,'Switzerland','Francs','CHF','CHF',',','.',NULL,NULL),(114,'Suriname','Dollars','SRD','$',',','.',NULL,NULL),(115,'Syria','Pounds','SYP','£',',','.',NULL,NULL),(116,'Taiwan','New Dollars','TWD','NT$',',','.',NULL,NULL),(117,'Thailand','Baht','THB','฿',',','.',NULL,NULL),(118,'Trinidad and Tobago','Dollars','TTD','TT$',',','.',NULL,NULL),(119,'Turkey','Lira','TRY','TL',',','.',NULL,NULL),(120,'Turkey','Liras','TRL','£',',','.',NULL,NULL),(121,'Tuvalu','Dollars','TVD','$',',','.',NULL,NULL),(122,'Ukraine','Hryvnia','UAH','₴',',','.',NULL,NULL),(123,'United Kingdom','Pounds','GBP','£',',','.',NULL,NULL),(124,'United States of America','Dollars','USD','$',',','.',NULL,NULL),(125,'Uruguay','Pesos','UYU','$U',',','.',NULL,NULL),(126,'Uzbekistan','Sums','UZS','лв',',','.',NULL,NULL),(127,'Vatican City','Euro','EUR','€','.',',',NULL,NULL),(128,'Venezuela','Bolivares Fuertes','VEF','Bs',',','.',NULL,NULL),(129,'Vietnam','Dong','VND','₫',',','.',NULL,NULL),(130,'Yemen','Rials','YER','﷼',',','.',NULL,NULL),(131,'Zimbabwe','Zimbabwe Dollars','ZWD','Z$',',','.',NULL,NULL),(132,'Iraq','Iraqi dinar','IQD','د.ع',',','.',NULL,NULL),(133,'Kenya','Kenyan shilling','KES','KSh',',','.',NULL,NULL),(134,'Bangladesh','Taka','BDT','৳',',','.',NULL,NULL),(135,'Algerie','Algerian dinar','DZD','د.ج',' ','.',NULL,NULL),(136,'United Arab Emirates','United Arab Emirates dirham','AED','د.إ',',','.',NULL,NULL),(137,'Uganda','Uganda shillings','UGX','USh',',','.',NULL,NULL),(138,'Tanzania','Tanzanian shilling','TZS','TSh',',','.',NULL,NULL),(139,'Angola','Kwanza','AOA','Kz',',','.',NULL,NULL),(140,'Kuwait','Kuwaiti dinar','KWD','KD',',','.',NULL,NULL),(141,'Bahrain','Bahraini dinar','BHD','BD',',','.',NULL,NULL);
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(5,2) NOT NULL,
  `price_calculation_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'percentage',
  `selling_price_group_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_groups_business_id_foreign` (`business_id`),
  KEY `customer_groups_created_by_index` (`created_by`),
  KEY `customer_groups_price_calculation_type_index` (`price_calculation_type`),
  KEY `customer_groups_selling_price_group_id_index` (`selling_price_group_id`),
  CONSTRAINT `customer_groups_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customer_groups` WRITE;
/*!40000 ALTER TABLE `customer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `dashboard_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_configurations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `created_by` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configuration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_configurations_business_id_foreign` (`business_id`),
  CONSTRAINT `dashboard_configurations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `dashboard_configurations` WRITE;
/*!40000 ALTER TABLE `dashboard_configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_configurations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discount_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discount_variations` (
  `discount_id` int(11) NOT NULL,
  `variation_id` int(11) NOT NULL,
  KEY `discount_variations_discount_id_index` (`discount_id`),
  KEY `discount_variations_variation_id_index` (`variation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discount_variations` WRITE;
/*!40000 ALTER TABLE `discount_variations` DISABLE KEYS */;
/*!40000 ALTER TABLE `discount_variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `discount_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `spg` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Applicable in specified selling price group only. Use of applicable_in_spg column is discontinued',
  `applicable_in_cg` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discounts_business_id_index` (`business_id`),
  KEY `discounts_brand_id_index` (`brand_id`),
  KEY `discounts_category_id_index` (`category_id`),
  KEY `discounts_location_id_index` (`location_id`),
  KEY `discounts_priority_index` (`priority`),
  KEY `discounts_spg_index` (`spg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `document_and_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_and_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `notable_id` int(11) NOT NULL,
  `notable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `heading` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `document_and_notes_business_id_index` (`business_id`),
  KEY `document_and_notes_notable_id_index` (`notable_id`),
  KEY `document_and_notes_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `document_and_notes` WRITE;
/*!40000 ALTER TABLE `document_and_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_and_notes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_allowances_and_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_allowances_and_deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('allowance','deduction') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(22,4) NOT NULL,
  `amount_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `applicable_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_allowances_and_deductions_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_allowances_and_deductions` WRITE;
/*!40000 ALTER TABLE `essentials_allowances_and_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_allowances_and_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `clock_in_time` datetime DEFAULT NULL,
  `clock_out_time` datetime DEFAULT NULL,
  `essentials_shift_id` int(11) DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clock_in_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clock_out_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clock_in_location` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clock_out_location` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_attendances_user_id_index` (`user_id`),
  KEY `essentials_attendances_business_id_index` (`business_id`),
  KEY `essentials_attendances_essentials_shift_id_index` (`essentials_shift_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_attendances` WRITE;
/*!40000 ALTER TABLE `essentials_attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_attendances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_document_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_document_shares` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `value_type` enum('user','role') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_document_shares_document_id_index` (`document_id`),
  KEY `essentials_document_shares_value_type_index` (`value_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_document_shares` WRITE;
/*!40000 ALTER TABLE `essentials_document_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_document_shares` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_documents` WRITE;
/*!40000 ALTER TABLE `essentials_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_holidays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `business_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_holidays_business_id_index` (`business_id`),
  KEY `essentials_holidays_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_holidays` WRITE;
/*!40000 ALTER TABLE `essentials_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_holidays` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_kb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_kb` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` bigint(20) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kb_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL COMMENT 'id from essentials_kb table',
  `share_with` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'public, private, only_with',
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_kb_business_id_index` (`business_id`),
  KEY `essentials_kb_parent_id_index` (`parent_id`),
  KEY `essentials_kb_created_by_index` (`created_by`),
  CONSTRAINT `essentials_kb_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `essentials_kb` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_kb` WRITE;
/*!40000 ALTER TABLE `essentials_kb` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_kb` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_kb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_kb_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kb_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_kb_users_kb_id_index` (`kb_id`),
  KEY `essentials_kb_users_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_kb_users` WRITE;
/*!40000 ALTER TABLE `essentials_kb_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_kb_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_leave_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `leave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_leave_count` int(11) DEFAULT NULL,
  `leave_count_interval` enum('month','year') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_leave_types_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_leave_types` WRITE;
/*!40000 ALTER TABLE `essentials_leave_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_leave_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_leaves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `essentials_leave_type_id` int(11) DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_leaves_essentials_leave_type_id_index` (`essentials_leave_type_id`),
  KEY `essentials_leaves_business_id_index` (`business_id`),
  KEY `essentials_leaves_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_leaves` WRITE;
/*!40000 ALTER TABLE `essentials_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_leaves` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_messages_business_id_index` (`business_id`),
  KEY `essentials_messages_user_id_index` (`user_id`),
  KEY `essentials_messages_location_id_index` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_messages` WRITE;
/*!40000 ALTER TABLE `essentials_messages` DISABLE KEYS */;
INSERT INTO `essentials_messages` VALUES (1,2,2,'MENSAJE DE PRUEBA',2,'2021-10-30 15:54:19','2021-10-30 15:54:19'),(2,1,1,'aaaaaaaaaaa',1,'2021-11-02 12:47:37','2021-11-02 12:47:37');
/*!40000 ALTER TABLE `essentials_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_reminders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `end_time` time DEFAULT NULL,
  `repeat` enum('one_time','every_day','every_week','every_month') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_reminders_business_id_index` (`business_id`),
  KEY `essentials_reminders_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_reminders` WRITE;
/*!40000 ALTER TABLE `essentials_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_reminders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_shifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('fixed_shift','flexible_shift') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed_shift',
  `business_id` int(11) NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `holidays` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_shifts_type_index` (`type`),
  KEY `essentials_shifts_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_shifts` WRITE;
/*!40000 ALTER TABLE `essentials_shifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_shifts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_to_dos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_to_dos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `task` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `task_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimated_hours` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_to_dos_status_index` (`status`),
  KEY `essentials_to_dos_priority_index` (`priority`),
  KEY `essentials_to_dos_created_by_index` (`created_by`),
  KEY `essentials_to_dos_business_id_index` (`business_id`),
  KEY `essentials_to_dos_task_id_index` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_to_dos` WRITE;
/*!40000 ALTER TABLE `essentials_to_dos` DISABLE KEYS */;
INSERT INTO `essentials_to_dos` VALUES (1,1,'Pegado','2021-11-13 11:25:00','2021-11-13 21:24:00','2021/0001','<p>321</p>','new','3','medium',1,'2021-11-13 11:26:47','2021-11-13 11:26:47'),(2,1,'Pegado','2021-11-13 11:25:00','2021-11-13 21:24:00','2021/0002','<p>321</p>','new','3','medium',1,'2021-11-13 11:27:01','2021-11-13 11:27:01');
/*!40000 ALTER TABLE `essentials_to_dos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_todo_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_todo_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_id` int(11) NOT NULL,
  `comment_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_todo_comments_task_id_index` (`task_id`),
  KEY `essentials_todo_comments_comment_by_index` (`comment_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_todo_comments` WRITE;
/*!40000 ALTER TABLE `essentials_todo_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_todo_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_todos_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_todos_users` (
  `todo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_todos_users` WRITE;
/*!40000 ALTER TABLE `essentials_todos_users` DISABLE KEYS */;
INSERT INTO `essentials_todos_users` VALUES (1,1),(2,1);
/*!40000 ALTER TABLE `essentials_todos_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_allowance_and_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_user_allowance_and_deductions` (
  `user_id` int(11) NOT NULL,
  `allowance_deduction_id` int(11) NOT NULL,
  KEY `essentials_user_allowance_and_deductions_user_id_index` (`user_id`),
  KEY `allow_deduct_index` (`allowance_deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_allowance_and_deductions` WRITE;
/*!40000 ALTER TABLE `essentials_user_allowance_and_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_user_allowance_and_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_user_shifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `essentials_shift_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_user_shifts_user_id_index` (`user_id`),
  KEY `essentials_user_shifts_essentials_shift_id_index` (`essentials_shift_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_shifts` WRITE;
/*!40000 ALTER TABLE `essentials_user_shifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_user_shifts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_categories_business_id_foreign` (`business_id`),
  CONSTRAINT `expense_categories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_sub_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_sub_taxes` (
  `group_tax_id` int(10) unsigned NOT NULL,
  `tax_id` int(10) unsigned NOT NULL,
  KEY `group_sub_taxes_group_tax_id_foreign` (`group_tax_id`),
  KEY `group_sub_taxes_tax_id_foreign` (`tax_id`),
  CONSTRAINT `group_sub_taxes_group_tax_id_foreign` FOREIGN KEY (`group_tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_sub_taxes_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_sub_taxes` WRITE;
/*!40000 ALTER TABLE `group_sub_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_sub_taxes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_layouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotation_no_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading_not_paid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading_paid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotation_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_total_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `round_off_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_due_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_client_id` tinyint(1) NOT NULL DEFAULT 0,
  `client_id_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_tax_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_time_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_time` tinyint(1) NOT NULL DEFAULT 1,
  `show_brand` tinyint(1) NOT NULL DEFAULT 0,
  `show_sku` tinyint(1) NOT NULL DEFAULT 1,
  `show_cat_code` tinyint(1) NOT NULL DEFAULT 1,
  `show_expiry` tinyint(1) NOT NULL DEFAULT 0,
  `show_lot` tinyint(1) NOT NULL DEFAULT 0,
  `show_image` tinyint(1) NOT NULL DEFAULT 0,
  `show_sale_description` tinyint(1) NOT NULL DEFAULT 0,
  `sales_person_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_sales_person` tinyint(1) NOT NULL DEFAULT 0,
  `table_product_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_qty_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_unit_price_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_subtotal_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cat_code_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_logo` tinyint(1) NOT NULL DEFAULT 0,
  `show_business_name` tinyint(1) NOT NULL DEFAULT 0,
  `show_location_name` tinyint(1) NOT NULL DEFAULT 1,
  `show_landmark` tinyint(1) NOT NULL DEFAULT 1,
  `show_city` tinyint(1) NOT NULL DEFAULT 1,
  `show_state` tinyint(1) NOT NULL DEFAULT 1,
  `show_zip_code` tinyint(1) NOT NULL DEFAULT 1,
  `show_country` tinyint(1) NOT NULL DEFAULT 1,
  `show_mobile_number` tinyint(1) NOT NULL DEFAULT 1,
  `show_alternate_number` tinyint(1) NOT NULL DEFAULT 0,
  `show_email` tinyint(1) NOT NULL DEFAULT 0,
  `show_tax_1` tinyint(1) NOT NULL DEFAULT 1,
  `show_tax_2` tinyint(1) NOT NULL DEFAULT 0,
  `show_barcode` tinyint(1) NOT NULL DEFAULT 0,
  `show_payments` tinyint(1) NOT NULL DEFAULT 0,
  `show_customer` tinyint(1) NOT NULL DEFAULT 0,
  `customer_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commission_agent_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_commission_agent` tinyint(1) NOT NULL DEFAULT 0,
  `show_reward_point` tinyint(1) NOT NULL DEFAULT 0,
  `highlight_color` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module_info` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `common_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `business_id` int(10) unsigned NOT NULL,
  `show_qr_code` tinyint(1) NOT NULL DEFAULT 0,
  `qr_code_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `design` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT 'classic',
  `cn_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'cn = credit note',
  `cn_no_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cn_amount_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_tax_headings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_previous_bal` tinyint(1) NOT NULL DEFAULT 0,
  `prev_bal_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_layouts_business_id_foreign` (`business_id`),
  CONSTRAINT `invoice_layouts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_layouts` WRITE;
/*!40000 ALTER TABLE `invoice_layouts` DISABLE KEYS */;
INSERT INTO `invoice_layouts` VALUES (1,'Default',NULL,'Invoice No.',NULL,'Comprobante',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',1,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,'1637167017_logo cuadrado.png',0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','<p>Gracias por tu compra</p>','{\"types_of_service\":{\"types_of_service_label\":null},\"service_staff\":{\"service_staff_label\":null},\"repair\":{\"repair_status_label\":null,\"repair_warranty_label\":null,\"brand_label\":null,\"device_label\":null,\"model_no_label\":null,\"serial_no_label\":null,\"defects_label\":null,\"repair_checklist_label\":null}}','{\"proforma_heading\":null,\"due_date_label\":null,\"total_quantity_label\":null,\"item_discount_label\":null,\"num_to_word_format\":\"international\"}',1,1,1,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2021-10-31 01:11:39','2021-11-17 11:36:57'),(2,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,2,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(3,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,3,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(4,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',NULL,0,0,'#000000','',NULL,NULL,1,4,0,NULL,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2021-11-20 01:16:31','2021-11-20 01:16:31');
/*!40000 ALTER TABLE `invoice_layouts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_schemes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_schemes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheme_type` enum('blank','year') COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_number` int(11) DEFAULT NULL,
  `invoice_count` int(11) NOT NULL DEFAULT 0,
  `total_digits` int(11) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_schemes_business_id_foreign` (`business_id`),
  KEY `invoice_schemes_scheme_type_index` (`scheme_type`),
  CONSTRAINT `invoice_schemes_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_schemes` WRITE;
/*!40000 ALTER TABLE `invoice_schemes` DISABLE KEYS */;
INSERT INTO `invoice_schemes` VALUES (1,1,'Default','blank','',1,69,4,1,'2021-10-31 01:11:39','2021-11-30 12:29:04'),(2,2,'Default','blank','',1,0,4,1,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(3,3,'Default','blank','',1,0,4,1,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(4,4,'Default','blank','',1,0,4,1,'2021-11-20 01:16:31','2021-11-20 01:16:31');
/*!40000 ALTER TABLE `invoice_schemes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `woocommerce_media_id` int(11) DEFAULT NULL,
  `model_media_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_business_id_index` (`business_id`),
  KEY `media_uploaded_by_index` (`uploaded_by`),
  KEY `media_woocommerce_media_id_index` (`woocommerce_media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (1,1,'1635628273_263460378_Baby.tux-800x800.png',NULL,1,'App\\Variation',NULL,NULL,1,'2021-10-30 16:11:13','2021-11-23 11:32:37'),(2,1,'1635628273_1485302900_Baby.tux-800x800.png',NULL,1,'App\\Variation',NULL,NULL,2,'2021-10-30 16:11:13','2021-11-23 11:32:37'),(3,1,'1635628273_1621666699_Baby.tux-800x800.png',NULL,1,'App\\Variation',NULL,NULL,3,'2021-10-30 16:11:13','2021-11-23 11:32:37'),(4,1,'1635628273_918284559_Baby.tux-800x800.png',NULL,1,'App\\Variation',NULL,NULL,4,'2021-10-30 16:11:13','2021-11-23 11:32:37'),(5,1,'1635628273_1884937703_Baby.tux-800x800.png',NULL,1,'App\\Product',NULL,NULL,1,'2021-10-30 16:11:13','2021-11-23 11:32:37'),(6,1,'1635897200_42384357_download.jpg',NULL,1,'App\\Variation',NULL,NULL,6,'2021-11-02 18:53:20','2021-11-23 11:32:37'),(7,1,'1635897200_1161660285_download.jpg',NULL,1,'App\\Product',NULL,NULL,3,'2021-11-02 18:53:20','2021-11-23 11:32:37'),(8,1,'1635912143_959370127_IMG-20211026-WA0013.jpg',NULL,1,'App\\Product',NULL,NULL,4,'2021-11-02 23:02:23','2021-11-23 11:32:37');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mfg_ingredient_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mfg_ingredient_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mfg_ingredient_groups` WRITE;
/*!40000 ALTER TABLE `mfg_ingredient_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfg_ingredient_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mfg_recipe_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mfg_recipe_ingredients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mfg_recipe_id` int(10) unsigned NOT NULL,
  `variation_id` int(11) NOT NULL,
  `mfg_ingredient_group_id` int(11) DEFAULT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `waste_percent` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `sub_unit_id` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mfg_recipe_ingredients_mfg_recipe_id_foreign` (`mfg_recipe_id`),
  CONSTRAINT `mfg_recipe_ingredients_mfg_recipe_id_foreign` FOREIGN KEY (`mfg_recipe_id`) REFERENCES `mfg_recipes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mfg_recipe_ingredients` WRITE;
/*!40000 ALTER TABLE `mfg_recipe_ingredients` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfg_recipe_ingredients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mfg_recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mfg_recipes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `variation_id` int(11) NOT NULL,
  `instructions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `waste_percent` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ingredients_cost` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `extra_cost` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `production_cost_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'percentage',
  `total_quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `final_price` decimal(22,4) NOT NULL,
  `sub_unit_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mfg_recipes_product_id_index` (`product_id`),
  KEY `mfg_recipes_variation_id_index` (`variation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mfg_recipes` WRITE;
/*!40000 ALTER TABLE `mfg_recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfg_recipes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=371 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_06_01_000001_create_oauth_auth_codes_table',1),(4,'2016_06_01_000002_create_oauth_access_tokens_table',1),(5,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(6,'2016_06_01_000004_create_oauth_clients_table',1),(7,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(8,'2017_07_05_071953_create_currencies_table',1),(9,'2017_07_05_073658_create_business_table',1),(10,'2017_07_22_075923_add_business_id_users_table',1),(11,'2017_07_23_113209_create_brands_table',1),(12,'2017_07_26_083429_create_permission_tables',1),(13,'2017_07_26_110000_create_tax_rates_table',1),(14,'2017_07_26_122313_create_units_table',1),(15,'2017_07_27_075706_create_contacts_table',1),(16,'2017_08_04_071038_create_categories_table',1),(17,'2017_08_08_115903_create_products_table',1),(18,'2017_08_09_061616_create_variation_templates_table',1),(19,'2017_08_09_061638_create_variation_value_templates_table',1),(20,'2017_08_10_061146_create_product_variations_table',1),(21,'2017_08_10_061216_create_variations_table',1),(22,'2017_08_19_054827_create_transactions_table',1),(23,'2017_08_31_073533_create_purchase_lines_table',1),(24,'2017_10_15_064638_create_transaction_payments_table',1),(25,'2017_10_31_065621_add_default_sales_tax_to_business_table',1),(26,'2017_11_20_051930_create_table_group_sub_taxes',1),(27,'2017_11_20_063603_create_transaction_sell_lines',1),(28,'2017_11_21_064540_create_barcodes_table',1),(29,'2017_11_23_181237_create_invoice_schemes_table',1),(30,'2017_12_25_122822_create_business_locations_table',1),(31,'2017_12_25_160253_add_location_id_to_transactions_table',1),(32,'2017_12_25_163227_create_variation_location_details_table',1),(33,'2018_01_04_115627_create_sessions_table',1),(34,'2018_01_05_112817_create_invoice_layouts_table',1),(35,'2018_01_06_112303_add_invoice_scheme_id_and_invoice_layout_id_to_business_locations',1),(36,'2018_01_08_104124_create_expense_categories_table',1),(37,'2018_01_08_123327_modify_transactions_table_for_expenses',1),(38,'2018_01_09_111005_modify_payment_status_in_transactions_table',1),(39,'2018_01_09_111109_add_paid_on_column_to_transaction_payments_table',1),(40,'2018_01_25_172439_add_printer_related_fields_to_business_locations_table',1),(41,'2018_01_27_184322_create_printers_table',1),(42,'2018_01_30_181442_create_cash_registers_table',1),(43,'2018_01_31_125836_create_cash_register_transactions_table',1),(44,'2018_02_07_173326_modify_business_table',1),(45,'2018_02_08_105425_add_enable_product_expiry_column_to_business_table',1),(46,'2018_02_08_111027_add_expiry_period_and_expiry_period_type_columns_to_products_table',1),(47,'2018_02_08_131118_add_mfg_date_and_exp_date_purchase_lines_table',1),(48,'2018_02_08_155348_add_exchange_rate_to_transactions_table',1),(49,'2018_02_09_124945_modify_transaction_payments_table_for_contact_payments',1),(50,'2018_02_12_113640_create_transaction_sell_lines_purchase_lines_table',1),(51,'2018_02_12_114605_add_quantity_sold_in_purchase_lines_table',1),(52,'2018_02_13_183323_alter_decimal_fields_size',1),(53,'2018_02_14_161928_add_transaction_edit_days_to_business_table',1),(54,'2018_02_15_161032_add_document_column_to_transactions_table',1),(55,'2018_02_17_124709_add_more_options_to_invoice_layouts',1),(56,'2018_02_19_111517_add_keyboard_shortcut_column_to_business_table',1),(57,'2018_02_19_121537_stock_adjustment_move_to_transaction_table',1),(58,'2018_02_20_165505_add_is_direct_sale_column_to_transactions_table',1),(59,'2018_02_21_105329_create_system_table',1),(60,'2018_02_23_100549_version_1_2',1),(61,'2018_02_23_125648_add_enable_editing_sp_from_purchase_column_to_business_table',1),(62,'2018_02_26_103612_add_sales_commission_agent_column_to_business_table',1),(63,'2018_02_26_130519_modify_users_table_for_sales_cmmsn_agnt',1),(64,'2018_02_26_134500_add_commission_agent_to_transactions_table',1),(65,'2018_02_27_121422_add_item_addition_method_to_business_table',1),(66,'2018_02_27_170232_modify_transactions_table_for_stock_transfer',1),(67,'2018_03_05_153510_add_enable_inline_tax_column_to_business_table',1),(68,'2018_03_06_210206_modify_product_barcode_types',1),(69,'2018_03_13_181541_add_expiry_type_to_business_table',1),(70,'2018_03_16_113446_product_expiry_setting_for_business',1),(71,'2018_03_19_113601_add_business_settings_options',1),(72,'2018_03_26_125334_add_pos_settings_to_business_table',1),(73,'2018_03_26_165350_create_customer_groups_table',1),(74,'2018_03_27_122720_customer_group_related_changes_in_tables',1),(75,'2018_03_29_110138_change_tax_field_to_nullable_in_business_table',1),(76,'2018_03_29_115502_add_changes_for_sr_number_in_products_and_sale_lines_table',1),(77,'2018_03_29_134340_add_inline_discount_fields_in_purchase_lines',1),(78,'2018_03_31_140921_update_transactions_table_exchange_rate',1),(79,'2018_04_03_103037_add_contact_id_to_contacts_table',1),(80,'2018_04_03_122709_add_changes_to_invoice_layouts_table',1),(81,'2018_04_09_135320_change_exchage_rate_size_in_business_table',1),(82,'2018_04_17_123122_add_lot_number_to_business',1),(83,'2018_04_17_160845_add_product_racks_table',1),(84,'2018_04_20_182015_create_res_tables_table',1),(85,'2018_04_24_105246_restaurant_fields_in_transaction_table',1),(86,'2018_04_24_114149_add_enabled_modules_business_table',1),(87,'2018_04_24_133704_add_modules_fields_in_invoice_layout_table',1),(88,'2018_04_27_132653_quotation_related_change',1),(89,'2018_05_02_104439_add_date_format_and_time_format_to_business',1),(90,'2018_05_02_111939_add_sell_return_to_transaction_payments',1),(91,'2018_05_14_114027_add_rows_positions_for_products',1),(92,'2018_05_14_125223_add_weight_to_products_table',1),(93,'2018_05_14_164754_add_opening_stock_permission',1),(94,'2018_05_15_134729_add_design_to_invoice_layouts',1),(95,'2018_05_16_183307_add_tax_fields_invoice_layout',1),(96,'2018_05_18_191956_add_sell_return_to_transaction_table',1),(97,'2018_05_21_131349_add_custom_fileds_to_contacts_table',1),(98,'2018_05_21_131607_invoice_layout_fields_for_sell_return',1),(99,'2018_05_21_131949_add_custom_fileds_and_website_to_business_locations_table',1),(100,'2018_05_22_123527_create_reference_counts_table',1),(101,'2018_05_22_154540_add_ref_no_prefixes_column_to_business_table',1),(102,'2018_05_24_132620_add_ref_no_column_to_transaction_payments_table',1),(103,'2018_05_24_161026_add_location_id_column_to_business_location_table',1),(104,'2018_05_25_180603_create_modifiers_related_table',1),(105,'2018_05_29_121714_add_purchase_line_id_to_stock_adjustment_line_table',1),(106,'2018_05_31_114645_add_res_order_status_column_to_transactions_table',1),(107,'2018_06_05_103530_rename_purchase_line_id_in_stock_adjustment_lines_table',1),(108,'2018_06_05_111905_modify_products_table_for_modifiers',1),(109,'2018_06_06_110524_add_parent_sell_line_id_column_to_transaction_sell_lines_table',1),(110,'2018_06_07_152443_add_is_service_staff_to_roles_table',1),(111,'2018_06_07_182258_add_image_field_to_products_table',1),(112,'2018_06_13_133705_create_bookings_table',1),(113,'2018_06_15_173636_add_email_column_to_contacts_table',1),(114,'2018_06_27_182835_add_superadmin_related_fields_business',1),(115,'2018_07_10_101913_add_custom_fields_to_products_table',1),(116,'2018_07_17_103434_add_sales_person_name_label_to_invoice_layouts_table',1),(117,'2018_07_17_163920_add_theme_skin_color_column_to_business_table',1),(118,'2018_07_24_160319_add_lot_no_line_id_to_transaction_sell_lines_table',1),(119,'2018_07_25_110004_add_show_expiry_and_show_lot_colums_to_invoice_layouts_table',1),(120,'2018_07_25_172004_add_discount_columns_to_transaction_sell_lines_table',1),(121,'2018_07_26_124720_change_design_column_type_in_invoice_layouts_table',1),(122,'2018_07_26_170424_add_unit_price_before_discount_column_to_transaction_sell_line_table',1),(123,'2018_07_28_103614_add_credit_limit_column_to_contacts_table',1),(124,'2018_08_08_110755_add_new_payment_methods_to_transaction_payments_table',1),(125,'2018_08_08_122225_modify_cash_register_transactions_table_for_new_payment_methods',1),(126,'2018_08_14_104036_add_opening_balance_type_to_transactions_table',1),(127,'2018_09_04_155900_create_accounts_table',1),(128,'2018_09_06_114438_create_selling_price_groups_table',1),(129,'2018_09_06_154057_create_variation_group_prices_table',1),(130,'2018_09_07_102413_add_permission_to_access_default_selling_price',1),(131,'2018_09_07_134858_add_selling_price_group_id_to_transactions_table',1),(132,'2018_09_10_112448_update_product_type_to_single_if_null_in_products_table',1),(133,'2018_09_10_152703_create_account_transactions_table',1),(134,'2018_09_10_173656_add_account_id_column_to_transaction_payments_table',1),(135,'2018_09_19_123914_create_notification_templates_table',1),(136,'2018_09_22_110504_add_sms_and_email_settings_columns_to_business_table',1),(137,'2018_09_24_134942_add_lot_no_line_id_to_stock_adjustment_lines_table',1),(138,'2018_09_26_105557_add_transaction_payments_for_existing_expenses',1),(139,'2018_09_27_111609_modify_transactions_table_for_purchase_return',1),(140,'2018_09_27_131154_add_quantity_returned_column_to_purchase_lines_table',1),(141,'2018_10_02_131401_add_return_quantity_column_to_transaction_sell_lines_table',1),(142,'2018_10_03_104918_add_qty_returned_column_to_transaction_sell_lines_purchase_lines_table',1),(143,'2018_10_03_185947_add_default_notification_templates_to_database',1),(144,'2018_10_09_153105_add_business_id_to_transaction_payments_table',1),(145,'2018_10_16_135229_create_permission_for_sells_and_purchase',1),(146,'2018_10_22_114441_add_columns_for_variable_product_modifications',1),(147,'2018_10_22_134428_modify_variable_product_data',1),(148,'2018_10_30_181558_add_table_tax_headings_to_invoice_layout',1),(149,'2018_10_31_122619_add_pay_terms_field_transactions_table',1),(150,'2018_10_31_161328_add_new_permissions_for_pos_screen',1),(151,'2018_10_31_174752_add_access_selected_contacts_only_to_users_table',1),(152,'2018_10_31_175627_add_user_contact_access',1),(153,'2018_10_31_180559_add_auto_send_sms_column_to_notification_templates_table',1),(154,'2018_11_02_171949_change_card_type_column_to_varchar_in_transaction_payments_table',1),(155,'2018_11_08_105621_add_role_permissions',1),(156,'2018_11_26_114135_add_is_suspend_column_to_transactions_table',1),(157,'2018_11_28_104410_modify_units_table_for_multi_unit',1),(158,'2018_11_28_170952_add_sub_unit_id_to_purchase_lines_and_sell_lines',1),(159,'2018_11_29_115918_add_primary_key_in_system_table',1),(160,'2018_12_03_185546_add_product_description_column_to_products_table',1),(161,'2018_12_06_114937_modify_system_table_and_users_table',1),(162,'2018_12_13_160007_add_custom_fields_display_options_to_invoice_layouts_table',1),(163,'2018_12_14_103307_modify_system_table',1),(164,'2018_12_18_133837_add_prev_balance_due_columns_to_invoice_layouts_table',1),(165,'2018_12_18_170656_add_invoice_token_column_to_transaction_table',1),(166,'2018_12_20_133639_add_date_time_format_column_to_invoice_layouts_table',1),(167,'2018_12_21_120659_add_recurring_invoice_fields_to_transactions_table',1),(168,'2018_12_24_154933_create_notifications_table',1),(169,'2019_01_08_112015_add_document_column_to_transaction_payments_table',1),(170,'2019_01_10_124645_add_account_permission',1),(171,'2019_01_16_125825_add_subscription_no_column_to_transactions_table',1),(172,'2019_01_28_111647_add_order_addresses_column_to_transactions_table',1),(173,'2019_02_13_173821_add_is_inactive_column_to_products_table',1),(174,'2019_02_19_103118_create_discounts_table',1),(175,'2019_02_21_120324_add_discount_id_column_to_transaction_sell_lines_table',1),(176,'2019_02_21_134324_add_permission_for_discount',1),(177,'2019_03_04_170832_add_service_staff_columns_to_transaction_sell_lines_table',1),(178,'2019_03_09_102425_add_sub_type_column_to_transactions_table',1),(179,'2019_03_09_124457_add_indexing_transaction_sell_lines_purchase_lines_table',1),(180,'2019_03_12_120336_create_activity_log_table',1),(181,'2019_03_15_132925_create_media_table',1),(182,'2019_05_08_130339_add_indexing_to_parent_id_in_transaction_payments_table',1),(183,'2019_05_10_132311_add_missing_column_indexing',1),(184,'2019_05_14_091812_add_show_image_column_to_invoice_layouts_table',1),(185,'2019_05_25_104922_add_view_purchase_price_permission',1),(186,'2019_06_17_103515_add_profile_informations_columns_to_users_table',1),(187,'2019_06_18_135524_add_permission_to_view_own_sales_only',1),(188,'2019_06_19_112058_add_database_changes_for_reward_points',1),(189,'2019_06_28_133732_change_type_column_to_string_in_transactions_table',1),(190,'2019_07_13_111420_add_is_created_from_api_column_to_transactions_table',1),(191,'2019_07_15_165136_add_fields_for_combo_product',1),(192,'2019_07_19_103446_add_mfg_quantity_used_column_to_purchase_lines_table',1),(193,'2019_07_22_152649_add_not_for_selling_in_product_table',1),(194,'2019_07_29_185351_add_show_reward_point_column_to_invoice_layouts_table',1),(195,'2019_08_08_162302_add_sub_units_related_fields',1),(196,'2019_08_26_133419_update_price_fields_decimal_point',1),(197,'2019_09_02_160054_remove_location_permissions_from_roles',1),(198,'2019_09_03_185259_add_permission_for_pos_screen',1),(199,'2019_09_04_163141_add_location_id_to_cash_registers_table',1),(200,'2019_09_04_184008_create_types_of_services_table',1),(201,'2019_09_06_131445_add_types_of_service_fields_to_transactions_table',1),(202,'2019_09_09_134810_add_default_selling_price_group_id_column_to_business_locations_table',1),(203,'2019_09_12_105616_create_product_locations_table',1),(204,'2019_09_17_122522_add_custom_labels_column_to_business_table',1),(205,'2019_09_18_164319_add_shipping_fields_to_transactions_table',1),(206,'2019_09_19_170927_close_all_active_registers',1),(207,'2019_09_23_161906_add_media_description_cloumn_to_media_table',1),(208,'2019_10_18_155633_create_account_types_table',1),(209,'2019_10_22_163335_add_common_settings_column_to_business_table',1),(210,'2019_10_29_132521_add_update_purchase_status_permission',1),(211,'2019_11_09_110522_add_indexing_to_lot_number',1),(212,'2019_11_19_170824_add_is_active_column_to_business_locations_table',1),(213,'2019_11_21_162913_change_quantity_field_types_to_decimal',1),(214,'2019_11_25_160340_modify_categories_table_for_polymerphic_relationship',1),(215,'2019_12_02_105025_create_warranties_table',1),(216,'2019_12_03_180342_add_common_settings_field_to_invoice_layouts_table',1),(217,'2019_12_05_183955_add_more_fields_to_users_table',1),(218,'2019_12_06_174904_add_change_return_label_column_to_invoice_layouts_table',1),(219,'2019_12_11_121307_add_draft_and_quotation_list_permissions',1),(220,'2019_12_12_180126_copy_expense_total_to_total_before_tax',1),(221,'2019_12_19_181412_make_alert_quantity_field_nullable_on_products_table',1),(222,'2019_12_25_173413_create_dashboard_configurations_table',1),(223,'2020_01_08_133506_create_document_and_notes_table',1),(224,'2020_01_09_113252_add_cc_bcc_column_to_notification_templates_table',1),(225,'2020_01_16_174818_add_round_off_amount_field_to_transactions_table',1),(226,'2020_01_28_162345_add_weighing_scale_settings_in_business_settings_table',1),(227,'2020_02_18_172447_add_import_fields_to_transactions_table',1),(228,'2020_03_13_135844_add_is_active_column_to_selling_price_groups_table',1),(229,'2020_03_16_115449_add_contact_status_field_to_contacts_table',1),(230,'2020_03_26_124736_add_allow_login_column_in_users_table',1),(231,'2020_04_13_154150_add_feature_products_column_to_business_loactions',1),(232,'2020_04_15_151802_add_user_type_to_users_table',1),(233,'2020_04_22_153905_add_subscription_repeat_on_column_to_transactions_table',1),(234,'2020_04_28_111436_add_shipping_address_to_contacts_table',1),(235,'2020_06_01_094654_add_max_sale_discount_column_to_users_table',1),(236,'2020_06_12_162245_modify_contacts_table',1),(237,'2020_06_22_103104_change_recur_interval_default_to_one',1),(238,'2020_07_09_174621_add_balance_field_to_contacts_table',1),(239,'2020_07_23_104933_change_status_column_to_varchar_in_transaction_table',1),(240,'2020_09_07_171059_change_completed_stock_transfer_status_to_final',1),(241,'2020_09_21_123224_modify_booking_status_column_in_bookings_table',1),(242,'2020_09_22_121639_create_discount_variations_table',1),(243,'2020_10_05_121550_modify_business_location_table_for_invoice_layout',1),(244,'2020_10_16_175726_set_status_as_received_for_opening_stock',1),(245,'2020_10_23_170823_add_for_group_tax_column_to_tax_rates_table',1),(246,'2020_11_04_130940_add_more_custom_fields_to_contacts_table',1),(247,'2020_11_10_152841_add_cash_register_permissions',1),(248,'2020_11_17_164041_modify_type_column_to_varchar_in_contacts_table',1),(249,'2020_12_18_181447_add_shipping_custom_fields_to_transactions_table',1),(250,'2020_12_22_164303_add_sub_status_column_to_transactions_table',1),(251,'2020_12_24_153050_add_custom_fields_to_transactions_table',1),(252,'2020_12_28_105403_add_whatsapp_text_column_to_notification_templates_table',1),(253,'2020_12_29_165925_add_model_document_type_to_media_table',1),(254,'2021_02_08_175632_add_contact_number_fields_to_users_table',1),(255,'2021_02_11_172217_add_indexing_for_multiple_columns',1),(256,'2021_02_23_122043_add_more_columns_to_customer_groups_table',1),(257,'2021_02_24_175551_add_print_invoice_permission_to_all_roles',1),(258,'2021_03_03_162021_add_purchase_order_columns_to_purchase_lines_and_transactions_table',1),(259,'2021_03_11_120229_add_sales_order_columns',1),(260,'2021_03_16_120705_add_business_id_to_activity_log_table',1),(261,'2021_03_16_153427_add_code_columns_to_business_table',1),(262,'2021_03_18_173308_add_account_details_column_to_accounts_table',1),(263,'2021_03_18_183119_add_prefer_payment_account_columns_to_transactions_table',1),(264,'2021_03_22_120810_add_more_types_of_service_custom_fields',1),(265,'2021_03_24_183132_add_shipping_export_custom_field_details_to_contacts_table',1),(266,'2021_03_25_170715_add_export_custom_fields_info_to_transactions_table',1),(267,'2021_04_15_063449_add_denominations_column_to_cash_registers_table',1),(268,'2021_05_22_083426_add_indexing_to_account_transactions_table',1),(269,'2021_07_08_065808_add_additional_expense_columns_to_transaction_table',1),(270,'2021_07_13_082918_add_qr_code_columns_to_invoice_layouts_table',1),(271,'2021_07_21_061615_add_fields_to_show_commission_agent_in_invoice_layout',1),(272,'2021_08_13_105549_add_crm_contact_id_to_users_table',1),(273,'2021_08_25_114932_add_payment_link_fields_to_transaction_payments_table',1),(274,'2021_09_01_063110_add_spg_column_to_discounts_table',1),(275,'2021_09_03_061528_modify_cash_register_transactions_table',1),(276,'2021_10_05_061658_add_source_column_to_transactions_table',1),(277,'2020_08_18_123107_add_connector_module_version_to_system_table',2),(278,'2018_10_10_110400_add_module_version_to_system_table',3),(279,'2018_10_10_122845_add_woocommerce_api_settings_to_business_table',3),(280,'2018_10_10_162041_add_woocommerce_category_id_to_categories_table',3),(281,'2018_10_11_173839_create_woocommerce_sync_logs_table',3),(282,'2018_10_16_123522_add_woocommerce_tax_rate_id_column_to_tax_rates_table',3),(283,'2018_10_23_111555_add_woocommerce_attr_id_column_to_variation_templates_table',3),(284,'2018_12_03_163945_add_woocommerce_permissions',3),(285,'2019_02_18_154414_change_woocommerce_sync_logs_table',3),(286,'2019_04_19_174129_add_disable_woocommerce_sync_column_to_products_table',3),(287,'2019_06_08_132440_add_woocommerce_wh_oc_secret_column_to_business_table',3),(288,'2019_10_01_171828_add_woocommerce_media_id_columns',3),(289,'2020_09_07_124952_add_woocommerce_skipped_orders_fields_to_business_table',3),(290,'2021_02_16_190608_add_woocommerce_module_indexing',3),(291,'2018_06_27_185405_create_packages_table',4),(292,'2018_06_28_182803_create_subscriptions_table',4),(293,'2018_07_17_182021_add_rows_to_system_table',4),(294,'2018_07_19_131721_add_options_to_packages_table',4),(295,'2018_08_17_155534_add_min_termination_alert_days',4),(296,'2018_08_28_105945_add_business_based_username_settings_to_system_table',4),(297,'2018_08_30_105906_add_superadmin_communicator_logs_table',4),(298,'2018_11_02_130636_add_custom_permissions_to_packages_table',4),(299,'2018_11_05_161848_add_more_fields_to_packages_table',4),(300,'2018_12_10_124621_modify_system_table_values_null_default',4),(301,'2019_05_10_135434_add_missing_database_column_indexes',4),(302,'2019_08_16_115300_create_superadmin_frontend_pages_table',4),(303,'2019_03_07_155813_make_repair_statuses_table',5),(304,'2019_03_08_120634_add_repair_columns_to_transactions_table',5),(305,'2019_03_14_182704_add_repair_permissions',5),(306,'2019_03_29_110241_add_repair_version_column_to_system_table',5),(307,'2019_04_12_113901_add_repair_settings_column_to_business_table',5),(308,'2020_05_05_125008_create_device_models_table',5),(309,'2020_05_06_103135_add_repair_model_id_column_to_products_table',5),(310,'2020_07_11_120308_add_columns_to_repair_statuses_table',5),(311,'2020_07_31_130737_create_job_sheets_table',5),(312,'2020_08_07_124241_add_job_sheet_id_to_transactions_table',5),(313,'2020_08_22_104640_add_email_template_field_to_repair_status_table',5),(314,'2020_10_19_131934_add_job_sheet_custom_fields_to_repair_job_sheets_table',5),(315,'2020_11_25_111050_add_parts_column_to_repair_job_sheets_table',5),(316,'2020_12_30_101842_add_use_for_repair_column_to_brands_table',5),(317,'2021_02_16_190423_add_repair_module_indexing',5),(318,'2019_11_12_163135_create_projects_table',6),(319,'2019_11_12_164431_create_project_members_table',6),(320,'2019_11_14_112230_create_project_tasks_table',6),(321,'2019_11_14_112258_create_project_task_members_table',6),(322,'2019_11_18_154617_create_project_task_comments_table',6),(323,'2019_11_19_134807_create_project_time_logs_table',6),(324,'2019_12_11_102549_add_more_fields_in_transactions_table',6),(325,'2019_12_11_102735_create_invoice_lines_table',6),(326,'2020_01_07_172852_add_project_permissions',6),(327,'2020_01_08_115422_add_project_module_version_to_system_table',6),(328,'2020_07_10_114514_set_location_id_on_existing_invoice',6),(329,'2020_09_29_184909_add_product_catalogue_version',7),(330,'2019_07_15_114211_add_manufacturing_module_version_to_system_table',8),(331,'2019_07_15_114403_create_mfg_recipes_table',8),(332,'2019_07_18_180217_add_production_columns_to_transactions_table',8),(333,'2019_07_26_110753_add_manufacturing_settings_column_to_business_table',8),(334,'2019_07_26_170450_add_manufacturing_permissions',8),(335,'2019_08_08_110035_create_mfg_recipe_ingredients_table',8),(336,'2019_08_08_172837_add_recipe_add_edit_permissions',8),(337,'2019_08_12_114610_add_ingredient_waste_percent_columns',8),(338,'2019_11_05_115136_create_ingredient_groups_table',8),(339,'2020_02_22_120303_add_column_to_mfg_recipe_ingredients_table',8),(340,'2020_08_19_103831_add_production_cost_type_to_recipe_and_transaction_table',8),(341,'2018_10_01_151252_create_documents_table',9),(342,'2018_10_02_151803_create_document_shares_table',9),(343,'2018_10_09_134558_create_reminders_table',9),(344,'2018_11_16_170756_create_to_dos_table',9),(345,'2019_02_22_120329_essentials_messages',9),(346,'2019_02_22_161513_add_message_permissions',9),(347,'2019_03_29_164339_add_essentials_version_to_system_table',9),(348,'2019_05_17_153306_create_essentials_leave_types_table',9),(349,'2019_05_17_175921_create_essentials_leaves_table',9),(350,'2019_05_21_154517_add_essentials_settings_columns_to_business_table',9),(351,'2019_05_21_181653_create_table_essentials_attendance',9),(352,'2019_05_30_110049_create_essentials_payrolls_table',9),(353,'2019_06_04_105723_create_essentials_holidays_table',9),(354,'2019_06_28_134217_add_payroll_columns_to_transactions_table',9),(355,'2019_08_26_103520_add_approve_leave_permission',9),(356,'2019_08_27_103724_create_essentials_allowance_and_deduction_table',9),(357,'2019_08_27_105236_create_essentials_user_allowances_and_deductions',9),(358,'2019_09_20_115906_add_more_columns_to_essentials_to_dos_table',9),(359,'2019_09_23_120439_create_essentials_todo_comments_table',9),(360,'2019_12_05_170724_add_hrm_columns_to_users_table',9),(361,'2019_12_09_105809_add_allowance_and_deductions_permission',9),(362,'2020_03_28_152838_create_essentials_shift_table',9),(363,'2020_03_30_162029_create_user_shifts_table',9),(364,'2020_03_31_134558_add_shift_id_to_attendance_table',9),(365,'2020_11_05_105157_modify_todos_date_column_type',9),(366,'2020_11_11_174852_add_end_time_column_to_essentials_reminders_table',9),(367,'2020_11_26_170527_create_essentials_kb_table',9),(368,'2020_11_30_112615_create_essentials_kb_users_table',9),(369,'2021_02_12_185514_add_clock_in_location_to_essentials_attendances_table',9),(370,'2021_02_16_190203_add_essentials_module_indexing',9);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES (111,'App\\User',5),(111,'App\\User',6);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\User',1),(2,'App\\User',5),(2,'App\\User',6),(3,'App\\User',2),(5,'App\\User',3),(7,'App\\User',4);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `template_for` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sms_body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bcc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_send` tinyint(1) NOT NULL DEFAULT 0,
  `auto_send_sms` tinyint(1) NOT NULL DEFAULT 0,
  `auto_send_wa_notif` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
INSERT INTO `notification_templates` VALUES (1,1,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(2,1,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(3,1,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(4,1,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(5,1,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(6,1,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(7,1,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(8,1,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(9,1,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(10,2,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(11,2,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(12,2,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(13,2,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(14,2,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(15,2,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(16,2,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(17,2,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(18,2,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(19,3,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(20,3,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(21,3,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(22,3,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(23,3,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(24,3,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(25,3,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(26,3,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(27,3,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(28,4,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(29,4,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}',NULL,'Payment Received, from {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(30,4,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}',NULL,'Payment Reminder, from {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(31,4,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}',NULL,'Booking Confirmed - {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(32,4,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}',NULL,'New Order, from {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(33,4,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}',NULL,'Payment Paid, from {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(34,4,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}',NULL,'Items received, from {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(35,4,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}',NULL,'Items Pending, from {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(36,4,'new_quotation','<p>Dear {contact_name},</p>\n\n                    <p>Your quotation number is {invoice_number}<br />\n                    Total amount: {total_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}',NULL,'Thank you from {business_name}',NULL,NULL,0,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31');
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('3f054ec5-cee5-463b-b154-06a6a2685b38','Modules\\Project\\Notifications\\NewProjectAssignedNotification','App\\User',6,'{\"project_id\":2}',NULL,'2021-11-27 08:44:35','2021-11-27 08:44:35');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'Nacional Code Personal Access Client','1c31T9Fp1iXGrKrfe5SvFKbndk7ZS0zKEMFumwym','http://localhost',1,0,0,'2021-10-30 14:55:59','2021-10-30 14:55:59'),(2,NULL,'Nacional Code Password Grant Client','zLr7LRAZnHYyUyb5A4890v6i4zYh6YMT6vSD1b0g','http://localhost',0,1,0,'2021-10-30 14:55:59','2021-10-30 14:55:59'),(3,1,'Jjjh','ScdbHXGJclQvuB9I3OVfZ7O6OTnmoKtTE05XUg9D','http://localhost',0,1,0,'2021-11-02 20:29:08','2021-11-02 20:29:08');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2021-10-30 14:55:59','2021-10-30 14:55:59');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_count` int(11) NOT NULL COMMENT 'No. of Business Locations, 0 = infinite option.',
  `user_count` int(11) NOT NULL,
  `product_count` int(11) NOT NULL,
  `bookings` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/Disable bookings',
  `kitchen` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/Disable kitchen',
  `order_screen` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/Disable order_screen',
  `tables` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Enable/Disable tables',
  `invoice_count` int(11) NOT NULL,
  `interval` enum('days','months','years') COLLATE utf8mb4_unicode_ci NOT NULL,
  `interval_count` int(11) NOT NULL,
  `trial_days` int(11) NOT NULL,
  `price` decimal(22,4) NOT NULL,
  `custom_permissions` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `is_one_time` tinyint(1) NOT NULL DEFAULT 0,
  `enable_custom_link` tinyint(1) NOT NULL DEFAULT 0,
  `custom_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_link_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,'DEMO 1','DEMO 1',0,0,0,0,0,0,0,0,'months',1,5,0.0000,'{\"connector_module\":\"1\",\"essentials_module\":\"1\",\"manufacturing_module\":\"1\",\"productcatalogue_module\":\"1\",\"project_module\":\"1\",\"repair_module\":\"1\",\"woocommerce_module\":\"1\"}',1,1,1,0,0,0,'','',NULL,'2021-10-31 02:14:36','2021-10-31 02:14:36');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'profit_loss_report.view','web','2021-10-31 01:09:23',NULL),(2,'direct_sell.access','web','2021-10-31 01:09:23',NULL),(3,'product.opening_stock','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(4,'crud_all_bookings','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(5,'crud_own_bookings','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(6,'access_default_selling_price','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(7,'purchase.payments','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(8,'sell.payments','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(9,'edit_product_price_from_sale_screen','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(10,'edit_product_discount_from_sale_screen','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(11,'roles.view','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(12,'roles.create','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(13,'roles.update','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(14,'roles.delete','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(15,'account.access','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(16,'discount.access','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(17,'view_purchase_price','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(18,'view_own_sell_only','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(19,'edit_product_discount_from_pos_screen','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(20,'edit_product_price_from_pos_screen','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(21,'access_shipping','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(22,'purchase.update_status','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(23,'list_drafts','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(24,'list_quotations','web','2021-10-31 01:09:23','2021-10-31 01:09:23'),(25,'view_cash_register','web','2021-10-31 01:09:24','2021-10-31 01:09:24'),(26,'close_cash_register','web','2021-10-31 01:09:24','2021-10-31 01:09:24'),(27,'print_invoice','web','2021-10-31 01:09:24','2021-10-31 01:09:24'),(28,'user.view','web','2021-10-31 01:09:24',NULL),(29,'user.create','web','2021-10-31 01:09:24',NULL),(30,'user.update','web','2021-10-31 01:09:24',NULL),(31,'user.delete','web','2021-10-31 01:09:24',NULL),(32,'supplier.view','web','2021-10-31 01:09:24',NULL),(33,'supplier.create','web','2021-10-31 01:09:24',NULL),(34,'supplier.update','web','2021-10-31 01:09:24',NULL),(35,'supplier.delete','web','2021-10-31 01:09:24',NULL),(36,'customer.view','web','2021-10-31 01:09:24',NULL),(37,'customer.create','web','2021-10-31 01:09:24',NULL),(38,'customer.update','web','2021-10-31 01:09:24',NULL),(39,'customer.delete','web','2021-10-31 01:09:24',NULL),(40,'product.view','web','2021-10-31 01:09:24',NULL),(41,'product.create','web','2021-10-31 01:09:24',NULL),(42,'product.update','web','2021-10-31 01:09:24',NULL),(43,'product.delete','web','2021-10-31 01:09:24',NULL),(44,'purchase.view','web','2021-10-31 01:09:24',NULL),(45,'purchase.create','web','2021-10-31 01:09:24',NULL),(46,'purchase.update','web','2021-10-31 01:09:24',NULL),(47,'purchase.delete','web','2021-10-31 01:09:24',NULL),(48,'sell.view','web','2021-10-31 01:09:24',NULL),(49,'sell.create','web','2021-10-31 01:09:24',NULL),(50,'sell.update','web','2021-10-31 01:09:24',NULL),(51,'sell.delete','web','2021-10-31 01:09:24',NULL),(52,'purchase_n_sell_report.view','web','2021-10-31 01:09:24',NULL),(53,'contacts_report.view','web','2021-10-31 01:09:24',NULL),(54,'stock_report.view','web','2021-10-31 01:09:24',NULL),(55,'tax_report.view','web','2021-10-31 01:09:24',NULL),(56,'trending_product_report.view','web','2021-10-31 01:09:24',NULL),(57,'register_report.view','web','2021-10-31 01:09:24',NULL),(58,'sales_representative.view','web','2021-10-31 01:09:24',NULL),(59,'expense_report.view','web','2021-10-31 01:09:24',NULL),(60,'business_settings.access','web','2021-10-31 01:09:24',NULL),(61,'barcode_settings.access','web','2021-10-31 01:09:24',NULL),(62,'invoice_settings.access','web','2021-10-31 01:09:24',NULL),(63,'brand.view','web','2021-10-31 01:09:24',NULL),(64,'brand.create','web','2021-10-31 01:09:24',NULL),(65,'brand.update','web','2021-10-31 01:09:24',NULL),(66,'brand.delete','web','2021-10-31 01:09:24',NULL),(67,'tax_rate.view','web','2021-10-31 01:09:24',NULL),(68,'tax_rate.create','web','2021-10-31 01:09:24',NULL),(69,'tax_rate.update','web','2021-10-31 01:09:24',NULL),(70,'tax_rate.delete','web','2021-10-31 01:09:24',NULL),(71,'unit.view','web','2021-10-31 01:09:24',NULL),(72,'unit.create','web','2021-10-31 01:09:24',NULL),(73,'unit.update','web','2021-10-31 01:09:24',NULL),(74,'unit.delete','web','2021-10-31 01:09:24',NULL),(75,'category.view','web','2021-10-31 01:09:24',NULL),(76,'category.create','web','2021-10-31 01:09:24',NULL),(77,'category.update','web','2021-10-31 01:09:24',NULL),(78,'category.delete','web','2021-10-31 01:09:24',NULL),(79,'expense.access','web','2021-10-31 01:09:24',NULL),(80,'access_all_locations','web','2021-10-31 01:09:24',NULL),(81,'dashboard.data','web','2021-10-31 01:09:24',NULL),(82,'location.1','web','2021-10-31 01:11:39','2021-10-31 01:11:39'),(83,'woocommerce.syc_categories','web','2021-10-30 14:56:33','2021-10-30 14:56:33'),(84,'woocommerce.sync_products','web','2021-10-30 14:56:33','2021-10-30 14:56:33'),(85,'woocommerce.sync_orders','web','2021-10-30 14:56:33','2021-10-30 14:56:33'),(86,'woocommerce.map_tax_rates','web','2021-10-30 14:56:33','2021-10-30 14:56:33'),(87,'woocommerce.access_woocommerce_api_settings','web','2021-10-30 14:56:33','2021-10-30 14:56:33'),(88,'repair.create','web','2021-10-30 14:57:07','2021-10-30 14:57:07'),(89,'repair.update','web','2021-10-30 14:57:07','2021-10-30 14:57:07'),(90,'repair.view','web','2021-10-30 14:57:07','2021-10-30 14:57:07'),(91,'repair.delete','web','2021-10-30 14:57:07','2021-10-30 14:57:07'),(92,'repair_status.update','web','2021-10-30 14:57:07','2021-10-30 14:57:07'),(93,'repair_status.access','web','2021-10-30 14:57:07','2021-10-30 14:57:07'),(94,'project.create_project','web','2021-10-30 14:57:16','2021-10-30 14:57:16'),(95,'project.edit_project','web','2021-10-30 14:57:16','2021-10-30 14:57:16'),(96,'project.delete_project','web','2021-10-30 14:57:16','2021-10-30 14:57:16'),(97,'manufacturing.access_recipe','web','2021-10-30 14:57:36','2021-10-30 14:57:36'),(98,'manufacturing.access_production','web','2021-10-30 14:57:36','2021-10-30 14:57:36'),(99,'manufacturing.add_recipe','web','2021-10-30 14:57:36','2021-10-30 14:57:36'),(100,'manufacturing.edit_recipe','web','2021-10-30 14:57:36','2021-10-30 14:57:36'),(101,'essentials.create_message','web','2021-10-30 14:57:52','2021-10-30 14:57:52'),(102,'essentials.view_message','web','2021-10-30 14:57:52','2021-10-30 14:57:52'),(103,'essentials.approve_leave','web','2021-10-30 14:57:52','2021-10-30 14:57:52'),(104,'essentials.assign_todos','web','2021-10-30 14:57:52','2021-10-30 14:57:52'),(105,'essentials.add_allowance_and_deduction','web','2021-10-30 14:57:52','2021-10-30 14:57:52'),(106,'location.2','web','2021-10-31 02:18:47','2021-10-31 02:18:47'),(107,'selling_price_group.1','web','2021-10-30 16:01:07','2021-10-30 16:01:07'),(108,'selling_price_group.2','web','2021-10-30 16:01:15','2021-10-30 16:01:15'),(109,'selling_price_group.3','web','2021-10-30 16:01:26','2021-10-30 16:01:26'),(110,'location.3','web','2021-11-03 18:49:28','2021-11-03 18:49:28'),(111,'location.4','web','2021-11-03 22:02:18','2021-11-03 22:02:18'),(112,'location.5','web','2021-11-20 01:16:31','2021-11-20 01:16:31');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_invoice_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pjt_invoice_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `task` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(22,4) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `quantity` decimal(22,4) NOT NULL,
  `total` decimal(22,4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_invoice_lines_transaction_id_foreign` (`transaction_id`),
  KEY `pjt_invoice_lines_tax_rate_id_index` (`tax_rate_id`),
  CONSTRAINT `pjt_invoice_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_invoice_lines` WRITE;
/*!40000 ALTER TABLE `pjt_invoice_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_invoice_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pjt_project_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_members_project_id_foreign` (`project_id`),
  KEY `pjt_project_members_user_id_index` (`user_id`),
  CONSTRAINT `pjt_project_members_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `pjt_projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_members` WRITE;
/*!40000 ALTER TABLE `pjt_project_members` DISABLE KEYS */;
INSERT INTO `pjt_project_members` VALUES (1,1,1),(2,2,6);
/*!40000 ALTER TABLE `pjt_project_members` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_task_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pjt_project_task_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_task_id` int(10) unsigned NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `commented_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_task_comments_project_task_id_foreign` (`project_task_id`),
  CONSTRAINT `pjt_project_task_comments_project_task_id_foreign` FOREIGN KEY (`project_task_id`) REFERENCES `pjt_project_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_task_comments` WRITE;
/*!40000 ALTER TABLE `pjt_project_task_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_task_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_task_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pjt_project_task_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_task_id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_task_members_project_task_id_foreign` (`project_task_id`),
  KEY `pjt_project_task_members_user_id_index` (`user_id`),
  CONSTRAINT `pjt_project_task_members_project_task_id_foreign` FOREIGN KEY (`project_task_id`) REFERENCES `pjt_project_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_task_members` WRITE;
/*!40000 ALTER TABLE `pjt_project_task_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_task_members` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pjt_project_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `task_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'low',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `status` enum('completed','not_started','in_progress','on_hold','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_started',
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_tasks_project_id_foreign` (`project_id`),
  KEY `pjt_project_tasks_business_id_index` (`business_id`),
  KEY `pjt_project_tasks_created_by_index` (`created_by`),
  CONSTRAINT `pjt_project_tasks_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `pjt_projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_tasks` WRITE;
/*!40000 ALTER TABLE `pjt_project_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_project_time_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pjt_project_time_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `project_task_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_project_time_logs_project_id_foreign` (`project_id`),
  KEY `pjt_project_time_logs_project_task_id_foreign` (`project_task_id`),
  KEY `pjt_project_time_logs_user_id_index` (`user_id`),
  KEY `pjt_project_time_logs_created_by_index` (`created_by`),
  CONSTRAINT `pjt_project_time_logs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `pjt_projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pjt_project_time_logs_project_task_id_foreign` FOREIGN KEY (`project_task_id`) REFERENCES `pjt_project_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_project_time_logs` WRITE;
/*!40000 ALTER TABLE `pjt_project_time_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjt_project_time_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pjt_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pjt_projects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `status` enum('not_started','in_progress','on_hold','cancelled','completed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `lead_id` int(11) NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pjt_projects_business_id_index` (`business_id`),
  KEY `pjt_projects_contact_id_index` (`contact_id`),
  KEY `pjt_projects_lead_id_index` (`lead_id`),
  KEY `pjt_projects_created_by_index` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pjt_projects` WRITE;
/*!40000 ALTER TABLE `pjt_projects` DISABLE KEYS */;
INSERT INTO `pjt_projects` VALUES (1,1,'Proyecto 1',3,'in_progress',1,NULL,NULL,NULL,1,'{\"enable_timelog\":1,\"enable_invoice\":1,\"enable_notes_documents\":1,\"members_crud_task\":0,\"members_crud_note\":0,\"members_crud_timelog\":0,\"task_view\":\"list_view\",\"task_id_prefix\":\"#\"}','2021-11-02 11:47:13','2021-11-29 12:18:31'),(2,1,'SHERROSERA DOMINICANA',10,'not_started',6,'2021-11-30 00:00:00','2022-10-31 00:00:00',NULL,1,'{\"enable_timelog\":1,\"enable_invoice\":1,\"enable_notes_documents\":1,\"members_crud_task\":0,\"members_crud_note\":0,\"members_crud_timelog\":0,\"task_view\":\"list_view\",\"task_id_prefix\":\"#\"}','2021-11-27 08:44:35','2021-11-29 12:18:29');
/*!40000 ALTER TABLE `pjt_projects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_type` enum('network','windows','linux') COLLATE utf8mb4_unicode_ci NOT NULL,
  `capability_profile` enum('default','simple','SP2000','TEP-200M','P822D') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `char_per_line` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `printers_business_id_foreign` (`business_id`),
  CONSTRAINT `printers_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `printers` WRITE;
/*!40000 ALTER TABLE `printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `printers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_locations` (
  `product_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  KEY `product_locations_product_id_index` (`product_id`),
  KEY `product_locations_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_locations` WRITE;
/*!40000 ALTER TABLE `product_locations` DISABLE KEYS */;
INSERT INTO `product_locations` VALUES (1,1),(2,1),(3,1),(4,1),(5,4),(6,4),(1,4),(7,1);
/*!40000 ALTER TABLE `product_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_racks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_racks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `rack` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_racks_business_id_index` (`business_id`),
  KEY `product_racks_location_id_index` (`location_id`),
  KEY `product_racks_product_id_index` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_racks` WRITE;
/*!40000 ALTER TABLE `product_racks` DISABLE KEYS */;
INSERT INTO `product_racks` VALUES (1,1,1,5,'2','6',NULL,'2021-11-03 22:09:13','2021-11-23 23:40:49'),(2,1,4,5,'1','3',NULL,'2021-11-03 22:09:13','2021-11-23 23:40:49'),(3,1,1,6,NULL,NULL,NULL,'2021-11-04 14:11:26','2021-11-04 14:11:26'),(4,1,4,6,NULL,NULL,NULL,'2021-11-04 14:11:26','2021-11-04 14:11:26'),(5,1,1,7,NULL,NULL,NULL,'2021-11-05 06:45:15','2021-11-05 06:45:15'),(6,1,4,7,NULL,NULL,NULL,'2021-11-05 06:45:15','2021-11-05 06:45:15'),(7,1,1,1,NULL,NULL,NULL,'2021-11-17 12:39:01','2021-11-17 12:39:01'),(8,1,4,1,NULL,NULL,NULL,'2021-11-17 12:39:01','2021-11-17 12:39:01'),(9,1,1,9,NULL,NULL,NULL,'2021-11-17 20:53:11','2021-11-17 20:53:11'),(10,1,4,9,NULL,NULL,NULL,'2021-11-17 20:53:11','2021-11-17 20:53:11');
/*!40000 ALTER TABLE `product_racks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_variations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation_template_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `is_dummy` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_variations_name_index` (`name`),
  KEY `product_variations_product_id_index` (`product_id`),
  CONSTRAINT `product_variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_variations` WRITE;
/*!40000 ALTER TABLE `product_variations` DISABLE KEYS */;
INSERT INTO `product_variations` VALUES (1,1,'TALLA',1,0,'2021-10-30 16:11:13','2021-10-30 16:11:13'),(2,NULL,'DUMMY',2,1,'2021-11-02 16:45:46','2021-11-02 16:45:46'),(3,NULL,'DUMMY',3,1,'2021-11-02 18:53:20','2021-11-02 18:53:20'),(5,NULL,'DUMMY',5,1,'2021-11-03 22:09:13','2021-11-03 22:09:13'),(6,NULL,'DUMMY',6,1,'2021-11-04 14:11:26','2021-11-04 14:11:26'),(7,NULL,'DUMMY',7,1,'2021-11-05 06:45:15','2021-11-05 06:45:15'),(8,NULL,'DUMMY',8,1,'2021-11-13 07:14:54','2021-11-13 07:14:54'),(9,NULL,'DUMMY',9,1,'2021-11-17 20:53:11','2021-11-17 20:53:11');
/*!40000 ALTER TABLE `product_variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `type` enum('single','variable','modifier','combo') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` int(11) unsigned DEFAULT NULL,
  `sub_unit_ids` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `sub_category_id` int(10) unsigned DEFAULT NULL,
  `tax` int(10) unsigned DEFAULT NULL,
  `tax_type` enum('inclusive','exclusive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable_stock` tinyint(1) NOT NULL DEFAULT 0,
  `alert_quantity` decimal(22,4) DEFAULT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode_type` enum('C39','C128','EAN13','EAN8','UPCA','UPCE') COLLATE utf8mb4_unicode_ci DEFAULT 'C128',
  `expiry_period` decimal(4,2) DEFAULT NULL,
  `expiry_period_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_sr_no` tinyint(1) NOT NULL DEFAULT 0,
  `weight` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_media_id` int(11) DEFAULT NULL,
  `product_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `woocommerce_product_id` int(11) DEFAULT NULL,
  `woocommerce_disable_sync` tinyint(1) NOT NULL DEFAULT 0,
  `warranty_id` int(11) DEFAULT NULL,
  `is_inactive` tinyint(1) NOT NULL DEFAULT 0,
  `repair_model_id` int(10) unsigned DEFAULT NULL,
  `not_for_selling` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_brand_id_foreign` (`brand_id`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_sub_category_id_foreign` (`sub_category_id`),
  KEY `products_tax_foreign` (`tax`),
  KEY `products_name_index` (`name`),
  KEY `products_business_id_index` (`business_id`),
  KEY `products_unit_id_index` (`unit_id`),
  KEY `products_created_by_index` (`created_by`),
  KEY `products_warranty_id_index` (`warranty_id`),
  KEY `products_type_index` (`type`),
  KEY `products_tax_type_index` (`tax_type`),
  KEY `products_barcode_type_index` (`barcode_type`),
  KEY `products_woocommerce_product_id_index` (`woocommerce_product_id`),
  KEY `products_woocommerce_media_id_index` (`woocommerce_media_id`),
  KEY `products_repair_model_id_index` (`repair_model_id`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_repair_model_id_foreign` FOREIGN KEY (`repair_model_id`) REFERENCES `repair_device_models` (`id`),
  CONSTRAINT `products_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_tax_foreign` FOREIGN KEY (`tax`) REFERENCES `tax_rates` (`id`),
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'demo1',1,'variable',3,NULL,1,2,NULL,NULL,'exclusive',1,0.0000,'123456','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1635628273_Baby.tux-800x800.png',NULL,NULL,1,NULL,0,NULL,0,NULL,0,'2021-10-30 16:11:13','2021-11-23 11:32:37'),(2,'COCA COLA lata',1,'single',3,NULL,2,1,NULL,NULL,'inclusive',1,10.0000,'21354155478','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1635889546_coca lata.jpg',NULL,'<p>Refresco carbonatado</p>',1,NULL,0,NULL,0,NULL,0,'2021-11-02 16:45:46','2021-11-23 11:32:37'),(3,'vasos',1,'single',3,NULL,1,1,NULL,NULL,'exclusive',1,NULL,'1234567','C128',NULL,NULL,0,'300',NULL,NULL,NULL,NULL,NULL,NULL,'<p>GHT</p>',1,NULL,1,NULL,0,NULL,0,'2021-11-02 18:53:20','2021-11-23 11:32:37'),(5,'ACEITE',1,'single',3,NULL,3,1,NULL,NULL,'exclusive',1,0.0000,'AC','C128',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'1635995353_descarga.jfif',NULL,NULL,1,NULL,0,NULL,0,NULL,0,'2021-11-03 22:09:13','2021-11-23 23:40:49'),(6,'Riiiickfu',1,'single',5,NULL,1,1,NULL,NULL,'exclusive',1,10.0000,'I2737e-ddkdjd','C128',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,0,NULL,0,'2021-11-04 14:11:26','2021-11-23 11:32:37'),(7,'Salame nacional',1,'single',3,NULL,4,2,NULL,NULL,'inclusive',1,0.0000,'Ar000007','EAN13',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'1636112715_IMG-20170826-WA0151.jpeg',NULL,NULL,1,NULL,1,1,0,NULL,0,'2021-11-05 06:45:15','2021-11-23 11:32:37'),(8,'Prueba212',1,'single',3,NULL,2,2,NULL,NULL,'exclusive',0,0.0000,'Ar000008','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,0,NULL,0,'2021-11-13 07:14:54','2021-11-23 11:32:37'),(9,'AGUA',1,'single',3,NULL,2,2,NULL,NULL,'exclusive',1,10.0000,'1234556','C128',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p>ADDADADAD</p>',1,NULL,0,1,0,NULL,0,'2021-11-17 20:53:11','2021-11-23 11:32:37');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `pp_without_discount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Purchase price before inline discounts',
  `discount_percent` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Inline discount percentage',
  `purchase_price` decimal(22,4) NOT NULL,
  `purchase_price_inc_tax` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `item_tax` decimal(22,4) NOT NULL COMMENT 'Tax for one quantity',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `purchase_order_line_id` int(11) DEFAULT NULL,
  `quantity_sold` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Quanity sold from this purchase line',
  `quantity_adjusted` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Quanity adjusted in stock adjustment from this purchase line',
  `quantity_returned` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `po_quantity_purchased` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `mfg_quantity_used` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `mfg_date` date DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `lot_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_unit_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_lines_transaction_id_foreign` (`transaction_id`),
  KEY `purchase_lines_product_id_foreign` (`product_id`),
  KEY `purchase_lines_variation_id_foreign` (`variation_id`),
  KEY `purchase_lines_tax_id_foreign` (`tax_id`),
  KEY `purchase_lines_sub_unit_id_index` (`sub_unit_id`),
  KEY `purchase_lines_lot_number_index` (`lot_number`),
  CONSTRAINT `purchase_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_lines` WRITE;
/*!40000 ALTER TABLE `purchase_lines` DISABLE KEYS */;
INSERT INTO `purchase_lines` VALUES (1,1,1,1,10.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,9.0000,1.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-10-30 16:12:10','2021-11-02 15:53:34'),(2,1,1,2,10.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,10.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-10-30 16:12:10','2021-11-03 00:10:05'),(3,1,1,3,10.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,10.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-10-30 16:12:10','2021-11-03 21:52:02'),(4,1,1,4,10.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,10.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-10-30 16:12:10','2021-11-02 19:00:22'),(5,4,1,4,100.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,30.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-10-30 16:37:46','2021-11-30 12:29:04'),(6,16,2,5,24.0000,3.7500,0.00,3.7500,3.7500,0.0000,NULL,NULL,24.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-02 16:46:40','2021-11-09 10:32:21'),(7,19,3,6,150.0000,1500.0000,0.00,1500.0000,1500.0000,0.0000,NULL,NULL,111.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-02 18:57:13','2021-11-30 12:29:04'),(8,34,5,9,1015.0000,100.0000,0.00,100.0000,100.0000,0.0000,NULL,NULL,26.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-03 22:15:10','2021-11-23 22:05:10'),(9,35,5,9,3.0000,100.0000,0.00,100.0000,100.0000,0.0000,NULL,NULL,3.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-03 22:28:06','2021-11-23 20:41:14'),(10,40,7,11,100.0000,18750.0000,0.00,18750.0000,18750.0000,0.0000,NULL,NULL,14.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-05 06:45:26','2021-11-29 14:07:50'),(11,45,2,5,1.0000,0.0000,0.00,3.7500,3.7500,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-06 08:05:48','2021-11-06 08:05:48'),(12,65,3,6,1.0000,0.0000,0.00,1500.0000,1500.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-15 10:04:50','2021-11-15 10:04:50'),(13,72,1,4,1.0000,0.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,1.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-15 10:19:47','2021-11-23 20:41:14'),(14,81,3,6,3.0000,0.0000,0.00,1500.0000,1500.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-23 16:30:57','2021-11-23 22:57:51'),(15,81,1,4,4.0000,0.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-23 16:30:57','2021-11-23 22:57:51'),(17,84,1,1,1000.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-23 21:54:48','2021-11-23 21:54:48'),(18,84,1,2,1500.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,1.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-23 21:54:48','2021-11-27 08:47:33'),(19,84,1,3,2000.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-23 21:54:48','2021-11-23 21:54:48'),(20,84,1,4,3000.0000,12.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-23 21:54:48','2021-11-23 21:54:48'),(21,86,3,6,59.0000,0.0000,0.00,1500.0000,1500.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-23 21:56:07','2021-11-23 21:56:07'),(22,108,1,4,5.0000,0.0000,0.00,12.0000,12.0000,0.0000,NULL,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,NULL,NULL,'2021-11-30 09:31:20','2021-11-30 09:31:20');
/*!40000 ALTER TABLE `purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reference_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reference_counts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ref_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_count` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reference_counts_business_id_index` (`business_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reference_counts` WRITE;
/*!40000 ALTER TABLE `reference_counts` DISABLE KEYS */;
INSERT INTO `reference_counts` VALUES (1,'contacts',11,1,'2021-10-31 01:11:39','2021-11-23 21:54:28'),(2,'business_location',2,1,'2021-10-31 01:11:39','2021-11-03 22:02:18'),(3,'contacts',1,2,'2021-10-31 02:18:46','2021-10-31 02:18:46'),(4,'business_location',1,2,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(5,'subscription',2,1,'2021-10-30 16:31:39','2021-11-07 12:28:30'),(6,'sell_payment',73,1,'2021-10-30 16:31:39','2021-11-30 12:29:04'),(7,'stock_adjustment',2,1,'2021-10-30 16:35:06','2021-11-03 22:11:26'),(8,'purchase',4,1,'2021-10-30 16:37:46','2021-11-23 21:54:48'),(9,'draft',18,1,'2021-11-02 11:37:57','2021-11-29 13:06:37'),(10,'purchase_payment',2,1,'2021-11-02 18:49:59','2021-11-03 22:28:36'),(11,'contacts',1,3,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(12,'business_location',1,3,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(14,'stock_transfer',6,1,'2021-11-06 08:05:48','2021-11-30 09:31:20'),(15,'essentials_todos',2,1,'2021-11-13 11:26:47','2021-11-13 11:27:01'),(16,'contacts',1,4,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(17,'business_location',1,4,'2021-11-20 01:16:31','2021-11-20 01:16:31');
/*!40000 ALTER TABLE `reference_counts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `repair_device_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repair_device_models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repair_checklist` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `device_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repair_device_models_business_id_index` (`business_id`),
  KEY `repair_device_models_brand_id_index` (`brand_id`),
  KEY `repair_device_models_device_id_index` (`device_id`),
  KEY `repair_device_models_created_by_index` (`created_by`),
  CONSTRAINT `repair_device_models_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `repair_device_models_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repair_device_models_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `repair_device_models_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `repair_device_models` WRITE;
/*!40000 ALTER TABLE `repair_device_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_device_models` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `repair_job_sheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repair_job_sheets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `job_sheet_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_type` enum('carry_in','pick_up','on_site') COLLATE utf8mb4_unicode_ci NOT NULL,
  `pick_up_on_site_addr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `device_id` int(10) unsigned DEFAULT NULL,
  `device_model_id` int(10) unsigned DEFAULT NULL,
  `checklist` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_pwd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `security_pattern` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_id` int(11) NOT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `product_configuration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defects` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_condition` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_staff` int(10) unsigned DEFAULT NULL,
  `comment_by_ss` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'comment made by technician',
  `estimated_cost` decimal(22,4) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `parts` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repair_job_sheets_business_id_index` (`business_id`),
  KEY `repair_job_sheets_location_id_index` (`location_id`),
  KEY `repair_job_sheets_contact_id_index` (`contact_id`),
  KEY `repair_job_sheets_brand_id_index` (`brand_id`),
  KEY `repair_job_sheets_device_id_index` (`device_id`),
  KEY `repair_job_sheets_device_model_id_index` (`device_model_id`),
  KEY `repair_job_sheets_status_id_index` (`status_id`),
  KEY `repair_job_sheets_service_staff_index` (`service_staff`),
  KEY `repair_job_sheets_created_by_index` (`created_by`),
  CONSTRAINT `repair_job_sheets_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `repair_job_sheets_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repair_job_sheets_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `repair_job_sheets_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `repair_job_sheets_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `repair_job_sheets_device_model_id_foreign` FOREIGN KEY (`device_model_id`) REFERENCES `repair_device_models` (`id`),
  CONSTRAINT `repair_job_sheets_service_staff_foreign` FOREIGN KEY (`service_staff`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `repair_job_sheets` WRITE;
/*!40000 ALTER TABLE `repair_job_sheets` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_job_sheets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `repair_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repair_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `is_completed_status` tinyint(1) NOT NULL DEFAULT 0,
  `sms_template` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_subject` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `repair_statuses` WRITE;
/*!40000 ALTER TABLE `repair_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `res_product_modifier_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `res_product_modifier_sets` (
  `modifier_set_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL COMMENT 'Table use to store the modifier sets applicable for a product',
  KEY `res_product_modifier_sets_modifier_set_id_foreign` (`modifier_set_id`),
  CONSTRAINT `res_product_modifier_sets_modifier_set_id_foreign` FOREIGN KEY (`modifier_set_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `res_product_modifier_sets` WRITE;
/*!40000 ALTER TABLE `res_product_modifier_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `res_product_modifier_sets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `res_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `res_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `res_tables_business_id_foreign` (`business_id`),
  CONSTRAINT `res_tables_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `res_tables` WRITE;
/*!40000 ALTER TABLE `res_tables` DISABLE KEYS */;
/*!40000 ALTER TABLE `res_tables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (25,2),(25,4),(25,6),(25,8),(26,2),(26,4),(26,6),(26,8),(48,2),(48,4),(48,6),(48,8),(49,2),(49,4),(49,6),(49,8),(50,2),(50,4),(50,6),(50,8),(51,2),(51,4),(51,6),(51,8),(80,4),(80,6),(80,8);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_service_staff` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_business_id_foreign` (`business_id`),
  CONSTRAINT `roles_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin#1','web',1,1,0,'2021-10-31 01:11:38','2021-10-31 01:11:38'),(2,'Cashier#1','web',1,0,0,'2021-10-31 01:11:38','2021-10-31 01:11:38'),(3,'Admin#2','web',2,1,0,'2021-10-31 02:18:46','2021-10-31 02:18:46'),(4,'Cashier#2','web',2,0,0,'2021-10-31 02:18:46','2021-10-31 02:18:46'),(5,'Admin#3','web',3,1,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(6,'Cashier#3','web',3,0,0,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(7,'Admin#4','web',4,1,0,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(8,'Cashier#4','web',4,0,0,'2021-11-20 01:16:31','2021-11-20 01:16:31');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sell_line_warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sell_line_warranties` (
  `sell_line_id` int(11) NOT NULL,
  `warranty_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sell_line_warranties` WRITE;
/*!40000 ALTER TABLE `sell_line_warranties` DISABLE KEYS */;
INSERT INTO `sell_line_warranties` VALUES (80,1),(84,1),(88,1),(100,1),(102,1),(103,1),(108,1),(117,1),(121,1),(124,1),(129,1),(131,1),(133,1),(137,1),(139,1);
/*!40000 ALTER TABLE `sell_line_warranties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `selling_price_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selling_price_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `selling_price_groups_business_id_foreign` (`business_id`),
  CONSTRAINT `selling_price_groups_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `selling_price_groups` WRITE;
/*!40000 ALTER TABLE `selling_price_groups` DISABLE KEYS */;
INSERT INTO `selling_price_groups` VALUES (1,'PVP',NULL,1,1,'2021-11-17 11:38:04','2021-10-30 16:01:07','2021-11-17 11:38:04'),(2,'PRECIO PUBLICO',NULL,1,1,NULL,'2021-10-30 16:01:15','2021-11-17 11:38:22'),(3,'MAYORISTA',NULL,1,1,NULL,'2021-10-30 16:01:26','2021-10-30 16:01:26');
/*!40000 ALTER TABLE `selling_price_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustment_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustment_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL,
  `unit_price` decimal(22,4) DEFAULT NULL COMMENT 'Last purchase unit price',
  `removed_purchase_line` int(11) DEFAULT NULL,
  `lot_no_line_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_adjustment_lines_product_id_foreign` (`product_id`),
  KEY `stock_adjustment_lines_variation_id_foreign` (`variation_id`),
  KEY `stock_adjustment_lines_transaction_id_index` (`transaction_id`),
  KEY `stock_adjustment_lines_lot_no_line_id_index` (`lot_no_line_id`),
  CONSTRAINT `stock_adjustment_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustment_lines` WRITE;
/*!40000 ALTER TABLE `stock_adjustment_lines` DISABLE KEYS */;
INSERT INTO `stock_adjustment_lines` VALUES (1,3,1,1,1.0000,12.0000,NULL,NULL,'2021-10-30 16:35:06','2021-10-30 16:35:06');
/*!40000 ALTER TABLE `stock_adjustment_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustments_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustments_temp` (
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustments_temp` WRITE;
/*!40000 ALTER TABLE `stock_adjustments_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_adjustments_temp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `package_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `trial_end_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `package_price` decimal(22,4) NOT NULL,
  `package_details` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_id` int(10) unsigned NOT NULL,
  `paid_via` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('approved','waiting','declined') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiting',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_business_id_foreign` (`business_id`),
  KEY `subscriptions_package_id_index` (`package_id`),
  KEY `subscriptions_created_id_index` (`created_id`),
  CONSTRAINT `subscriptions_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,2,1,'2021-10-30','2021-12-05','2021-11-30',0.0000,'{\"location_count\":0,\"user_count\":0,\"product_count\":0,\"invoice_count\":0,\"name\":\"DEMO 1\",\"connector_module\":\"1\",\"essentials_module\":\"1\",\"manufacturing_module\":\"1\",\"productcatalogue_module\":\"1\",\"project_module\":\"1\",\"repair_module\":\"1\",\"woocommerce_module\":\"1\"}',2,NULL,'FREE','approved',NULL,'2021-10-30 15:50:51','2021-10-30 15:50:51'),(2,1,1,'2021-10-30','2021-12-05','2021-11-30',0.0000,'{\"location_count\":0,\"user_count\":0,\"product_count\":0,\"invoice_count\":0,\"name\":\"DEMO 1\",\"connector_module\":\"1\",\"essentials_module\":\"1\",\"manufacturing_module\":\"1\",\"productcatalogue_module\":\"1\",\"project_module\":\"1\",\"repair_module\":\"1\",\"woocommerce_module\":\"1\"}',1,NULL,'FREE','approved',NULL,'2021-10-30 15:57:32','2021-10-30 15:57:32'),(3,3,1,'2021-11-03','2021-12-08','2021-12-03',0.0000,'{\"location_count\":0,\"user_count\":0,\"product_count\":0,\"invoice_count\":0,\"name\":\"DEMO 1\",\"connector_module\":\"1\",\"essentials_module\":\"1\",\"manufacturing_module\":\"1\",\"productcatalogue_module\":\"1\",\"project_module\":\"1\",\"repair_module\":\"1\",\"woocommerce_module\":\"1\"}',3,NULL,'FREE','approved',NULL,'2021-11-03 08:21:23','2021-11-03 08:21:23'),(4,1,1,'2021-12-01','2022-01-06','2022-01-01',0.0000,'{\"location_count\":0,\"user_count\":0,\"product_count\":0,\"invoice_count\":0,\"name\":\"DEMO 1\",\"connector_module\":\"1\",\"essentials_module\":\"1\",\"manufacturing_module\":\"1\",\"productcatalogue_module\":\"1\",\"project_module\":\"1\",\"repair_module\":\"1\",\"woocommerce_module\":\"1\"}',1,NULL,'FREE','approved',NULL,'2021-11-03 22:00:16','2021-11-03 22:00:16');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `superadmin_communicator_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `superadmin_communicator_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_ids` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `superadmin_communicator_logs` WRITE;
/*!40000 ALTER TABLE `superadmin_communicator_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `superadmin_communicator_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `superadmin_frontend_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `superadmin_frontend_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_shown` tinyint(1) NOT NULL,
  `menu_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `superadmin_frontend_pages` WRITE;
/*!40000 ALTER TABLE `superadmin_frontend_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `superadmin_frontend_pages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system` WRITE;
/*!40000 ALTER TABLE `system` DISABLE KEYS */;
INSERT INTO `system` VALUES (1,'db_version','4.6'),(2,'default_business_active_status','1'),(4,'woocommerce_version','2.7'),(5,'superadmin_version','2.7'),(6,'app_currency_id','2'),(7,'invoice_business_name','Nacional Code'),(8,'invoice_business_landmark','Landmark'),(9,'invoice_business_zip','Zip'),(10,'invoice_business_state','State'),(11,'invoice_business_city','City'),(12,'invoice_business_country','Country'),(13,'email','superadmin@example.com'),(14,'package_expiry_alert_days','5'),(15,'enable_business_based_username','0'),(17,'project_version','1.6'),(18,'productcatalogue_version','0.6'),(21,'superadmin_register_tc',NULL),(22,'welcome_email_subject',NULL),(23,'welcome_email_body',NULL),(24,'additional_js',NULL),(25,'additional_css',NULL),(26,'offline_payment_details','DEPOSITO'),(27,'superadmin_enable_register_tc','0'),(28,'allow_email_settings_to_businesses','0'),(29,'enable_new_business_registration_notification','0'),(30,'enable_new_subscription_notification','0'),(31,'enable_welcome_email','0'),(32,'enable_offline_payment','1'),(33,'essentials_version','2.5');
/*!40000 ALTER TABLE `system` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_rates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(22,4) NOT NULL,
  `is_tax_group` tinyint(1) NOT NULL DEFAULT 0,
  `for_tax_group` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) unsigned NOT NULL,
  `woocommerce_tax_rate_id` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_rates_business_id_foreign` (`business_id`),
  KEY `tax_rates_created_by_foreign` (`created_by`),
  KEY `tax_rates_woocommerce_tax_rate_id_index` (`woocommerce_tax_rate_id`),
  CONSTRAINT `tax_rates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tax_rates_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
INSERT INTO `tax_rates` VALUES (1,1,'iva 12',12.0000,0,0,1,NULL,NULL,'2021-11-23 23:03:25','2021-11-23 23:03:25');
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) unsigned DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `is_return` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Used during sales to return the change',
  `amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_transaction_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_holder_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_month` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_security` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `paid_through_link` tinyint(1) NOT NULL DEFAULT 0,
  `gateway` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_advance` tinyint(1) NOT NULL DEFAULT 0,
  `payment_for` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_payments_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_payments_created_by_index` (`created_by`),
  KEY `transaction_payments_parent_id_index` (`parent_id`),
  CONSTRAINT `transaction_payments_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_payments` WRITE;
/*!40000 ALTER TABLE `transaction_payments` DISABLE KEYS */;
INSERT INTO `transaction_payments` VALUES (1,2,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 16:29:00',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0001',NULL,'2021-10-30 16:31:39','2021-10-30 16:33:46'),(2,5,1,0,60.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 20:17:32',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0002',NULL,'2021-10-30 20:17:32','2021-10-30 20:17:32'),(3,6,1,0,30.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 20:21:54',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0003',NULL,'2021-10-30 20:21:54','2021-10-30 20:21:54'),(4,7,1,0,90.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 20:29:49',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0004',NULL,'2021-10-30 20:29:49','2021-10-30 20:29:49'),(5,8,1,0,30.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 11:37:08',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0005',NULL,'2021-11-02 11:37:08','2021-11-02 11:37:08'),(6,9,1,0,30.0000,'card',NULL,NULL,NULL,'visa',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 11:37:36',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0006',NULL,'2021-11-02 11:37:36','2021-11-02 11:37:36'),(7,12,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 12:13:55',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0007',NULL,'2021-11-02 12:13:55','2021-11-02 12:13:55'),(8,13,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 15:51:53',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0008',NULL,'2021-11-02 15:51:53','2021-11-02 15:51:53'),(9,14,1,0,60.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 15:53:34',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0009',NULL,'2021-11-02 15:53:34','2021-11-02 15:53:34'),(10,15,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 15:53:40',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0010',NULL,'2021-11-02 15:53:40','2021-11-02 15:53:40'),(11,4,1,0,1200.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 18:49:00',1,0,NULL,0,4,NULL,NULL,NULL,'PP2021/0001',NULL,'2021-11-02 18:49:59','2021-11-02 18:49:59'),(12,20,1,0,15000.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 18:59:13',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0011',NULL,'2021-11-02 18:59:13','2021-11-02 18:59:13'),(13,21,1,0,3835.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 18:59:52',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0012',NULL,'2021-11-02 18:59:52','2021-11-02 18:59:52'),(14,22,1,0,3805.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 19:00:22',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0013',NULL,'2021-11-02 19:00:22','2021-11-02 19:00:22'),(15,23,1,0,3790.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 19:01:08',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0014',NULL,'2021-11-02 19:01:08','2021-11-02 19:01:08'),(16,24,1,0,1875.0000,'cash',NULL,'21','122222','visa','122','02',NULL,'12',NULL,NULL,'2021-11-02 19:01:55',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0015',NULL,'2021-11-02 19:01:55','2021-11-02 19:03:36'),(17,25,1,0,1910.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 00:09:42',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0016',NULL,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(18,26,1,0,1925.0000,'cash',NULL,NULL,NULL,'visa',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 00:10:05',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0017',NULL,'2021-11-03 00:10:05','2021-11-05 00:01:19'),(19,NULL,1,0,5.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 00:13:00',1,0,NULL,1,5,NULL,NULL,NULL,'SP2021/0018',NULL,'2021-11-03 00:13:21','2021-11-03 00:13:21'),(20,17,1,0,5.0000,'cash','cash',NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 00:13:00',1,0,NULL,0,5,19,NULL,NULL,'SP2021/0019',NULL,'2021-11-03 00:13:21','2021-11-03 00:13:21'),(21,27,1,0,3790.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 08:24:20',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0020',NULL,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(22,28,1,0,10.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 11:53:00',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0021',NULL,'2021-11-03 11:53:00','2021-11-03 11:53:00'),(23,29,1,0,20.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 14:29:20',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0022',NULL,'2021-11-03 14:29:20','2021-11-03 14:29:20'),(24,30,1,0,5.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 15:22:58',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0023',NULL,'2021-11-03 15:22:58','2021-11-03 15:22:58'),(25,32,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 21:52:02',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0024',NULL,'2021-11-03 21:52:02','2021-11-03 21:52:02'),(26,33,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 21:52:50',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0025',NULL,'2021-11-03 21:52:50','2021-11-03 21:52:50'),(27,35,1,0,300.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 22:28:00',1,0,NULL,0,8,NULL,NULL,NULL,'PP2021/0002',NULL,'2021-11-03 22:28:36','2021-11-03 22:28:36'),(28,36,1,0,55.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 22:33:30',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0026',NULL,'2021-11-03 22:33:30','2021-11-03 22:33:30'),(29,36,1,0,100.0000,'bank_transfer',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 22:33:30',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0027',NULL,'2021-11-03 22:33:30','2021-11-03 22:33:30'),(30,38,1,0,3.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-04 10:39:17',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0028',NULL,'2021-11-04 10:39:17','2021-11-04 10:39:17'),(31,38,1,0,2.0000,'card',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-04 10:39:17',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0029',NULL,'2021-11-04 10:39:17','2021-11-04 10:39:17'),(32,39,1,0,5.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-04 10:40:35',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0030',NULL,'2021-11-04 10:40:35','2021-11-04 10:40:35'),(33,41,1,0,5.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-05 11:03:00',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0031',NULL,'2021-11-05 11:06:16','2021-11-05 11:06:16'),(34,42,1,0,155.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-05 12:32:02',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0032',NULL,'2021-11-05 12:32:02','2021-11-05 12:32:02'),(35,43,1,0,155.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-05 17:27:12',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0033',NULL,'2021-11-05 17:27:12','2021-11-05 17:27:12'),(36,46,1,0,620.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-07 11:49:36',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0034',NULL,'2021-11-07 11:49:36','2021-11-07 11:49:36'),(37,47,1,0,310.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-07 12:28:30',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0035',NULL,'2021-11-07 12:28:30','2021-11-07 12:28:30'),(38,50,1,0,155.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-07 17:22:34',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0036',NULL,'2021-11-07 17:22:34','2021-11-07 17:22:34'),(39,51,1,0,155.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-07 17:24:05',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0037',NULL,'2021-11-07 17:24:05','2021-11-07 17:24:05'),(40,53,1,0,465.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-08 09:16:07',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0038',NULL,'2021-11-08 09:16:07','2021-11-08 09:16:07'),(41,54,1,0,310.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-08 11:44:33',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0039',NULL,'2021-11-08 11:44:33','2021-11-08 11:44:33'),(42,55,1,0,5.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-08 20:11:26',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0040',NULL,'2021-11-08 20:11:26','2021-11-08 20:11:26'),(43,56,1,0,5.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-08 20:14:36',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0041',NULL,'2021-11-08 20:14:36','2021-11-08 20:14:36'),(44,57,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-09 10:32:21',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0042',NULL,'2021-11-09 10:32:21','2021-11-09 10:32:21'),(45,58,1,0,1875.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-10 08:08:05',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0043',NULL,'2021-11-10 08:08:05','2021-11-10 08:08:05'),(46,60,1,0,3765.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-10 14:06:53',1,0,NULL,0,10,NULL,NULL,NULL,'SP2021/0044',NULL,'2021-11-10 14:06:53','2021-11-10 14:06:53'),(49,63,1,0,25312.5000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 07:11:46',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0047',NULL,'2021-11-15 07:11:46','2021-11-15 07:11:46'),(50,66,1,0,1875.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:07:00',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0048',NULL,'2021-11-15 10:07:00','2021-11-15 10:07:00'),(51,67,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:10:33',1,0,NULL,0,11,NULL,NULL,NULL,'SP2021/0049',NULL,'2021-11-15 10:10:33','2021-11-15 10:10:33'),(52,69,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:11:47',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0050',NULL,'2021-11-15 10:11:47','2021-11-15 10:11:47'),(53,70,1,0,1890.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:18:41',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0051',NULL,'2021-11-15 10:18:41','2021-11-15 10:18:41'),(54,73,1,0,3750.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 22:29:46',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0052',NULL,'2021-11-15 22:29:46','2021-11-15 22:29:46'),(55,74,1,0,1876.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-16 06:40:35',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0053',NULL,'2021-11-16 06:40:35','2021-11-16 06:40:35'),(56,75,1,0,1875.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-17 11:32:54',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0054',NULL,'2021-11-17 11:32:54','2021-11-17 11:32:54'),(57,76,1,0,23437.5000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-17 11:37:09',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0055',NULL,'2021-11-17 11:37:09','2021-11-17 11:37:09'),(58,78,1,0,93750.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-17 20:54:16',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0056',NULL,'2021-11-17 20:54:16','2021-11-17 20:54:16'),(59,79,1,0,1875.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-18 15:59:23',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0057',NULL,'2021-11-18 15:59:23','2021-11-18 15:59:23'),(60,83,1,0,325.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 20:41:14',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0058',NULL,'2021-11-23 20:41:14','2021-11-23 20:41:14'),(61,87,1,0,1240.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 22:04:19',6,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0059',NULL,'2021-11-23 22:04:19','2021-11-23 22:04:19'),(62,88,1,0,465.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 22:04:33',6,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0060',NULL,'2021-11-23 22:04:33','2021-11-23 22:05:10'),(63,90,1,0,25327.5000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-25 08:45:40',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0061',NULL,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(64,91,1,0,70357.5000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-26 12:44:47',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0062',NULL,'2021-11-26 12:44:47','2021-11-26 12:44:47'),(65,93,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-26 15:17:50',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0063',NULL,'2021-11-26 15:17:50','2021-11-26 15:17:50'),(66,95,1,0,15.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-27 08:47:33',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0064',NULL,'2021-11-27 08:47:33','2021-11-27 08:47:33'),(67,96,1,0,3750.0000,'card',NULL,NULL,NULL,'visa',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-27 15:04:48',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0065',NULL,'2021-11-27 15:04:48','2021-11-27 15:04:48'),(68,97,1,0,1875.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-27 15:05:10',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0066',NULL,'2021-11-27 15:05:10','2021-11-27 15:05:10'),(69,98,1,0,38437.5000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-27 15:36:40',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0067',NULL,'2021-11-27 15:36:40','2021-11-27 15:36:40'),(70,99,1,0,25312.5000,'card',NULL,'414','444444145455555555','visa','ALEX','14',NULL,'151',NULL,NULL,'2021-11-27 17:31:38',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0068',NULL,'2021-11-27 17:31:38','2021-11-27 17:31:38'),(71,100,1,0,60.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-28 10:52:49',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0069',NULL,'2021-11-28 10:52:49','2021-11-28 10:52:49'),(72,103,1,0,23452.5000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-29 12:56:08',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0070',NULL,'2021-11-29 12:56:08','2021-11-29 12:56:08'),(73,105,1,0,25312.5000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-29 14:07:50',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0071',NULL,'2021-11-29 14:07:50','2021-11-29 14:07:50'),(74,106,1,0,1875.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-29 14:08:19',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0072',NULL,'2021-11-29 14:08:19','2021-11-29 14:08:19'),(75,109,1,0,5640.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-30 12:29:04',1,0,NULL,0,1,NULL,NULL,NULL,'SP2021/0073',NULL,'2021-11-30 12:29:04','2021-11-30 12:29:04');
/*!40000 ALTER TABLE `transaction_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_sell_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_sell_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `mfg_waste_percent` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `quantity_returned` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `unit_price_before_discount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `unit_price` decimal(22,4) DEFAULT NULL COMMENT 'Sell price excluding tax',
  `line_discount_type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_discount_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `unit_price_inc_tax` decimal(22,4) DEFAULT NULL COMMENT 'Sell price including tax',
  `item_tax` decimal(22,4) NOT NULL COMMENT 'Tax for one quantity',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `lot_no_line_id` int(11) DEFAULT NULL,
  `sell_line_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `woocommerce_line_items_id` int(11) DEFAULT NULL,
  `so_line_id` int(11) DEFAULT NULL,
  `so_quantity_invoiced` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `res_service_staff_id` int(11) DEFAULT NULL,
  `res_line_order_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_sell_line_id` int(11) DEFAULT NULL,
  `children_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Type of children for the parent, like modifier or combo',
  `sub_unit_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_sell_lines_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_sell_lines_product_id_foreign` (`product_id`),
  KEY `transaction_sell_lines_variation_id_foreign` (`variation_id`),
  KEY `transaction_sell_lines_tax_id_foreign` (`tax_id`),
  KEY `transaction_sell_lines_children_type_index` (`children_type`),
  KEY `transaction_sell_lines_parent_sell_line_id_index` (`parent_sell_line_id`),
  KEY `transaction_sell_lines_line_discount_type_index` (`line_discount_type`),
  KEY `transaction_sell_lines_discount_id_index` (`discount_id`),
  KEY `transaction_sell_lines_lot_no_line_id_index` (`lot_no_line_id`),
  KEY `transaction_sell_lines_sub_unit_id_index` (`sub_unit_id`),
  KEY `transaction_sell_lines_woocommerce_line_items_id_index` (`woocommerce_line_items_id`),
  CONSTRAINT `transaction_sell_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_sell_lines` WRITE;
/*!40000 ALTER TABLE `transaction_sell_lines` DISABLE KEYS */;
INSERT INTO `transaction_sell_lines` VALUES (1,2,1,1,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'123444',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-10-30 16:31:39','2021-11-02 11:18:40'),(2,5,1,4,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-10-30 20:17:32','2021-11-02 11:18:34'),(3,5,1,1,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-10-30 20:17:32','2021-11-02 11:18:34'),(4,6,1,1,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-10-30 20:21:54','2021-11-02 11:18:44'),(5,6,1,2,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-10-30 20:21:54','2021-11-02 11:18:44'),(6,7,1,4,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-10-30 20:29:49','2021-11-02 19:13:23'),(7,7,1,1,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-10-30 20:29:49','2021-11-02 19:13:23'),(8,7,1,2,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-10-30 20:29:49','2021-11-02 19:13:23'),(9,8,1,1,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 11:37:08','2021-11-02 19:13:06'),(10,8,1,2,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 11:37:08','2021-11-02 19:13:06'),(11,9,1,2,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 11:37:36','2021-11-02 11:50:34'),(12,9,1,3,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 11:37:36','2021-11-02 11:50:34'),(13,10,1,2,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-02 11:37:57','2021-11-02 11:37:57'),(14,10,1,1,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-02 11:37:57','2021-11-02 11:37:57'),(15,11,1,1,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-02 11:43:25','2021-11-02 11:43:25'),(16,12,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 12:13:55','2021-11-02 19:13:26'),(17,13,1,1,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 15:51:53','2021-11-02 19:13:22'),(18,14,1,1,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 15:53:34','2021-11-02 19:13:10'),(19,14,1,2,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 15:53:34','2021-11-02 19:13:10'),(20,14,1,3,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 15:53:34','2021-11-02 19:13:10'),(21,14,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 15:53:34','2021-11-02 19:13:10'),(22,15,1,2,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 15:53:40','2021-11-02 19:13:08'),(23,17,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 16:50:57','2021-11-02 19:13:16'),(24,18,2,5,20.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-02 17:55:33','2021-11-02 17:55:33'),(25,20,3,6,8.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 18:59:13','2021-11-02 19:13:18'),(26,21,3,6,2.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 18:59:52','2021-11-02 19:13:33'),(27,21,1,4,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 18:59:52','2021-11-02 19:13:33'),(28,21,2,5,2.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 18:59:52','2021-11-02 19:13:33'),(29,21,1,3,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 18:59:52','2021-11-02 19:13:33'),(30,21,1,2,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 18:59:52','2021-11-02 19:13:33'),(31,22,3,6,2.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 19:00:22','2021-11-02 19:13:34'),(32,22,2,5,2.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 19:00:22','2021-11-02 19:13:34'),(33,22,1,4,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 19:00:22','2021-11-02 19:13:34'),(34,22,1,3,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 19:00:22','2021-11-02 19:13:34'),(35,23,3,6,2.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 19:01:08','2021-11-02 19:13:28'),(36,23,2,5,2.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 19:01:08','2021-11-02 19:13:28'),(37,23,1,3,2.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 19:01:08','2021-11-02 19:13:28'),(38,24,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-02 19:01:55','2021-11-02 19:13:31'),(39,25,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(40,25,1,3,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(41,25,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(42,25,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(43,26,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:10:05','2021-11-05 00:01:19'),(44,26,1,3,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:10:05','2021-11-05 00:01:19'),(45,26,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:10:05','2021-11-05 00:01:19'),(46,26,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:10:05','2021-11-05 00:01:19'),(47,26,1,2,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 00:10:05','2021-11-05 00:01:19'),(48,27,2,5,2.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(49,27,3,6,2.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(50,27,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(51,27,1,3,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(52,28,2,5,2.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,'cooked',NULL,'',NULL,'2021-11-03 11:53:00','2021-11-03 11:54:51'),(53,29,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 14:29:20','2021-11-03 14:29:20'),(54,29,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 14:29:20','2021-11-03 14:29:20'),(55,30,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 15:22:31','2021-11-03 15:22:58'),(56,31,2,5,4.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 21:51:17','2021-11-03 21:51:17'),(57,32,1,3,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 21:52:02','2021-11-03 21:52:02'),(58,33,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 21:52:50','2021-11-03 21:52:50'),(59,36,5,9,1.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-03 22:33:30','2021-11-03 22:33:30'),(60,37,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-04 10:38:21','2021-11-04 10:38:21'),(61,38,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-04 10:39:17','2021-11-04 10:39:17'),(62,39,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-04 10:40:35','2021-11-04 10:40:35'),(63,41,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-05 11:06:16','2021-11-05 11:06:16'),(64,42,5,9,1.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-05 12:32:02','2021-11-05 12:32:02'),(65,43,5,9,1.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-05 17:27:12','2021-11-05 17:27:12'),(66,44,2,5,1.0000,0.0000,0.0000,3.7500,3.7500,NULL,0.0000,3.7500,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-06 08:05:48','2021-11-06 08:05:48'),(67,46,5,9,4.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-07 11:49:36','2021-11-07 11:49:36'),(68,47,5,9,2.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-07 12:28:30','2021-11-07 12:28:30'),(69,48,5,9,8.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-07 12:30:28','2021-11-07 12:30:28'),(70,49,5,9,2.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-07 16:46:10','2021-11-07 16:46:10'),(71,50,5,9,1.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-07 17:22:34','2021-11-07 17:22:34'),(72,51,5,9,1.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-07 17:24:05','2021-11-07 17:24:05'),(73,52,5,9,2.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-08 07:27:07','2021-11-08 07:27:07'),(74,53,5,9,3.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-08 09:16:07','2021-11-08 09:16:07'),(75,54,5,9,2.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-08 11:44:33','2021-11-08 11:44:33'),(76,55,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-08 20:11:26','2021-11-08 20:11:26'),(77,56,2,5,1.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-08 20:14:36','2021-11-08 20:14:36'),(78,57,2,5,3.0000,0.0000,0.0000,5.0000,5.0000,'fixed',0.0000,5.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-09 10:32:21','2021-11-09 10:32:21'),(79,58,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-10 08:08:05','2021-11-10 08:08:05'),(80,59,5,9,2.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-10 14:01:37','2021-11-10 14:01:37'),(81,60,3,6,2.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-10 14:06:53','2021-11-10 14:06:53'),(82,60,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-10 14:06:53','2021-11-10 14:06:53'),(87,63,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 07:11:46','2021-11-15 07:11:46'),(88,63,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 07:11:46','2021-11-15 07:11:46'),(89,64,3,6,1.0000,0.0000,0.0000,1500.0000,1500.0000,NULL,0.0000,1500.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 10:04:50','2021-11-15 10:04:50'),(90,66,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 10:07:00','2021-11-15 10:07:00'),(91,67,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 10:10:33','2021-11-15 10:10:33'),(92,68,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 10:11:25','2021-11-15 10:11:25'),(93,69,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 10:11:47','2021-11-15 10:11:47'),(94,70,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 10:18:41','2021-11-15 10:18:41'),(95,70,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 10:18:41','2021-11-15 10:18:41'),(96,71,1,4,1.0000,0.0000,0.0000,12.0000,12.0000,NULL,0.0000,12.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 10:19:47','2021-11-15 10:19:47'),(97,73,3,6,2.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-15 22:29:46','2021-11-15 22:29:46'),(98,74,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-16 06:40:35','2021-11-16 06:40:35'),(99,75,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-17 11:32:54','2021-11-17 11:32:54'),(100,76,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-17 11:37:09','2021-11-17 11:37:09'),(101,77,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-17 20:49:45','2021-11-17 20:49:45'),(102,77,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-17 20:49:45','2021-11-17 20:49:45'),(103,78,7,11,4.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-17 20:54:16','2021-11-17 20:54:16'),(104,79,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-18 15:59:23','2021-11-18 15:59:23'),(105,80,3,6,3.0000,0.0000,0.0000,1500.0000,1500.0000,NULL,0.0000,1500.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 16:30:57','2021-11-23 22:57:51'),(106,80,1,4,5.0000,0.0000,0.0000,12.0000,12.0000,NULL,0.0000,12.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 16:30:57','2021-11-23 22:57:51'),(107,80,1,4,4.0000,0.0000,0.0000,12.0000,12.0000,NULL,0.0000,12.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 16:30:57','2021-11-23 22:57:51'),(108,82,7,11,7.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 16:42:40','2021-11-23 16:42:40'),(109,82,3,6,4.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 16:42:40','2021-11-23 16:42:40'),(110,82,1,4,5.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 16:42:40','2021-11-23 16:42:40'),(111,83,5,9,2.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 20:41:14','2021-11-23 20:41:14'),(112,83,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 20:41:14','2021-11-23 20:41:14'),(113,85,3,6,59.0000,0.0000,0.0000,1500.0000,1500.0000,NULL,0.0000,1500.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 21:56:07','2021-11-23 21:56:07'),(114,87,5,9,8.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 22:04:19','2021-11-23 22:04:19'),(115,88,5,9,3.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 22:04:33','2021-11-23 22:05:10'),(116,89,5,9,3.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-23 22:06:16','2021-11-23 22:06:16'),(117,90,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(118,90,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(119,90,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(120,91,1,4,3.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-26 12:44:47','2021-11-26 12:44:47'),(121,91,7,11,3.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-26 12:44:47','2021-11-26 12:44:47'),(122,92,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-26 12:45:23','2021-11-26 12:45:23'),(123,93,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-26 15:17:50','2021-11-26 15:17:50'),(124,94,7,11,2.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-27 08:46:27','2021-11-27 08:46:27'),(125,95,1,2,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-27 08:47:33','2021-11-27 08:47:33'),(126,96,3,6,2.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-27 15:04:48','2021-11-27 15:04:48'),(127,97,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-27 15:05:10','2021-11-27 15:05:10'),(128,98,3,6,8.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-27 15:36:40','2021-11-27 15:36:40'),(129,98,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-27 15:36:40','2021-11-27 15:36:40'),(130,99,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-27 17:31:38','2021-11-27 17:31:38'),(131,99,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-27 17:31:38','2021-11-27 17:31:38'),(132,100,1,4,4.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-28 10:52:49','2021-11-28 10:52:49'),(133,101,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 11:46:25','2021-11-29 11:46:25'),(134,101,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 11:46:25','2021-11-29 11:46:25'),(135,102,5,9,1.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 11:49:00','2021-11-29 11:49:00'),(136,103,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 12:56:08','2021-11-29 12:56:08'),(137,103,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 12:56:08','2021-11-29 12:56:08'),(138,104,5,9,1.0000,0.0000,0.0000,155.0000,155.0000,'fixed',0.0000,155.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 13:06:37','2021-11-29 13:06:37'),(139,105,7,11,1.0000,0.0000,0.0000,23437.5000,23437.5000,'fixed',0.0000,23437.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 14:07:50','2021-11-29 14:07:50'),(140,105,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 14:07:50','2021-11-29 14:07:50'),(141,106,3,6,1.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-29 14:08:19','2021-11-29 14:08:19'),(142,107,1,4,5.0000,0.0000,0.0000,12.0000,12.0000,NULL,0.0000,12.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-30 09:31:20','2021-11-30 09:31:20'),(143,109,3,6,3.0000,0.0000,0.0000,1875.0000,1875.0000,'fixed',0.0000,1875.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-30 12:29:04','2021-11-30 12:29:04'),(144,109,1,4,1.0000,0.0000,0.0000,15.0000,15.0000,'fixed',0.0000,15.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,0.0000,NULL,NULL,NULL,'',NULL,'2021-11-30 12:29:04','2021-11-30 12:29:04');
/*!40000 ALTER TABLE `transaction_sell_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_sell_lines_purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_sell_lines_purchase_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sell_line_id` int(10) unsigned DEFAULT NULL COMMENT 'id from transaction_sell_lines',
  `stock_adjustment_line_id` int(10) unsigned DEFAULT NULL COMMENT 'id from stock_adjustment_lines',
  `purchase_line_id` int(10) unsigned NOT NULL COMMENT 'id from purchase_lines',
  `quantity` decimal(22,4) NOT NULL,
  `qty_returned` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sell_line_id` (`sell_line_id`),
  KEY `stock_adjustment_line_id` (`stock_adjustment_line_id`),
  KEY `purchase_line_id` (`purchase_line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_sell_lines_purchase_lines` WRITE;
/*!40000 ALTER TABLE `transaction_sell_lines_purchase_lines` DISABLE KEYS */;
INSERT INTO `transaction_sell_lines_purchase_lines` VALUES (1,1,NULL,1,1.0000,0.0000,'2021-10-30 16:31:39','2021-10-30 16:31:39'),(2,NULL,1,1,1.0000,0.0000,'2021-10-30 16:35:06','2021-10-30 16:35:06'),(3,2,NULL,4,2.0000,0.0000,'2021-10-30 20:17:32','2021-10-30 20:17:32'),(4,3,NULL,1,2.0000,0.0000,'2021-10-30 20:17:32','2021-10-30 20:17:32'),(5,4,NULL,1,1.0000,0.0000,'2021-10-30 20:21:54','2021-10-30 20:21:54'),(6,5,NULL,2,1.0000,0.0000,'2021-10-30 20:21:54','2021-10-30 20:21:54'),(7,6,NULL,4,2.0000,0.0000,'2021-10-30 20:29:49','2021-10-30 20:29:49'),(8,7,NULL,1,2.0000,0.0000,'2021-10-30 20:29:49','2021-10-30 20:29:49'),(9,8,NULL,2,2.0000,0.0000,'2021-10-30 20:29:49','2021-10-30 20:29:49'),(10,9,NULL,1,1.0000,0.0000,'2021-11-02 11:37:08','2021-11-02 11:37:08'),(11,10,NULL,2,1.0000,0.0000,'2021-11-02 11:37:08','2021-11-02 11:37:08'),(12,11,NULL,2,1.0000,0.0000,'2021-11-02 11:37:36','2021-11-02 11:37:36'),(13,12,NULL,3,1.0000,0.0000,'2021-11-02 11:37:36','2021-11-02 11:37:36'),(14,16,NULL,4,1.0000,0.0000,'2021-11-02 12:13:55','2021-11-02 12:13:55'),(15,17,NULL,1,1.0000,0.0000,'2021-11-02 15:51:53','2021-11-02 15:51:53'),(16,18,NULL,1,1.0000,0.0000,'2021-11-02 15:53:34','2021-11-02 15:53:34'),(17,19,NULL,2,1.0000,0.0000,'2021-11-02 15:53:34','2021-11-02 15:53:34'),(18,20,NULL,3,1.0000,0.0000,'2021-11-02 15:53:34','2021-11-02 15:53:34'),(19,21,NULL,4,1.0000,0.0000,'2021-11-02 15:53:34','2021-11-02 15:53:34'),(20,22,NULL,2,1.0000,0.0000,'2021-11-02 15:53:40','2021-11-02 15:53:40'),(21,23,NULL,6,1.0000,0.0000,'2021-11-02 16:50:58','2021-11-02 16:50:58'),(22,25,NULL,7,8.0000,0.0000,'2021-11-02 18:59:13','2021-11-02 18:59:13'),(23,26,NULL,7,2.0000,0.0000,'2021-11-02 18:59:52','2021-11-02 18:59:52'),(24,27,NULL,4,2.0000,0.0000,'2021-11-02 18:59:52','2021-11-02 18:59:52'),(25,28,NULL,6,2.0000,0.0000,'2021-11-02 18:59:52','2021-11-02 18:59:52'),(26,29,NULL,3,1.0000,0.0000,'2021-11-02 18:59:52','2021-11-02 18:59:52'),(27,30,NULL,2,2.0000,0.0000,'2021-11-02 18:59:52','2021-11-02 18:59:52'),(28,31,NULL,7,2.0000,0.0000,'2021-11-02 19:00:22','2021-11-02 19:00:22'),(29,32,NULL,6,2.0000,0.0000,'2021-11-02 19:00:22','2021-11-02 19:00:22'),(30,33,NULL,4,2.0000,0.0000,'2021-11-02 19:00:22','2021-11-02 19:00:22'),(31,34,NULL,3,1.0000,0.0000,'2021-11-02 19:00:22','2021-11-02 19:00:22'),(32,35,NULL,7,2.0000,0.0000,'2021-11-02 19:01:08','2021-11-02 19:01:08'),(33,36,NULL,6,2.0000,0.0000,'2021-11-02 19:01:08','2021-11-02 19:01:08'),(34,37,NULL,3,2.0000,0.0000,'2021-11-02 19:01:08','2021-11-02 19:01:08'),(35,38,NULL,7,1.0000,0.0000,'2021-11-02 19:01:55','2021-11-02 19:01:55'),(36,39,NULL,6,1.0000,0.0000,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(37,40,NULL,3,1.0000,0.0000,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(38,41,NULL,5,1.0000,0.0000,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(39,42,NULL,7,1.0000,0.0000,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(40,43,NULL,7,1.0000,0.0000,'2021-11-03 00:10:05','2021-11-03 00:10:05'),(41,44,NULL,3,1.0000,0.0000,'2021-11-03 00:10:05','2021-11-03 00:10:05'),(42,45,NULL,6,1.0000,0.0000,'2021-11-03 00:10:05','2021-11-03 00:10:05'),(43,46,NULL,5,1.0000,0.0000,'2021-11-03 00:10:05','2021-11-03 00:10:05'),(44,47,NULL,2,1.0000,0.0000,'2021-11-03 00:10:05','2021-11-03 00:10:05'),(45,48,NULL,6,2.0000,0.0000,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(46,49,NULL,7,2.0000,0.0000,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(47,50,NULL,5,1.0000,0.0000,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(48,51,NULL,3,1.0000,0.0000,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(49,52,NULL,6,2.0000,0.0000,'2021-11-03 11:53:00','2021-11-03 11:53:00'),(50,53,NULL,6,1.0000,0.0000,'2021-11-03 14:29:20','2021-11-03 14:29:20'),(51,54,NULL,5,1.0000,0.0000,'2021-11-03 14:29:20','2021-11-03 14:29:20'),(52,55,NULL,6,1.0000,0.0000,'2021-11-03 15:22:31','2021-11-03 15:22:31'),(53,57,NULL,3,1.0000,0.0000,'2021-11-03 21:52:02','2021-11-03 21:52:02'),(54,58,NULL,5,1.0000,0.0000,'2021-11-03 21:52:50','2021-11-03 21:52:50'),(55,59,NULL,8,1.0000,0.0000,'2021-11-03 22:33:30','2021-11-03 22:33:30'),(56,61,NULL,6,1.0000,0.0000,'2021-11-04 10:39:17','2021-11-04 10:39:17'),(57,62,NULL,6,1.0000,0.0000,'2021-11-04 10:40:35','2021-11-04 10:40:35'),(58,63,NULL,6,1.0000,0.0000,'2021-11-05 11:06:16','2021-11-05 11:06:16'),(59,64,NULL,8,1.0000,0.0000,'2021-11-05 12:32:02','2021-11-05 12:32:02'),(60,65,NULL,8,1.0000,0.0000,'2021-11-05 17:27:12','2021-11-05 17:27:12'),(61,66,NULL,6,1.0000,0.0000,'2021-11-06 08:05:48','2021-11-06 08:05:48'),(62,67,NULL,8,4.0000,0.0000,'2021-11-07 11:49:36','2021-11-07 11:49:36'),(63,68,NULL,8,2.0000,0.0000,'2021-11-07 12:28:30','2021-11-07 12:28:30'),(64,71,NULL,8,1.0000,0.0000,'2021-11-07 17:22:34','2021-11-07 17:22:34'),(65,72,NULL,8,1.0000,0.0000,'2021-11-07 17:24:05','2021-11-07 17:24:05'),(66,74,NULL,8,3.0000,0.0000,'2021-11-08 09:16:07','2021-11-08 09:16:07'),(67,75,NULL,8,1.0000,0.0000,'2021-11-08 11:44:33','2021-11-08 11:44:33'),(68,75,NULL,9,1.0000,0.0000,'2021-11-08 11:44:33','2021-11-08 11:44:33'),(69,76,NULL,6,1.0000,0.0000,'2021-11-08 20:11:26','2021-11-08 20:11:26'),(70,77,NULL,6,1.0000,0.0000,'2021-11-08 20:14:36','2021-11-08 20:14:36'),(71,78,NULL,6,3.0000,0.0000,'2021-11-09 10:32:21','2021-11-09 10:32:21'),(72,79,NULL,7,1.0000,0.0000,'2021-11-10 08:08:05','2021-11-10 08:08:05'),(73,81,NULL,7,2.0000,0.0000,'2021-11-10 14:06:53','2021-11-10 14:06:53'),(74,82,NULL,5,1.0000,0.0000,'2021-11-10 14:06:53','2021-11-10 14:06:53'),(78,87,NULL,7,1.0000,0.0000,'2021-11-15 07:11:46','2021-11-15 07:11:46'),(79,88,NULL,10,1.0000,0.0000,'2021-11-15 07:11:46','2021-11-15 07:11:46'),(80,89,NULL,7,1.0000,0.0000,'2021-11-15 10:04:50','2021-11-15 10:04:50'),(81,90,NULL,7,1.0000,0.0000,'2021-11-15 10:07:00','2021-11-15 10:07:00'),(82,91,NULL,5,1.0000,0.0000,'2021-11-15 10:10:33','2021-11-15 10:10:33'),(83,93,NULL,5,1.0000,0.0000,'2021-11-15 10:11:47','2021-11-15 10:11:47'),(84,94,NULL,7,1.0000,0.0000,'2021-11-15 10:18:41','2021-11-15 10:18:41'),(85,95,NULL,5,1.0000,0.0000,'2021-11-15 10:18:41','2021-11-15 10:18:41'),(86,96,NULL,5,1.0000,0.0000,'2021-11-15 10:19:47','2021-11-15 10:19:47'),(87,97,NULL,7,2.0000,0.0000,'2021-11-15 22:29:46','2021-11-15 22:29:46'),(88,98,NULL,7,1.0000,0.0000,'2021-11-16 06:40:35','2021-11-16 06:40:35'),(89,99,NULL,7,1.0000,0.0000,'2021-11-17 11:32:54','2021-11-17 11:32:54'),(90,100,NULL,10,1.0000,0.0000,'2021-11-17 11:37:09','2021-11-17 11:37:09'),(91,103,NULL,10,4.0000,0.0000,'2021-11-17 20:54:16','2021-11-17 20:54:16'),(92,104,NULL,7,1.0000,0.0000,'2021-11-18 15:59:23','2021-11-18 15:59:23'),(93,111,NULL,9,2.0000,0.0000,'2021-11-23 20:41:14','2021-11-23 20:41:14'),(94,112,NULL,13,1.0000,0.0000,'2021-11-23 20:41:14','2021-11-23 20:41:14'),(95,113,NULL,7,59.0000,0.0000,'2021-11-23 21:56:07','2021-11-23 21:56:07'),(96,114,NULL,8,8.0000,0.0000,'2021-11-23 22:04:19','2021-11-23 22:04:19'),(97,115,NULL,8,1.0000,0.0000,'2021-11-23 22:04:33','2021-11-23 22:04:33'),(98,115,NULL,8,2.0000,0.0000,'2021-11-23 22:05:10','2021-11-23 22:05:10'),(99,105,NULL,7,3.0000,0.0000,'2021-11-23 22:57:51','2021-11-23 22:57:51'),(100,106,NULL,5,5.0000,0.0000,'2021-11-23 22:57:51','2021-11-23 22:57:51'),(101,107,NULL,5,4.0000,0.0000,'2021-11-23 22:57:51','2021-11-23 22:57:51'),(102,117,NULL,10,1.0000,0.0000,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(103,118,NULL,7,1.0000,0.0000,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(104,119,NULL,5,1.0000,0.0000,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(105,120,NULL,5,3.0000,0.0000,'2021-11-26 12:44:47','2021-11-26 12:44:47'),(106,121,NULL,10,3.0000,0.0000,'2021-11-26 12:44:47','2021-11-26 12:44:47'),(107,123,NULL,5,1.0000,0.0000,'2021-11-26 15:17:50','2021-11-26 15:17:50'),(108,125,NULL,18,1.0000,0.0000,'2021-11-27 08:47:33','2021-11-27 08:47:33'),(109,126,NULL,7,2.0000,0.0000,'2021-11-27 15:04:48','2021-11-27 15:04:48'),(110,127,NULL,7,1.0000,0.0000,'2021-11-27 15:05:10','2021-11-27 15:05:10'),(111,128,NULL,7,8.0000,0.0000,'2021-11-27 15:36:40','2021-11-27 15:36:40'),(112,129,NULL,10,1.0000,0.0000,'2021-11-27 15:36:40','2021-11-27 15:36:40'),(113,130,NULL,7,1.0000,0.0000,'2021-11-27 17:31:38','2021-11-27 17:31:38'),(114,131,NULL,10,1.0000,0.0000,'2021-11-27 17:31:38','2021-11-27 17:31:38'),(115,132,NULL,5,4.0000,0.0000,'2021-11-28 10:52:49','2021-11-28 10:52:49'),(116,136,NULL,5,1.0000,0.0000,'2021-11-29 12:56:08','2021-11-29 12:56:08'),(117,137,NULL,10,1.0000,0.0000,'2021-11-29 12:56:08','2021-11-29 12:56:08'),(118,139,NULL,10,1.0000,0.0000,'2021-11-29 14:07:50','2021-11-29 14:07:50'),(119,140,NULL,7,1.0000,0.0000,'2021-11-29 14:07:50','2021-11-29 14:07:50'),(120,141,NULL,7,1.0000,0.0000,'2021-11-29 14:08:19','2021-11-29 14:08:19'),(121,143,NULL,7,3.0000,0.0000,'2021-11-30 12:29:04','2021-11-30 12:29:04'),(122,144,NULL,5,1.0000,0.0000,'2021-11-30 12:29:04','2021-11-30 12:29:04');
/*!40000 ALTER TABLE `transaction_sell_lines_purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `res_table_id` int(10) unsigned DEFAULT NULL COMMENT 'fields to restaurant module',
  `res_waiter_id` int(10) unsigned DEFAULT NULL COMMENT 'fields to restaurant module',
  `res_order_status` enum('received','cooked','served') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_quotation` tinyint(1) NOT NULL DEFAULT 0,
  `payment_status` enum('paid','due','partial') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adjustment_type` enum('normal','abnormal') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` int(11) unsigned DEFAULT NULL,
  `customer_group_id` int(11) DEFAULT NULL COMMENT 'used to add customer group while selling',
  `invoice_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_repeat_on` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `total_before_tax` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Total before the purchase/invoice tax, this includeds the indivisual product tax',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `tax_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `discount_type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(22,4) DEFAULT 0.0000,
  `rp_redeemed` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `rp_redeemed_amount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'rp is the short form of reward points',
  `shipping_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_charges` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `shipping_custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_custom_field_5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_export` tinyint(1) NOT NULL DEFAULT 0,
  `export_custom_fields_info` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `round_off_amount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Difference of rounded total and actual total',
  `additional_expense_key_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_expense_value_1` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `additional_expense_key_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_expense_value_2` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `additional_expense_key_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_expense_value_3` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `additional_expense_key_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_expense_value_4` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `final_total` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `expense_category_id` int(10) unsigned DEFAULT NULL,
  `expense_for` int(10) unsigned DEFAULT NULL,
  `commission_agent` int(11) DEFAULT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_direct_sale` tinyint(1) NOT NULL DEFAULT 0,
  `is_suspend` tinyint(1) NOT NULL DEFAULT 0,
  `exchange_rate` decimal(20,3) NOT NULL DEFAULT 1.000,
  `total_amount_recovered` decimal(22,4) DEFAULT NULL COMMENT 'Used for stock adjustment.',
  `transfer_parent_id` int(11) DEFAULT NULL,
  `return_parent_id` int(11) DEFAULT NULL,
  `opening_stock_product_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `essentials_duration` decimal(8,2) NOT NULL,
  `essentials_duration_unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `essentials_amount_per_unit_duration` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `essentials_allowances` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `essentials_deductions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mfg_parent_production_purchase_id` int(11) DEFAULT NULL,
  `mfg_wasted_units` decimal(22,4) DEFAULT NULL,
  `mfg_production_cost` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `mfg_production_cost_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'percentage',
  `mfg_is_final` tinyint(1) NOT NULL DEFAULT 0,
  `repair_completed_on` datetime DEFAULT NULL,
  `repair_warranty_id` int(11) DEFAULT NULL,
  `repair_brand_id` int(11) DEFAULT NULL,
  `repair_status_id` int(11) DEFAULT NULL,
  `repair_model_id` int(11) DEFAULT NULL,
  `repair_job_sheet_id` int(10) unsigned DEFAULT NULL,
  `repair_defects` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_serial_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_checklist` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_security_pwd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_security_pattern` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repair_due_date` datetime DEFAULT NULL,
  `repair_device_id` int(11) DEFAULT NULL,
  `repair_updates_notif` tinyint(1) NOT NULL DEFAULT 0,
  `woocommerce_order_id` int(11) DEFAULT NULL,
  `prefer_payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prefer_payment_account` int(11) DEFAULT NULL,
  `sales_order_ids` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_order_ids` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import_batch` int(11) DEFAULT NULL,
  `import_time` datetime DEFAULT NULL,
  `types_of_service_id` int(11) DEFAULT NULL,
  `packing_charge` decimal(22,4) DEFAULT NULL,
  `packing_charge_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_1` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_3` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_4` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_5` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_6` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_created_from_api` tinyint(1) NOT NULL DEFAULT 0,
  `rp_earned` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `order_addresses` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `recur_interval` double(22,4) DEFAULT NULL,
  `recur_interval_type` enum('days','months','years') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recur_repetitions` int(11) DEFAULT NULL,
  `recur_stopped_on` datetime DEFAULT NULL,
  `recur_parent_id` int(11) DEFAULT NULL,
  `invoice_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_term_number` int(11) DEFAULT NULL,
  `pay_term_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pjt_project_id` int(10) unsigned DEFAULT NULL,
  `pjt_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selling_price_group_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_tax_id_foreign` (`tax_id`),
  KEY `transactions_business_id_index` (`business_id`),
  KEY `transactions_type_index` (`type`),
  KEY `transactions_contact_id_index` (`contact_id`),
  KEY `transactions_transaction_date_index` (`transaction_date`),
  KEY `transactions_created_by_index` (`created_by`),
  KEY `transactions_location_id_index` (`location_id`),
  KEY `transactions_expense_for_foreign` (`expense_for`),
  KEY `transactions_expense_category_id_index` (`expense_category_id`),
  KEY `transactions_sub_type_index` (`sub_type`),
  KEY `transactions_return_parent_id_index` (`return_parent_id`),
  KEY `type` (`type`),
  KEY `transactions_status_index` (`status`),
  KEY `transactions_sub_status_index` (`sub_status`),
  KEY `transactions_res_table_id_index` (`res_table_id`),
  KEY `transactions_res_waiter_id_index` (`res_waiter_id`),
  KEY `transactions_res_order_status_index` (`res_order_status`),
  KEY `transactions_payment_status_index` (`payment_status`),
  KEY `transactions_discount_type_index` (`discount_type`),
  KEY `transactions_commission_agent_index` (`commission_agent`),
  KEY `transactions_transfer_parent_id_index` (`transfer_parent_id`),
  KEY `transactions_types_of_service_id_index` (`types_of_service_id`),
  KEY `transactions_packing_charge_type_index` (`packing_charge_type`),
  KEY `transactions_recur_parent_id_index` (`recur_parent_id`),
  KEY `transactions_selling_price_group_id_index` (`selling_price_group_id`),
  KEY `transactions_woocommerce_order_id_index` (`woocommerce_order_id`),
  KEY `transactions_repair_model_id_index` (`repair_model_id`),
  KEY `transactions_repair_warranty_id_index` (`repair_warranty_id`),
  KEY `transactions_repair_brand_id_index` (`repair_brand_id`),
  KEY `transactions_repair_status_id_index` (`repair_status_id`),
  KEY `transactions_repair_device_id_index` (`repair_device_id`),
  KEY `transactions_repair_job_sheet_id_index` (`repair_job_sheet_id`),
  KEY `transactions_pjt_project_id_foreign` (`pjt_project_id`),
  CONSTRAINT `transactions_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_expense_category_id_foreign` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_expense_for_foreign` FOREIGN KEY (`expense_for`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `business_locations` (`id`),
  CONSTRAINT `transactions_pjt_project_id_foreign` FOREIGN KEY (`pjt_project_id`) REFERENCES `pjt_projects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_repair_job_sheet_id_foreign` FOREIGN KEY (`repair_job_sheet_id`) REFERENCES `repair_job_sheets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1,1,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-01 16:12:10',480.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,480.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,1,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 16:12:10','2021-10-30 16:12:10'),(2,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0001','',NULL,'2021/0001','25','2021-10-30 16:29:00',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,1,NULL,1,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,1,1.0000,'days',0,NULL,NULL,'4db68954d46415b3ea10157335426668',NULL,NULL,NULL,NULL,NULL,'2021-10-30 16:31:39','2021-10-30 16:33:46'),(3,1,1,NULL,NULL,NULL,'stock_adjustment',NULL,'',NULL,0,NULL,'normal',NULL,NULL,NULL,'EDEDED',NULL,NULL,NULL,'2021-10-30 16:34:00',0.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'SOBRANRE',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,12.0000,NULL,NULL,NULL,NULL,0,0,1.000,122.0000,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 16:35:06','2021-10-30 16:35:06'),(4,1,1,NULL,NULL,NULL,'purchase',NULL,'received',NULL,0,'paid',NULL,4,NULL,NULL,'PO2021/0001',NULL,NULL,NULL,'2021-10-30 16:36:00',1200.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1200.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-30 16:37:46','2021-11-02 18:49:59'),(5,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0002','',NULL,NULL,NULL,'2021-10-30 20:17:32',60.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,60.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,60,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-10-30 20:17:32','2021-10-30 20:17:32'),(6,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0003','',NULL,NULL,NULL,'2021-10-30 20:21:54',30.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,30.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,30,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-10-30 20:21:54','2021-10-30 20:21:54'),(7,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0004','',NULL,NULL,NULL,'2021-10-30 20:29:49',90.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,90.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,90,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-10-30 20:29:49','2021-10-30 20:29:49'),(8,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0005','',NULL,NULL,NULL,'2021-11-02 11:37:08',30.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,30.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,30,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 11:37:08','2021-11-02 11:37:08'),(9,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0006','',NULL,NULL,NULL,'2021-11-02 11:37:36',30.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,30.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,30,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 11:37:36','2021-11-02 11:37:36'),(10,1,1,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0001','',NULL,NULL,NULL,'2021-11-02 11:37:57',30.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,30.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 11:37:57','2021-11-02 11:37:57'),(11,1,1,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0002','',NULL,NULL,NULL,'2021-11-02 11:43:25',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 11:43:25','2021-11-02 11:43:25'),(12,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0007','',NULL,NULL,NULL,'2021-11-02 12:13:55',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 12:13:55','2021-11-02 12:13:55'),(13,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0008','',NULL,NULL,NULL,'2021-11-02 15:51:53',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 15:51:53','2021-11-02 15:51:53'),(14,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0009','',NULL,NULL,NULL,'2021-11-02 15:53:34',60.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,60.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,60,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 15:53:34','2021-11-02 15:53:34'),(15,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0010','',NULL,NULL,NULL,'2021-11-02 15:53:40',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 15:53:40','2021-11-02 15:53:40'),(16,1,1,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-01 16:46:40',90.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,90.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,2,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 16:46:40','2021-11-02 16:46:40'),(17,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,5,NULL,'0011','',NULL,NULL,NULL,'2021-11-02 16:50:57',5.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,5,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 16:50:57','2021-11-03 00:13:21'),(18,1,1,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0003','',NULL,NULL,NULL,'2021-11-02 17:55:33',100.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,100.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2021-11-02 17:55:33','2021-11-02 17:55:33'),(19,1,1,NULL,NULL,NULL,'purchase',NULL,'received',NULL,0,'due',NULL,6,NULL,NULL,'2352',NULL,NULL,NULL,'2021-11-02 18:54:00',225000.0000,NULL,0.0000,'fixed',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,225000.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'days',NULL,NULL,NULL,'2021-11-02 18:57:13','2021-11-02 18:57:13'),(20,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0012','',NULL,NULL,NULL,'2021-11-02 18:59:13',15000.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15000.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15000,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 18:59:13','2021-11-02 18:59:13'),(21,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0013','',NULL,NULL,NULL,'2021-11-02 18:59:52',3835.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3835.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,3835,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 18:59:52','2021-11-02 18:59:52'),(22,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0014','',NULL,NULL,NULL,'2021-11-02 19:00:22',3805.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3805.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,3805,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 19:00:22','2021-11-02 19:00:22'),(23,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0015','',NULL,NULL,NULL,'2021-11-02 19:01:08',3790.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3790.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,3790,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-02 19:01:08','2021-11-02 19:01:08'),(24,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0016','',NULL,NULL,NULL,'2021-11-02 19:01:55',1875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1875.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1875,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-02 19:01:55','2021-11-02 19:03:36'),(25,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0017','',NULL,NULL,NULL,'2021-11-03 00:09:42',1910.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1910.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1910,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-03 00:09:42','2021-11-03 00:09:42'),(26,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0018','',NULL,NULL,NULL,'2021-11-03 00:10:05',1925.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1925.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1925,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 00:10:05','2021-11-05 00:01:19'),(27,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0019','',NULL,NULL,NULL,'2021-11-03 08:24:20',3790.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3790.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,3790,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-03 08:24:20','2021-11-03 08:24:20'),(28,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0020','',NULL,NULL,NULL,'2021-11-03 11:53:00',10.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,10.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,10,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-03 11:53:00','2021-11-03 11:53:00'),(29,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0021','',NULL,NULL,NULL,'2021-11-03 14:29:20',20.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,20.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,20,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-11-03 14:29:20','2021-11-03 14:29:20'),(30,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0022','',NULL,NULL,NULL,'2021-11-03 15:22:31',5.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'JUAN',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,5,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 15:22:31','2021-11-03 15:22:58'),(31,1,1,NULL,NULL,NULL,'sell',NULL,'draft',NULL,0,NULL,NULL,1,NULL,'2021/0004','',NULL,NULL,NULL,'2021-11-03 21:51:17',20.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,20.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-03 21:51:17','2021-11-03 21:51:17'),(32,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0023','',NULL,NULL,NULL,'2021-11-03 21:52:02',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-03 21:52:02','2021-11-03 21:52:02'),(33,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0024','',NULL,NULL,NULL,'2021-11-03 21:52:50',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-03 21:52:50','2021-11-03 21:52:50'),(34,1,4,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-01 22:15:10',101500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,101500.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,5,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 22:15:10','2021-11-23 21:50:15'),(35,1,4,NULL,NULL,NULL,'purchase',NULL,'received',NULL,0,'paid',NULL,8,NULL,NULL,'PO2021/0003',NULL,NULL,NULL,'2021-11-03 22:25:00',300.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,300.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'months',NULL,NULL,NULL,'2021-11-03 22:28:06','2021-11-03 22:28:36'),(36,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0025','',NULL,NULL,NULL,'2021-11-03 22:33:30',155.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,155.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,155,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-03 22:33:30','2021-11-03 22:33:30'),(37,1,1,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0005','',NULL,NULL,NULL,'2021-11-04 10:38:21',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-04 10:38:21','2021-11-04 10:38:21'),(38,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0026','',NULL,NULL,NULL,'2021-11-04 10:39:17',5.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,5,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-04 10:39:17','2021-11-04 10:39:17'),(39,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0027','',NULL,NULL,NULL,'2021-11-04 10:40:35',5.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,5,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-04 10:40:35','2021-11-04 10:40:35'),(40,1,1,NULL,NULL,NULL,'opening_stock',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-01-01 06:45:25',1875000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1875000.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,7,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-05 06:45:25','2021-11-05 06:45:25'),(41,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'122','',NULL,NULL,NULL,'2021-11-05 11:03:00',5.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5.0000,NULL,NULL,NULL,NULL,1,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,5,NULL,0,1.0000,'days',0,NULL,NULL,NULL,1,'days',NULL,NULL,NULL,'2021-11-05 11:06:16','2021-11-05 11:06:16'),(42,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0028','',NULL,NULL,NULL,'2021-11-05 12:32:02',155.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,155.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,155,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-05 12:32:02','2021-11-05 12:32:02'),(43,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0029','',NULL,NULL,NULL,'2021-11-05 17:27:12',155.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,155.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,155,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-05 17:27:12','2021-11-05 17:27:12'),(44,1,1,NULL,NULL,NULL,'sell_transfer',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'2021-11-06 08:04:00',3.7500,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,5.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3.7500,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-06 08:05:48','2021-11-06 08:05:48'),(45,1,4,NULL,NULL,NULL,'purchase_transfer',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,'2021-11-06 08:04:00',3.7500,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,5.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3.7500,NULL,NULL,NULL,NULL,0,0,1.000,NULL,44,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-06 08:05:48','2021-11-06 08:05:48'),(46,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0030','',NULL,NULL,NULL,'2021-11-07 11:49:36',620.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,620.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,620,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-07 11:49:36','2021-11-07 11:49:36'),(47,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0031','',NULL,'2021/0002',NULL,'2021-11-07 12:28:30',310.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,310.0000,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,310,NULL,1,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-07 12:28:30','2021-11-07 12:28:30'),(48,1,4,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0006','',NULL,NULL,NULL,'2021-11-07 12:30:28',1240.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1240.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-07 12:30:28','2021-11-07 12:30:28'),(49,1,4,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0007','',NULL,NULL,NULL,'2021-11-07 16:46:10',310.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,310.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-07 16:46:10','2021-11-07 16:46:10'),(50,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0032','',NULL,NULL,NULL,'2021-11-07 17:22:34',155.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,155.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,155,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-07 17:22:34','2021-11-07 17:22:34'),(51,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0033','',NULL,NULL,NULL,'2021-11-07 17:24:05',155.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,155.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,155,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-07 17:24:05','2021-11-07 17:24:05'),(52,1,4,NULL,NULL,NULL,'sell',NULL,'draft',NULL,0,NULL,NULL,1,NULL,'2021/0008','',NULL,NULL,NULL,'2021-11-08 07:27:07',310.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,310.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-08 07:27:07','2021-11-08 07:27:07'),(53,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0034','',NULL,NULL,NULL,'2021-11-08 09:16:07',465.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,465.0000,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,465,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2021-11-08 09:16:07','2021-11-08 09:16:07'),(54,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0035','',NULL,NULL,NULL,'2021-11-08 11:44:33',310.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,310.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,310,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-08 11:44:33','2021-11-08 11:44:33'),(55,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0036','',NULL,NULL,NULL,'2021-11-08 20:11:26',5.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,5,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-08 20:11:26','2021-11-08 20:11:26'),(56,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0037','',NULL,NULL,NULL,'2021-11-08 20:14:36',5.0000,NULL,0.0000,'fixed',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,5,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-08 20:14:36','2021-11-08 20:14:36'),(57,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0038','',NULL,NULL,NULL,'2021-11-09 10:32:21',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-09 10:32:21','2021-11-09 10:32:21'),(58,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0039','',NULL,NULL,NULL,'2021-11-10 08:08:05',1875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1875.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1875,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-10 08:08:05','2021-11-10 08:08:05'),(59,1,4,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0009','',NULL,NULL,NULL,'2021-11-10 13:59:00',310.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,310.0000,NULL,NULL,NULL,NULL,1,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-10 14:01:37','2021-11-10 14:01:37'),(60,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,10,NULL,'0040','',NULL,NULL,NULL,'2021-11-10 14:06:53',3765.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3765.0000,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,3765,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2021-11-10 14:06:53','2021-11-10 14:06:53'),(63,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0043','',NULL,NULL,NULL,'2021-11-15 07:11:46',25312.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,25312.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,25312,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-15 07:11:46','2021-11-15 07:11:46'),(64,1,1,NULL,NULL,NULL,'sell_transfer',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,'2021-11-15 10:02:00',1500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1500.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:04:50','2021-11-15 10:04:50'),(65,1,4,NULL,NULL,NULL,'purchase_transfer',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,'2021-11-15 10:02:00',1500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1500.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,64,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:04:50','2021-11-15 10:04:50'),(66,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0044','',NULL,NULL,NULL,'2021-11-15 10:07:00',1875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1875.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1875,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-15 10:07:00','2021-11-15 10:07:00'),(67,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,11,NULL,'0045','',NULL,NULL,NULL,'2021-11-15 10:10:33',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-15 10:10:33','2021-11-15 10:10:33'),(68,1,1,NULL,NULL,NULL,'sell',NULL,'draft',NULL,0,NULL,NULL,1,NULL,'2021/0010','',NULL,NULL,NULL,'2021-11-15 10:11:25',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-15 10:11:25','2021-11-15 10:11:25'),(69,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0046','',NULL,NULL,NULL,'2021-11-15 10:11:47',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-15 10:11:47','2021-11-15 10:11:47'),(70,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0047','',NULL,NULL,NULL,'2021-11-15 10:18:41',1890.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1890.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1890,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-15 10:18:41','2021-11-15 10:18:41'),(71,1,1,NULL,NULL,NULL,'sell_transfer',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'ST2021/0003',NULL,NULL,NULL,'2021-11-15 10:19:00',12.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,12.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:19:47','2021-11-15 10:19:47'),(72,1,4,NULL,NULL,NULL,'purchase_transfer',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,'ST2021/0003',NULL,NULL,NULL,'2021-11-15 10:19:00',12.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,10.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,12.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,71,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-15 10:19:47','2021-11-15 10:19:47'),(73,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0048','',NULL,NULL,NULL,'2021-11-15 22:29:46',3750.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3750.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,3750,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-15 22:29:46','2021-11-15 22:29:46'),(74,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0049','',NULL,NULL,NULL,'2021-11-16 06:40:35',1875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1876.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1876,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-16 06:40:35','2021-11-16 06:40:35'),(75,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0050','',NULL,NULL,NULL,'2021-11-17 11:32:54',1875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1875.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1875,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,'2021-11-17 11:32:54','2021-11-17 11:32:54'),(76,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0051','',NULL,NULL,NULL,'2021-11-17 11:37:09',23437.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,23437.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,23437,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-17 11:37:09','2021-11-17 11:37:09'),(77,1,1,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0011','',NULL,NULL,NULL,'2021-11-17 20:48:00',23452.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,23452.5000,NULL,NULL,1,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2021-11-17 20:49:45','2021-11-17 20:49:45'),(78,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0052','',NULL,NULL,NULL,'2021-11-17 20:53:00',93750.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,93750.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,93750,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-17 20:54:16','2021-11-17 20:54:16'),(79,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0053','',NULL,NULL,NULL,'2021-11-18 15:58:00',1875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1875.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1875,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2021-11-18 15:59:23','2021-11-18 15:59:23'),(80,1,1,NULL,NULL,NULL,'sell_transfer',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'01012',NULL,NULL,NULL,'2021-11-23 16:29:00',4608.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,4608.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 16:30:57','2021-11-23 22:57:51'),(81,1,4,NULL,NULL,NULL,'purchase_transfer',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,'01012',NULL,NULL,NULL,'2021-11-23 16:29:00',4608.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,4608.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,80,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 16:30:57','2021-11-23 22:57:51'),(82,1,1,NULL,NULL,NULL,'sell','repair','draft','quotation',1,NULL,NULL,1,NULL,'2021/0012','',NULL,NULL,NULL,'2021-11-23 16:41:00',171637.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,171637.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-23 16:42:40','2021-11-23 16:42:40'),(83,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0054','',NULL,NULL,NULL,'2021-11-23 20:40:00',325.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,325.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,325,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-23 20:41:14','2021-11-23 20:41:14'),(84,1,4,NULL,NULL,NULL,'purchase',NULL,'received',NULL,0,'due',NULL,14,NULL,NULL,'PO2021/0004',NULL,NULL,NULL,'2021-11-23 21:52:00',90000.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,90000.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 21:54:48','2021-11-23 21:54:48'),(85,1,1,NULL,NULL,NULL,'sell_transfer',NULL,'final',NULL,0,'paid',NULL,NULL,NULL,NULL,'ST2021/0005',NULL,NULL,NULL,'2021-11-23 21:55:00',88500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,88500.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 21:56:07','2021-11-23 21:56:07'),(86,1,4,NULL,NULL,NULL,'purchase_transfer',NULL,'received',NULL,0,'paid',NULL,NULL,NULL,NULL,'ST2021/0005',NULL,NULL,NULL,'2021-11-23 21:55:00',88500.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,88500.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,85,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 21:56:07','2021-11-23 21:56:07'),(87,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0055','',NULL,NULL,NULL,'2021-11-23 22:03:00',1240.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1240.0000,NULL,NULL,6,NULL,0,0,1.000,NULL,NULL,NULL,NULL,6,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1240,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 22:04:19','2021-11-23 22:04:19'),(88,1,4,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0056','',NULL,NULL,NULL,'2021-11-23 22:04:00',465.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,465.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,6,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,465,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 22:04:33','2021-11-23 22:05:10'),(89,1,4,NULL,NULL,NULL,'sell',NULL,'draft',NULL,0,NULL,NULL,1,NULL,'2021/0013','',NULL,NULL,NULL,'2021-11-23 22:05:00',465.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,465.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,6,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-23 22:06:16','2021-11-23 22:06:16'),(90,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0057','',NULL,NULL,NULL,'2021-11-25 08:45:00',25327.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,25327.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,25327,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-25 08:45:40','2021-11-25 08:45:40'),(91,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0058','',NULL,NULL,NULL,'2021-11-26 12:43:00',70357.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,70357.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,70357,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-26 12:44:47','2021-11-26 12:44:47'),(92,1,1,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0014','',NULL,NULL,NULL,'2021-11-26 12:43:00',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-26 12:45:23','2021-11-26 12:45:23'),(93,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0059','',NULL,NULL,NULL,'2021-11-26 15:17:00',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-26 15:17:50','2021-11-26 15:17:50'),(94,1,1,NULL,NULL,NULL,'sell','repair','draft','quotation',1,NULL,NULL,1,NULL,'2021/0015','',NULL,NULL,NULL,'2021-11-27 08:45:00',46875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,46875.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-27 08:46:27','2021-11-27 08:46:27'),(95,1,4,NULL,NULL,NULL,'sell','repair','final',NULL,0,'paid',NULL,1,NULL,'0060','',NULL,NULL,NULL,'2021-11-27 08:47:00',15.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,15.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,15,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-27 08:47:33','2021-11-27 08:47:33'),(96,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0061','',NULL,NULL,NULL,'2021-11-27 15:04:00',3750.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,3750.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,3750,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-27 15:04:48','2021-11-27 15:04:48'),(97,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0062','',NULL,NULL,NULL,'2021-11-27 15:04:00',1875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1875.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1875,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-27 15:05:10','2021-11-27 15:05:10'),(98,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0063','',NULL,NULL,NULL,'2021-11-27 15:35:00',38437.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,38437.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,38437,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-27 15:36:40','2021-11-27 15:36:40'),(99,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0064','',NULL,NULL,NULL,'2021-11-27 17:30:00',25312.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,25312.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,25312,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-27 17:31:38','2021-11-27 17:31:38'),(100,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0065','',NULL,NULL,NULL,'2021-11-28 10:49:00',60.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,60.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,60,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-28 10:52:49','2021-11-28 10:52:49'),(101,1,1,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0016','',NULL,NULL,NULL,'2021-11-29 11:45:00',23452.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,23452.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-29 11:46:25','2021-11-29 11:46:25'),(102,1,4,NULL,NULL,NULL,'sell','repair','draft','quotation',1,NULL,NULL,1,NULL,'2021/0017','',NULL,NULL,NULL,'2021-11-29 11:48:00',155.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,155.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-29 11:49:00','2021-11-29 11:49:00'),(103,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0066','',NULL,NULL,NULL,'2021-11-29 12:54:00',23452.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,23452.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,23452,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-29 12:56:08','2021-11-29 12:56:08'),(104,1,4,NULL,NULL,NULL,'sell',NULL,'draft','quotation',1,NULL,NULL,1,NULL,'2021/0018','',NULL,NULL,NULL,'2021-11-29 13:05:00',155.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,155.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,6,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-29 13:06:37','2021-11-29 13:06:37'),(105,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0067','',NULL,NULL,NULL,'2021-11-29 14:07:00',25312.5000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,25312.5000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,25312,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-29 14:07:50','2021-11-29 14:07:50'),(106,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0068','',NULL,NULL,NULL,'2021-11-29 14:07:00',1875.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,1875.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1875,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-29 14:08:19','2021-11-29 14:08:19'),(107,1,1,NULL,NULL,NULL,'sell_transfer',NULL,'pending',NULL,0,'paid',NULL,NULL,NULL,NULL,'ST2021/0006',NULL,NULL,NULL,'2021-11-30 09:30:00',60.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'solo es prueba de sistema',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,60.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-30 09:31:20','2021-11-30 09:31:20'),(108,1,4,NULL,NULL,NULL,'purchase_transfer',NULL,'pending',NULL,0,'paid',NULL,NULL,NULL,NULL,'ST2021/0006',NULL,NULL,NULL,'2021-11-30 09:30:00',60.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,'solo es prueba de sistema',NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,60.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,107,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-30 09:31:20','2021-11-30 09:31:20'),(109,1,1,NULL,NULL,NULL,'sell',NULL,'final',NULL,0,'paid',NULL,1,NULL,'0069','',NULL,NULL,NULL,'2021-11-30 12:28:00',5640.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,NULL,0.0000,5640.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,0.00,NULL,0.0000,NULL,NULL,NULL,NULL,0.0000,'percentage',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,5640,NULL,0,1.0000,'days',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2021-11-30 12:29:04','2021-11-30 12:29:04');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `types_of_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types_of_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `location_price_group` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `packing_charge` decimal(22,4) DEFAULT NULL,
  `packing_charge_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_custom_fields` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `types_of_services_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `types_of_services` WRITE;
/*!40000 ALTER TABLE `types_of_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `types_of_services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allow_decimal` tinyint(1) NOT NULL,
  `base_unit_id` int(11) DEFAULT NULL,
  `base_unit_multiplier` decimal(20,4) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `units_business_id_foreign` (`business_id`),
  KEY `units_created_by_foreign` (`created_by`),
  KEY `units_base_unit_id_index` (`base_unit_id`),
  CONSTRAINT `units_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `units_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,1,'Pieces','Pc(s)',0,NULL,NULL,1,NULL,'2021-10-31 01:11:39','2021-10-31 01:11:39'),(2,2,'Pieces','Pc(s)',0,NULL,NULL,2,NULL,'2021-10-31 02:18:47','2021-10-31 02:18:47'),(3,1,'UNIDAD','UNIDAD',1,NULL,NULL,1,NULL,'2021-10-30 15:58:56','2021-10-30 15:58:56'),(4,3,'Pieces','Pc(s)',0,NULL,NULL,3,NULL,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(5,1,'Otro','Otra medida',1,NULL,NULL,1,NULL,'2021-11-04 14:09:16','2021-11-04 14:09:16'),(6,1,'ded','2de',1,NULL,NULL,1,NULL,'2021-11-05 11:12:05','2021-11-05 11:12:05'),(7,4,'Pieces','Pc(s)',0,NULL,NULL,4,NULL,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(8,1,'paquete','paquete',1,NULL,NULL,1,NULL,'2021-11-23 22:25:07','2021-11-23 22:25:07'),(9,1,'Galones','Galon',1,NULL,NULL,1,NULL,'2021-11-30 09:22:31','2021-11-30 09:22:31');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_contact_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_contact_access` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_contact_access_user_id_index` (`user_id`),
  KEY `user_contact_access_contact_id_index` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_contact_access` WRITE;
/*!40000 ALTER TABLE `user_contact_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_contact_access` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `surname` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `contact_no` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(10) unsigned DEFAULT NULL,
  `essentials_department_id` int(11) DEFAULT NULL,
  `essentials_designation_id` int(11) DEFAULT NULL,
  `max_sales_discount_percent` decimal(5,2) DEFAULT NULL,
  `allow_login` tinyint(1) NOT NULL DEFAULT 1,
  `status` enum('active','inactive','terminated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `crm_contact_id` int(10) unsigned DEFAULT NULL,
  `is_cmmsn_agnt` tinyint(1) NOT NULL DEFAULT 0,
  `cmmsn_percent` decimal(4,2) NOT NULL DEFAULT 0.00,
  `selected_contacts` tinyint(1) NOT NULL DEFAULT 0,
  `dob` date DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` enum('married','unmarried','divorced') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blood_group` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alt_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `family_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_media_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_media_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permanent_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_details` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_proof_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_proof_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_business_id_foreign` (`business_id`),
  KEY `users_user_type_index` (`user_type`),
  KEY `users_crm_contact_id_foreign` (`crm_contact_id`),
  KEY `users_essentials_department_id_index` (`essentials_department_id`),
  KEY `users_essentials_designation_id_index` (`essentials_designation_id`),
  CONSTRAINT `users_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_crm_contact_id_foreign` FOREIGN KEY (`crm_contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'user','Señor','Nacional','Code','admin@nacionalcode.com','admin@nacionalcode.com','$2y$10$aSX9FiiDU6t1jwMNJRYFz.mK0qlcOb/H2WtZmfxPkD6dNGV889fgW','es',NULL,NULL,'WEGxnGk10CqLSAyysSCNkvJjkWstFFSjOdymIBumYELNoygRPXgSke4PiYIW',1,NULL,NULL,NULL,1,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-31 01:11:38','2021-10-31 01:11:38'),(2,'user','MR','DEMO','UNI','JCROMERO09','JCROMERO09@HOTMAIL.COM','$2y$10$JZ/vRquO/9RFxRMfLKa6R.cXb0YCcScg0zVoY1A9JrK3TEHS1BSLu','en',NULL,NULL,'U8LCWxoAxcFZ0q4C6E4OoeiQ6VXqeizXTaDf7ShvWH0Bv6hsTdv64SfR2M7h',2,NULL,NULL,NULL,1,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-10-31 02:18:46','2021-10-31 02:18:46'),(3,'user','Señor','Alvieri','Vila Pariona','alvieri','sagitdiciembre@gmail.com','$2y$10$blzek2OqpqbBY7lckT/.3OXPWk6dl6txBEYciEnRq3bniExb.T2bi','es',NULL,NULL,NULL,3,NULL,NULL,NULL,1,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-03 18:49:28','2021-11-03 18:49:28'),(4,'user','juan','juan','juan','juan','email@email.com','$2y$10$mggjvhq0MeT/szKdYFfNPOFFhyxZzOhCwSqnPspKp42d6ueu547UO','en',NULL,NULL,NULL,4,NULL,NULL,NULL,1,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-11-20 01:16:31','2021-11-20 01:16:31'),(5,'user','Sr','Luis','Luis','luisito','drsinaluisa@gmail.com','$2y$10$w5KyfxI9uUNonzIj5tYtK.HqQqgk6.SVFjaLZdjhgGzVQ9ArbtFq2','en',NULL,NULL,NULL,1,NULL,NULL,NULL,1,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,'2021-11-23 22:02:04','2021-11-23 20:43:52','2021-11-23 22:02:04'),(6,'user','Sr','Luis','Luis','drsinaluisa@gmail.com','drsinaluisa@gmail.com','$2y$10$scQod7RVycq44TLQuTcxlOmm845OlL6J4RZievNc.5CqsyqhshHPC','en',NULL,NULL,NULL,1,NULL,NULL,NULL,1,'active',NULL,0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2021-11-23 22:02:42','2021-11-29 13:05:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_group_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_group_prices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation_id` int(10) unsigned NOT NULL,
  `price_group_id` int(10) unsigned NOT NULL,
  `price_inc_tax` decimal(22,4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_group_prices_variation_id_foreign` (`variation_id`),
  KEY `variation_group_prices_price_group_id_foreign` (`price_group_id`),
  CONSTRAINT `variation_group_prices_price_group_id_foreign` FOREIGN KEY (`price_group_id`) REFERENCES `selling_price_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variation_group_prices_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_group_prices` WRITE;
/*!40000 ALTER TABLE `variation_group_prices` DISABLE KEYS */;
INSERT INTO `variation_group_prices` VALUES (1,9,1,0.0000,'2021-11-03 22:09:26','2021-11-03 22:09:52'),(2,9,2,0.0000,'2021-11-03 22:09:26','2021-11-03 22:09:52'),(3,9,3,0.0000,'2021-11-03 22:09:26','2021-11-03 22:09:52'),(4,13,2,20.0000,'2021-11-17 20:53:22','2021-11-17 20:53:22'),(5,13,3,60.0000,'2021-11-17 20:53:22','2021-11-17 20:53:22');
/*!40000 ALTER TABLE `variation_group_prices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_location_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_location_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `product_variation_id` int(10) unsigned NOT NULL COMMENT 'id from product_variations table',
  `variation_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `qty_available` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_location_details_location_id_foreign` (`location_id`),
  KEY `variation_location_details_product_id_index` (`product_id`),
  KEY `variation_location_details_product_variation_id_index` (`product_variation_id`),
  KEY `variation_location_details_variation_id_index` (`variation_id`),
  CONSTRAINT `variation_location_details_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `business_locations` (`id`),
  CONSTRAINT `variation_location_details_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_location_details` WRITE;
/*!40000 ALTER TABLE `variation_location_details` DISABLE KEYS */;
INSERT INTO `variation_location_details` VALUES (1,1,1,1,1,0.0000,'2021-10-30 16:12:10','2021-11-02 15:53:34'),(2,1,1,2,1,0.0000,'2021-10-30 16:12:10','2021-11-03 00:10:05'),(3,1,1,3,1,0.0000,'2021-10-30 16:12:10','2021-11-03 21:52:02'),(4,1,1,4,1,70.0000,'2021-10-30 16:12:10','2021-11-30 12:29:04'),(5,2,2,5,1,0.0000,'2021-11-02 16:46:40','2021-11-09 10:32:21'),(6,3,3,6,1,39.0000,'2021-11-02 18:57:13','2021-11-30 12:29:04'),(7,5,5,9,4,989.0000,'2021-11-03 22:15:10','2021-11-23 22:05:10'),(8,7,7,11,1,86.0000,'2021-11-05 06:45:25','2021-11-29 14:07:50'),(9,2,2,5,4,1.0000,'2021-11-06 08:05:48','2021-11-06 08:05:48'),(10,3,3,6,4,63.0000,'2021-11-15 10:04:50','2021-11-23 22:57:51'),(11,1,1,4,4,3009.0000,'2021-11-15 10:19:47','2021-11-23 22:57:51'),(12,1,1,1,4,1000.0000,'2021-11-23 21:54:48','2021-11-23 21:54:48'),(13,1,1,2,4,1499.0000,'2021-11-23 21:54:48','2021-11-27 08:47:33'),(14,1,1,3,4,2000.0000,'2021-11-23 21:54:48','2021-11-23 21:54:48');
/*!40000 ALTER TABLE `variation_location_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `woocommerce_attr_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_templates_business_id_foreign` (`business_id`),
  KEY `variation_templates_woocommerce_attr_id_index` (`woocommerce_attr_id`),
  CONSTRAINT `variation_templates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_templates` WRITE;
/*!40000 ALTER TABLE `variation_templates` DISABLE KEYS */;
INSERT INTO `variation_templates` VALUES (1,'TALLA',1,NULL,'2021-10-30 16:03:49','2021-11-23 11:32:37');
/*!40000 ALTER TABLE `variation_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_value_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_value_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variation_template_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_value_templates_name_index` (`name`),
  KEY `variation_value_templates_variation_template_id_index` (`variation_template_id`),
  CONSTRAINT `variation_value_templates_variation_template_id_foreign` FOREIGN KEY (`variation_template_id`) REFERENCES `variation_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_value_templates` WRITE;
/*!40000 ALTER TABLE `variation_value_templates` DISABLE KEYS */;
INSERT INTO `variation_value_templates` VALUES (1,'32',1,'2021-10-30 16:03:49','2021-10-30 16:03:49'),(2,'34',1,'2021-10-30 16:03:49','2021-10-30 16:03:49'),(3,'36',1,'2021-10-30 16:03:49','2021-10-30 16:03:49'),(4,'38',1,'2021-10-30 16:03:49','2021-10-30 16:03:49');
/*!40000 ALTER TABLE `variation_value_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `sub_sku` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_variation_id` int(10) unsigned NOT NULL,
  `woocommerce_variation_id` int(11) DEFAULT NULL,
  `variation_value_id` int(11) DEFAULT NULL,
  `default_purchase_price` decimal(22,4) DEFAULT NULL,
  `dpp_inc_tax` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `profit_percent` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `default_sell_price` decimal(22,4) DEFAULT NULL,
  `sell_price_inc_tax` decimal(22,4) DEFAULT NULL COMMENT 'Sell price including tax',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `combo_variations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Contains the combo variation details',
  PRIMARY KEY (`id`),
  KEY `variations_product_id_foreign` (`product_id`),
  KEY `variations_product_variation_id_foreign` (`product_variation_id`),
  KEY `variations_name_index` (`name`),
  KEY `variations_sub_sku_index` (`sub_sku`),
  KEY `variations_variation_value_id_index` (`variation_value_id`),
  KEY `variations_woocommerce_variation_id_index` (`woocommerce_variation_id`),
  CONSTRAINT `variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variations_product_variation_id_foreign` FOREIGN KEY (`product_variation_id`) REFERENCES `product_variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variations` WRITE;
/*!40000 ALTER TABLE `variations` DISABLE KEYS */;
INSERT INTO `variations` VALUES (1,'32',1,'123',1,NULL,1,12.0000,12.0000,25.0000,15.0000,15.0000,'2021-10-30 16:11:13','2021-11-23 11:32:37',NULL,NULL),(2,'34',1,'456',1,NULL,2,12.0000,12.0000,25.0000,15.0000,15.0000,'2021-10-30 16:11:13','2021-11-23 11:32:37',NULL,NULL),(3,'36',1,'789',1,NULL,3,12.0000,12.0000,25.0000,15.0000,15.0000,'2021-10-30 16:11:13','2021-11-23 11:32:37',NULL,NULL),(4,'38',1,'10112',1,NULL,4,12.0000,12.0000,25.0000,15.0000,15.0000,'2021-10-30 16:11:13','2021-11-23 11:32:37',NULL,NULL),(5,'DUMMY',2,'21354155478',2,NULL,NULL,3.5000,3.5000,42.8600,5.0000,5.0000,'2021-11-02 16:45:46','2021-11-23 11:32:37',NULL,'[]'),(6,'DUMMY',3,'1234567',3,NULL,NULL,1500.0000,1500.0000,25.0000,1875.0000,1875.0000,'2021-11-02 18:53:20','2021-11-23 11:32:37',NULL,'[]'),(9,'DUMMY',5,'AC',5,NULL,NULL,100.0000,100.0000,55.0000,155.0000,155.0000,'2021-11-03 22:09:13','2021-11-23 23:40:49',NULL,'[]'),(10,'DUMMY',6,'I2737e-ddkdjd',6,NULL,NULL,7000.0000,7000.0000,25.0000,8750.0000,8750.0000,'2021-11-04 14:11:26','2021-11-23 11:32:37',NULL,'[]'),(11,'DUMMY',7,'Ar000007',7,NULL,NULL,18750.0000,18750.0000,25.0000,23437.5000,23437.5000,'2021-11-05 06:45:15','2021-11-23 11:32:37',NULL,'[]'),(12,'DUMMY',8,'Ar000008',8,NULL,NULL,19.0000,19.0000,25.0000,23.7500,23.7500,'2021-11-13 07:14:54','2021-11-23 11:32:37',NULL,'[]'),(13,'DUMMY',9,'1234556',9,NULL,NULL,10.0000,10.0000,25.0000,12.5000,12.5000,'2021-11-17 20:53:11','2021-11-23 11:32:37',NULL,'[]');
/*!40000 ALTER TABLE `variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warranties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` int(11) NOT NULL,
  `duration_type` enum('days','months','years') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `warranties_business_id_index` (`business_id`),
  KEY `warranties_duration_type_index` (`duration_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warranties` WRITE;
/*!40000 ALTER TABLE `warranties` DISABLE KEYS */;
INSERT INTO `warranties` VALUES (1,'GARANTIA DE FABRICA',1,'FABRICA',90,'days','2021-10-30 16:00:43','2021-10-30 16:00:43');
/*!40000 ALTER TABLE `warranties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `woocommerce_sync_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `woocommerce_sync_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `sync_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `woocommerce_sync_logs` WRITE;
/*!40000 ALTER TABLE `woocommerce_sync_logs` DISABLE KEYS */;
INSERT INTO `woocommerce_sync_logs` VALUES (1,1,'all_products','reset',NULL,NULL,1,'2021-11-23 11:32:37','2021-11-23 11:32:37');
/*!40000 ALTER TABLE `woocommerce_sync_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

